/*
 * preset.c - game presets management for Freecell Solver
 *
 * Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000
 *
 * This file is in the public domain (it's uncopyrighted).
 * 
 */

#include "fcs.h"


struct fcs_preset_struct
{
    int preset_id;
    int freecells_num;
    int stacks_num;
    int decks_num;

    int sequences_are_built_by_suit;
    int unlimited_sequence_move;
    int empty_stacks_fill;
};

typedef struct fcs_preset_struct fcs_preset_t;

enum fcs_presets_ids 
{
    FCS_PRESET_BAKERS_GAME,
    FCS_PRESET_DER_KATZENSCHWANTZ,
    FCS_PRESET_DIE_SCHALANGE, 
    FCS_PRESET_EIGHT_OFF,
    FCS_PRESET_FORECELL, 
    FCS_PRESET_FREECELL,
    FCS_PRESET_KINGS_ONLY_BAKERS_GAME,
    FCS_PRESET_RELAXED_FREECELL,
    FCS_PRESET_RELAXED_SEAHAVEN_TOWERS,
    FCS_PRESET_SEAHAVEN_TOWERS,
};

static fcs_preset_t fcs_presets[10] =
{
    {
        FCS_PRESET_BAKERS_GAME,
        4,
        8,
        1,

        1,
        0,
        FCS_ES_FILLED_BY_ANY_CARD,
    },
    {
        FCS_PRESET_DER_KATZENSCHWANTZ,
        8,
        9,
        2,

        0,
        1,
        FCS_ES_FILLED_BY_NONE,
    },
    {
        FCS_PRESET_DIE_SCHALANGE,
        8,
        9,
        2,

        0,
        0,
        FCS_ES_FILLED_BY_NONE,
    },    
    {
        FCS_PRESET_EIGHT_OFF,
        8,
        8,
        1,

        1,
        0,
        FCS_ES_FILLED_BY_KINGS_ONLY
    },    
    {
        FCS_PRESET_FORECELL,
        4,
        8,
        1,

        0,
        0,
        FCS_ES_FILLED_BY_KINGS_ONLY        
    },
    {
        FCS_PRESET_FREECELL,
        4,
        8,
        1,

        0,
        0,
        FCS_ES_FILLED_BY_ANY_CARD
    },
    {
        FCS_PRESET_KINGS_ONLY_BAKERS_GAME,
        4,
        8,
        1,

        1,
        0,
        FCS_ES_FILLED_BY_KINGS_ONLY,
    },
    {
        FCS_PRESET_RELAXED_FREECELL,
        4,
        8,
        1,

        0,
        1,
        FCS_ES_FILLED_BY_ANY_CARD,
    },
    {
        FCS_PRESET_RELAXED_SEAHAVEN_TOWERS,
        4,
        10,
        1,

        1,
        1,
        FCS_ES_FILLED_BY_KINGS_ONLY,
    },
    {
        FCS_PRESET_SEAHAVEN_TOWERS,
        4,
        10,
        1,

        1,
        0,
        FCS_ES_FILLED_BY_KINGS_ONLY,
    },
};

struct fcs_preset_name_struct
{
    char name[32];
    int preset_id;
};

typedef struct fcs_preset_name_struct fcs_preset_name_t;

static fcs_preset_name_t fcs_preset_names[14] =
{
    {
        "bakers_game",
        FCS_PRESET_BAKERS_GAME,
    },
    {
        "der_katzenschwantz",
        FCS_PRESET_DER_KATZENSCHWANTZ,
    },
    {
        "der_katz",
        FCS_PRESET_DER_KATZENSCHWANTZ,
    },
    {
        "die_schalange",
        FCS_PRESET_DIE_SCHALANGE,
    },
    {
        "eight_off",
        FCS_PRESET_EIGHT_OFF,
    },
    {
        "forecell",
        FCS_PRESET_FORECELL,
    },    
    {
        "freecell",
        FCS_PRESET_FREECELL,
    },
    {
        "ko_bakers_game",
        FCS_PRESET_KINGS_ONLY_BAKERS_GAME,
    },
    {
        "kings_only_bakers_game",
        FCS_PRESET_KINGS_ONLY_BAKERS_GAME,
    },
    {
        "relaxed_freecell",
        FCS_PRESET_RELAXED_FREECELL,
    },
    {
        "relaxed_seahaven_towers",
        FCS_PRESET_RELAXED_SEAHAVEN_TOWERS,
    },
    {
        "relaxed_seahaven",
        FCS_PRESET_RELAXED_SEAHAVEN_TOWERS,
    },
    {
        "seahaven_towers",
        FCS_PRESET_SEAHAVEN_TOWERS,
    },
    {
        "seahaven",
        FCS_PRESET_SEAHAVEN_TOWERS,
    },
};

static int fcs_get_preset_id_by_name(
    char * name
)
{
    int a;
    int ret = -1;
    for(a=0;a<(sizeof(fcs_preset_names)/sizeof(fcs_preset_names[0]));a++)
    {
        if (!strcmp(name, fcs_preset_names[a].name))
        {
            ret = fcs_preset_names[a].preset_id;
            break;
        }
    }
    
    return ret;
}

static void fcs_apply_preset(
    freecell_solver_instance_t * instance,
    int preset_id
    )
{
    int preset_index;
    for(preset_index=0 ; preset_index < (sizeof(fcs_presets)/sizeof(fcs_presets[0])) ; preset_index++)
    {
        if (fcs_presets[preset_index].preset_id == preset_id)
        {
#define preset (fcs_presets[preset_index])            
            instance->freecells_num = preset.freecells_num;
            instance->stacks_num = preset.stacks_num;
            instance->decks_num = preset.decks_num;

            instance->sequences_are_built_by_suit = preset.sequences_are_built_by_suit;
            instance->unlimited_sequence_move = preset.unlimited_sequence_move;
            instance->empty_stacks_fill = preset.empty_stacks_fill;

            return;
        }
    }
}

int fcs_apply_preset_by_name(
    freecell_solver_instance_t * instance,
    char * name
    )
{
    int preset_id = fcs_get_preset_id_by_name(name);
    if (preset_id >= 0)
    {
        fcs_apply_preset(instance, preset_id);
        return 0;
    }
    return 1;
}
