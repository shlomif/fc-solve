/*
 * move.h - header file for the move and move stacks functions of 
 * Freecell Solver
 *
 * Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000
 *
 * This file is in the public domain (it's uncopyrighted).
 */

#ifndef __MOVE_H
#define __MOVE_H

#ifdef _cplusplus
extern "C" {
#endif

#include "state.h"

enum fcs_move_types
{
    FCS_MOVE_TYPE_STACK_TO_STACK,
    FCS_MOVE_TYPE_STACK_TO_FREECELL,
    FCS_MOVE_TYPE_FREECELL_TO_STACK,
    FCS_MOVE_TYPE_FREECELL_TO_FREECELL,
    FCS_MOVE_TYPE_STACK_TO_FOUNDATION,
    FCS_MOVE_TYPE_FREECELL_TO_FOUNDATION,
    FCS_MOVE_TYPE_CANONIZE,
    FCS_MOVE_TYPE_SEPARATOR,
    FCS_MOVE_TYPE_NULL,
};

struct fcs_move_struct
{
    /* The index of the foundation, in case there are more than one decks */
    int foundation;
    /* Used in the case of a stack to stack move */
    int num_cards_in_sequence;  
    /* There are two freecells, one for the source and the other
     * for the destination */
    int src_freecell;
    int dest_freecell;
    /* Ditto for the stacks */
    int src_stack;
    int dest_stack;
    /* The type of the move see the enum fcs_move_types */
    int type;
};

typedef struct fcs_move_struct fcs_move_t;

struct fcs_move_stack_struct
{
    fcs_move_t * moves;
    int max_num_moves;
    int num_moves;
};

typedef struct fcs_move_stack_struct fcs_move_stack_t;

fcs_move_stack_t * fcs_move_stack_create(void);
int fcs_move_stack_push(fcs_move_stack_t * stack, fcs_move_t move);
int fcs_move_stack_pop(fcs_move_stack_t * stack, fcs_move_t * move);
void fcs_move_stack_destroy(fcs_move_stack_t * stack);
void fcs_move_stack_swallow_stack(fcs_move_stack_t * stack, fcs_move_stack_t * src_stack);
void fcs_move_stack_reset(fcs_move_stack_t * stack);
int fcs_move_stack_get_num_moves(fcs_move_stack_t * stack);
fcs_move_stack_t * fcs_move_stack_duplicate(fcs_move_stack_t * stack);

void fcs_apply_move(fcs_state_with_locations_t * state_with_locations, fcs_move_t move, int freecells_num, int stacks_num, int decks_num);

#if 0
char * fcs_move_as_string(fcs_move_t move);
#endif

void fcs_move_stack_normalize(
    fcs_move_stack_t * moves,
    fcs_state_with_locations_t * init_state,
    int freecells_num,
    int stacks_num,
    int decks_num
    );

#ifdef _cplusplus
}
#endif

#endif  // __MOVE_H
