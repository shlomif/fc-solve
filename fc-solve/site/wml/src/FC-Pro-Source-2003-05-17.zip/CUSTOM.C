//
// created by wilson callan 11/7/98
//

#include "main.h"
#include "custom.h"
#include "freecell.h"

CHAR gszCustomGameFile[MAXSTRING];
BOOL gbCustomGame = FALSE;
CHAR gszCustomGameName[CUSTOM_MAXSTRING_NAME];
extern HWND ghwndMainApp;
BOOL gbCustClip ;
char* ClipText ;
PTSTR pClip, ClipPtr ;
//INT ClipPtr ;
BOOL CustomReadName (HWND hwnd)
{
	HFILE fhFile;
	CHAR  szTemp[16 + MAXSTRING];
	HANDLE hClip ;
	INT i ;

if (gbCustClip)
{
	OpenClipboard(ghwndMainApp) ;
	hClip = GetClipboardData(CF_TEXT);
	if (!hClip)
	{
		CloseClipboard() ;
		MainMessage ("No text data in Clipboard");
		return FALSE;
	}
	ClipText = (char*)malloc(GlobalSize(hClip)) ;
	pClip = GlobalLock(hClip) ;
	lstrcpy (ClipText, pClip) ;
	GlobalUnlock(hClip) ;
	CloseClipboard() ;
	ClipPtr = ClipText ;
	i = 0 ;
	while (ClipPtr[0] != '\n')
	{
		gszCustomGameName[i] = ClipPtr[0] ;
		ClipPtr++ ;
		i++ ;
	}
	gszCustomGameName[i - 1] = 0 ;  // Pending 2/21/02 to fix sloppy line
							// (from memory; check out)
//MainMessage(ClipText) ;
}
else
{
	if ((fhFile = _lopen(gszCustomGameFile, OF_READ)) == HFILE_ERROR)
	{
		//put up a message here.
		sprintf (szTemp, "ERROR_LOPEN: '%s'", gszCustomGameFile);
		ShowLastError (hwnd, szTemp);
		return FALSE;
	}

	// File exists
	// scan in game name

	_lread(fhFile, szTemp, CUSTOM_MAXSTRING_NAME);

	if (sscanf (szTemp, "%s", gszCustomGameName) != 1)
	{
		Message (hwnd, MB_ICONEXCLAMATION, 
					"No Game Name Found in '%s'!", szTemp);
		_lclose(fhFile);
		return FALSE;
	}

	_lclose(fhFile);
}
	return TRUE;
}

VOID CustomDeal (VOID)
{
	HFILE fhFile;
	CHAR  szTemp[16 + MAXSTRING];
    int  col, pos;
	BOOL gbCustMode ;

	if (((fhFile = _lopen(gszCustomGameFile, OF_READ)) == HFILE_ERROR) && !gbCustClip)
	{
		//put up a message here.
		sprintf (szTemp, "ERROR_LOPEN: '%s'", gszCustomGameFile);
		ShowLastError (ghwndMainApp, szTemp);
		return;
	}

	// File exists

	/* init Column Length */

	for (col = 0; col < NUM_COLS; col++)
	{
		ColLen[col] = 0;
	}
	// scan in game
	gbCustMode = FALSE ;

    for (pos = 0; pos < MAXPOS; pos++)
	{
		// goto end of line
	if (!gbCustClip)
		FileScan (fhFile, '\n', 1);
	else
		ClipPtr = strchr(ClipPtr, (int)'\n') + 1;
	for (col = 1; col < MAXCOL; col++)
		{
			CARD c;

			// read value
			if ((!gbCustClip && (_lread(fhFile, szTemp, 1) == 0)) || (gbCustClip && (ClipPtr[0] == 0)))
			{
				// reached end of file!
				pos = MAXPOS;
				break;
			}
			if (gbCustClip)
			{
				szTemp[0] = ClipPtr[0] ;
				ClipPtr++ ;
			}
			if ((szTemp[0] == '\n') || (szTemp[0] == '\r'))
			{
				// reached end of file!
				pos = MAXPOS;
				break;
			}
			if (szTemp[0] == '+')
			{
				col = 1 ;
				_lread(fhFile, szTemp, 1) ;
				_lread(fhFile, szTemp, 1) ;
				_lread(fhFile, szTemp, 1) ;
				gbCustMode = TRUE ;
			}
/*
			if (szTemp[0] == ' ')
			{
				// only allow spaces at end of lines and files
				pos = MAXPOS;
				break;
			}
*/
			if (szTemp[0] == '-')
			{
				// for intermediate position setup
				c = EMPTY ;
			}
			
			szTemp[0] = toupper (szTemp[0]);

			switch (szTemp[0])
			{
				case 'A':
					c = 0;
					break;
				case 'T':
					c = 9;
					break;
				case 'J':
					c = 10;
					break;
				case 'Q':
					c = 11;
					break;
				case 'K':
					c = 12;
					break;
				default:
				if (isdigit(szTemp[0]))
					c = szTemp[0] - '1';
			}

			c *= NUM_SUITS;

			// read suit

			if ((!gbCustClip && (_lread(fhFile, szTemp, 1) == 0)) || (gbCustClip && (szTemp[0] == 0)))
			{
				// reached end of file!
				pos = MAXPOS;
				break;
			}
			if (gbCustClip)
			{
				szTemp[0] = ClipPtr[0] ;
				ClipPtr++ ;
			}
			if (szTemp[0] == '-')
			{
				c = EMPTY ;
			}
			szTemp[0] = toupper (szTemp[0]);

			switch (szTemp[0])
			{
				case 'C':
					c += 0;
					break;
				case 'D':
					c += 1;
					break;
				case 'H':
					c += 2;
					break;
				case 'S':
					c += 3;
					break;
			}
			if (!gbCustMode)
	            card[col][pos] = c;
			else
				card[0][col-1] = c;
			if ((c != EMPTY) && !gbCustMode)
				ColLen[col-1]++;

			// read space

			if ((!gbCustClip && (_lread(fhFile, szTemp, 1) == 0)) || (gbCustClip && (ClipPtr[0] == 0)))
			{
				// reached end of file!
				pos = MAXPOS;
				break;
			}
		if (gbCustClip)
		{
			ClipPtr++ ;
		}
		}
	}
	if (!gbCustClip)
		_lclose(fhFile);
	else
		gbCustClip = FALSE;
return ;
}
