// 1997, wilson callan
#include "main.h"
#include "fcplay.h"
PRIVATE CHAR gszMoveFrom[3], gszMoveTo[3];

PRIVATE VOID CardString (CARD c, CHAR *str);

BOOL MakeMoveStatus (CHAR src, CHAR dst)
{
	CHAR str[3+2+3+2+9+1];
	BOOL rtn = MakeMoveHS (src, dst);

	// use strncpy since gszMoveFrom or To could be bad

	strncpy (str, gszMoveFrom, 3+1);
	strcat (str, "->");
	strncat (str, gszMoveTo, 3+1);

	if (rtn)
	{
		// okay move
		strcat (str, ": Okay Move");
	}
	else											   
	{
		// no good
		strcat (str, ": No Good");
	}

	StatusOut (str);

	return rtn;
}

VOID ShowCardG (CARD c, BOOL moveFrom) 
{
	if (moveFrom)
	{
		CardString (c, gszMoveFrom);
	}
	else
	{
		CardString (c, gszMoveTo);
	}
}

VOID ShowCell (CHAR *str)
{
	strcpy (gszMoveTo, str);
}

PRIVATE VOID CardString (CARD c, CHAR *str)
{
	switch (VALUE(c))
	{
		case ACE:
			sprintf(str, "A");
			break;

		case TEN:
			sprintf(str, "%d", VALUE(c)+1);
			break;

		case JACK:
			sprintf(str, "J");
			break;

		case QUEEN:
			sprintf(str, "Q");
			break;

		case KING:
			sprintf(str, "K");
			break;

		default:
			sprintf(str, "%d", VALUE(c)+1);
			break;
	}

	switch (SUIT(c))
	{
		case CLUB:
			strcat (str, "C");
			break;

		case DIAMOND:
			strcat (str, "D");
			break;

		case HEART:
			strcat (str, "H");
			break;

		case SPADE:
			strcat (str, "S");
			break;

		default:
			strcat (str, "?");
			break;
	}
}



