// wilson callan, copyright 1997, 1998

#include "main.h"
#include "custom.h"
#include "settings.h"
#include "freecell.h"
#include "log.h"
#include "fcplay.h"
#include "fcsolve.h"

#define SHOWAUTO	(0)
//#define SHOWAUTO	(1)
//#define SHOWAUTODIAG    (1)

STD_CARD gSel;
INT	     gnUserMoves;	// non-auto
BOOL	 gbFlourish;
INT 	 gnAnimation;
INT      gnUserUndoType;
BYTE     gyPrevAction;
INT		 gnSels;	// user&auto selections
STD_MOVES gMoves[STD_MOVES_PER_LINE * STD_MAX_LINES * AUTO_PER_MOVE]; 

BOOL gbMoveID ;
PRIVATE BOOL gbRedo ;
PRIVATE INT   gnLastMove;
PRIVATE CHAR Scol ; // added for supermove

PRIVATE BOOL ClickOnCol (UINT pos, INT col);
PRIVATE VOID GotBackspace (VOID);
PRIVATE BOOL GotLiveClick (HWND hwnd, CHAR location);
PRIVATE VOID SelectCard (CHAR loc);
PRIVATE VOID DeselectCard (BOOL move);
PRIVATE VOID AddMoveStruct (INT col, INT pos, STD_CARD *crd);
extern BOOL gbSearchF, gbSearchF2, gbSearchF3;

//
// init function
//
VOID FreeCellInit (BOOL update)
{
	gSel.location   = 0;
	gSel.position   = NONE_SELECTED;
	gSel.column	    = NONE_SELECTED;
	gnSels  	    = 0;
	gnUserMoves	    = 0;
	gbMoveID		= FALSE;
	gnLastMove		= 0;
	gbRedo			= FALSE;
	gyPrevAction	= START;
	gbFlourish		= FALSE;

	gbLoadingSolver = gbSolverLoaded = FALSE;

	FileInit ();
	LogInit ();

	// deal hand

	FreeCellDeal ();
	FCPlayInit ();
	// init proaids
	if (gbProAids)
	    {
		TestPossMoves (0);  // clear arrows
		TestProLines ();
	    }

//	TestPossMoves (0);
//	TestProLines ();
	if (update)
	{
		// show deal&solution 
		InvalidateMain (NULL);
	}
	else
	{
		InvalidateSolution (FALSE); // top line
	}
}

//
// handle single click
//
CHAR RcvdLeftButtonDown (UINT xPos, UINT yPos)
{
	CHAR l, loc = '?';

	if (yPos <= YPOS_FC_END)
	{
		if (xPos >= XPOS_HC_START)
		{
			// found a home click

			loc = 'h'; 
		}
		else if (xPos <= XPOS_FC_END)
		{
			// found a freecell click

			loc = (xPos / XPOS_FC_SIZE) + 'a';
			if (loc > 'g')
				loc = loc + 3 ;  // for > 7 freecells
		}
	}
	else if (yPos >= YPOS_CL_START)
	{
		// found a column click?

		l = ((xPos - XPOS_CL_OFFSET) / XPOS_CL_SIZE);

		if (gSel.location)
		{
			// location is the destination

			if (l >= NUM_COLS)
			{
				// user clicked in last "dead" space

				l = NUM_COLS - 1;
			}
			else if (l < 0)
			{
				// user clicked in first "dead" space

				l = 0;
			}

			loc = l + '1';
		}
		else
		{
			// location is the origination

			if ((l < NUM_COLS) && (l >= 0))
			{
				// user clicked on a column
				// is click above last card end?

				if (ClickOnCol (yPos, l))
				{
					loc = l + '1';
				}
			}
		}
	}

	return loc;
}

PRIVATE BOOL ClickOnCol (UINT pos, INT col)
{
	if (pos < (UINT) ((ColLen[col] * YPOS_CARD_VISIBLE_SIZE) 
			 		  + YPOS_LAST_CARD_DELTA
					  + YPOS_CL_START))
	{
		ActivateSupMoveTest() ;
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

BOOL RcvdRightButtonDown (UINT xPos, UINT yPos, BYTE *col, BYTE *pos)
{
	if (yPos >= YPOS_CL_START)
	{
		// found a column click

		*col = ((xPos - XPOS_CL_OFFSET) / XPOS_CL_SIZE);

		if (*col >= NUM_COLS)
		{
			// user clicked in last "dead" space

			*col = NUM_COLS - 1;
		}
		else if (*col < 0)
		{
			// user clicked in first "dead" space

			*col = 0;
		}

		(*col)++;  // col 0 is fc row

		*pos = ((yPos - YPOS_CL_START) / YPOS_CARD_VISIBLE_SIZE);

		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

VOID GotChar (HWND hwnd, CHAR ch)
{
	BOOL bBackupID;
	INT  nMove;
	switch (ch)
	{
		case '1':
	    case '2':
	    case '3':
	    case '4':
	    case '5':
	    case '6':
	    case '7':
	    case '8':
		case '9':
		case 'a':
	    case 'b':
	    case 'c':
	    case 'd':
		case 'e': //TEST
		case 'f':
		case 'g':
		case 'h':
		case 'k':
		case 'l':
		case '0':
			// process live click/key
//MessageBox(GetFocus(), "LC0", "LC", MB_OK) ;
			if (!gbGameOn && gbSpider)
				break ;
//MessageBox(GetFocus(), "LC1", "LC", MB_OK) ;
			if (gSel.location && gSel.column &&  //11/26/99 protects against lock-up when
					//ace is moved to column as first move of game
						(VALUE(card[gSel.column][ColLen[gSel.column-1] - 1]) == ACE)
						&& !gbSpider)
				ch = 'h' ;
			if (ch == '9')
				ch = 'h' ;	// to conform to standard freecell
//MessageBox(GetFocus(), "pGLC", "LC", MB_OK) ;
			if (GotLiveClick (hwnd, ch))
			{
				gyPrevAction = MOVE;
//MessageBox(GetFocus(), "GLC", "LC", MB_OK) ;

				// if user is changing a loaded set of moves, then 
				// inc attempt number
				if (gbSolutionLoaded)
				{
					gbSolutionLoaded = FALSE;
					// update attempt num in log file
					UpdateLogFile (TRUE);
				}
//MessageBox(GetFocus(), "Pre-IS", "LC", MB_OK) ;
				InvalidateSolution (TRUE);  // most recent move forward
			}
			break;

		case ' ':
		TestSolver() ;
		case CR:
		case LF:
			break;

		case 'u':
			// undo 10
			for (nMove = 0; nMove < 10; nMove++)
			{
				SendMessage (hwnd, WM_CHAR, VK_BACK, 0);
			}
			break;

		case 'r':
			// redo 10
			for (nMove = 0; nMove < 10; nMove++)
			{
				if ((gnSels / 2) >= gnLastMove)
				{
					// none more to redo
					// do redo once to show message
					SendMessage (hwnd, WM_CHAR, VK_TAB, 0);
					break;
				}
				SendMessage (hwnd, WM_CHAR, VK_TAB, 0);
			}
			break;

		case VK_HOME:
			while (gnSels > 0)
			{
				SendMessage (hwnd, WM_CHAR, VK_BACK, 0);
			}
			break;

		case VK_END:
			while ((gnSels / 2) < gnLastMove)
			{
				SendMessage (hwnd, WM_CHAR, VK_TAB, 0);
			}
			break;

		case VK_BACK:
		{
			BOOL bAllowUndo = TRUE;

			if(gbSpider)
				gbGameOn = TRUE;
			
			if (gnUserUndoType == UNDO_NONE)
			{
				// user disabled it

				Message (hwnd, MB_ICONEXCLAMATION, "Undo is completely disabled!");
				break;
			}

			 // undo - handle state machine

			switch (gyPrevAction)
			{
				case UNDO1:
				case UNDO2:
					// new attempt after 2 undoes OF MOVES
					if (( gbFastUndo && (gyPrevAction == UNDO1)) ||
					    (!gbFastUndo && (gyPrevAction == UNDO2)) )
					{
						if (!gbSolutionLoaded)
						{
							// we are not just backing
							// up a solution.  its a new attempt since
							// we are making a new move

							if (gnUserUndoType == UNDO_UNLIMITED)
							{
								gyPrevAction = UNDOING;

								// update attempt num in log file
								UpdateLogFile (TRUE);

								// show new attempt number
								
								InvalidateSolution (FALSE);
							}
							else
							{
								// user asked to not do this
								bAllowUndo = FALSE;

								Message (hwnd, MB_ICONEXCLAMATION, "Further Undo is disabled!");
							}
						}
						else
						{
							// not new attempt since we are just backing
							// up a solution.  

							gyPrevAction = UNDOING;
						}
					}
					else
					{
						// if Slow Undo and Previous Action is Undo1
						gyPrevAction = UNDO2;
					}
					break;
				case UNDOING:
					break;
				default:
					gyPrevAction = UNDO1;
			}

			if (!bAllowUndo)
			{
				break;
			}

			if (gSel.location)
			{
				DeselectCard (FALSE);
				BackLog (1);
			}
			else if (gnSels > 0)
			{
				// no card selected, we have to dig into the 
				// solution.  unmake the last move including auto
				// posts.  keep undoing moves until the move id
				// changes

				// get opposite of current id

				bBackupID = !gbMoveID;

				// backup solution to previous

				gnSels -= 2;

				while ((gMoves[gnSels/2].bMoveID == bBackupID) &&
					   (gnSels >= 0))
				{
					if (!gMoves[gnSels/2].bAutoMove)
					{
						// backup user move count

						gnUserMoves--;
					}

					// use MoveCard () because this might not be a
					// legal move - make sure new space is empty
					gbGameOn = TRUE ;  // 5/2/00 needs to be reactivated
					MoveUndo (gMoves[gnSels/2].src.column,
							  gMoves[gnSels/2].src.position,
							  gMoves[gnSels/2].dst.column,
							  gMoves[gnSels/2].dst.position);

					if (gbProAids)
			    		  TestProLines ();
	
					// backup solution to previous

					gnSels -= 2;
				}

				// dont overwrite this move

				gnSels += 2;

				// adrian wants option to make
				// undo undo both clicks

				if (!gbFastUndo)
				{
					// leave the card selected - have to use the location
					// here since this could be an auto move

					SelectCard (gMoves[gnSels/2].src.location);
				}

				// toggle ID back to this value

				gbMoveID = !gbMoveID;

				// backup log file here too
				BackLog (1); // remove dst

				if (gbFastUndo)
				{
					BackLog (1); // remove src
				}
			}
			InvalidateSolution (TRUE);  // most recent undo
		}
		break;

		case VK_TAB:
			// Redo - send next user move off array back thru fcpro

			gyPrevAction = REDO;

			// note that redo of the first selection does not work
			// because gMoves never got the selection

			nMove = gnSels/2;

			if (nMove >= gnLastMove)
			{
				Message (hwnd, MB_ICONINFORMATION, "Cannot Redo any more.");
				return;
			}

			while (gMoves[nMove].bAutoMove)
			{
				if (++nMove >= gnLastMove)
				{
					Message (hwnd, MB_ICONINFORMATION, "Cannot Redo any more.");
					return;
				}
			}

			if (!gSel.location || gbFastUndo)
			{
				// select card

				SendMessage (hwnd, WM_CHAR, 
					gMoves[nMove].src.location, 0);

				if (!gbFastUndo)
				{
					// redo one click at a time

					return;
				}
			}

			gbRedo = TRUE;
			SendMessage (hwnd, WM_CHAR, 
				gMoves[nMove].dst.location, 0);
			gbRedo = FALSE;
			break;

		 default:
#if DEBUG
			Message (hwnd, MB_ICONEXCLAMATION, 
						"Illegal Character '%c'.", ch);
#endif
			break;
	}
}
//char szTemp[50] ;
PRIVATE BOOL GotLiveClick (HWND hwnd, CHAR loc)
{
	WORD locword ;
	INT smCnt, i ;
	char tSrc ;
//MessageBox(GetFocus(), "GLC", "GLC", MB_OK) ;
	// put char in array of moves
	if (gSel.location)
	{
		// location is the destination
		// check if this is a deselection
		if (loc == gSel.location)
		{
			// deselection
			DeselectCard (FALSE);
			if (gbProAids)
			  TestPossMoves(0) ;
			// backup log
			BackLog (1);
			return TRUE;
		}
		else
		{

			// completion of a move?
			if (gbSpider && (loc == 'h'))
				return FALSE ;	// In spider mode, inhibit moves to home
//MainMessage("Spid1 OK");
			if (loc == '0')  //Keyboard request for freecell
			{
				if (gSel.location < 'a')
				{
					for (i = 0 ; i < NumFcs ; i++)
					{
						if (card[0][i] == EMPTY)
						{
							loc = i + 'a' ;
							break ;
						}
					}
					if (i == NumFcs)
					{
						StatusOut("All freecells are occupied.") ;
						return FALSE ;
					}
				}
				else
				{		//freecell already selected, advance to next one
					tSrc = gSel.location ;
					DeselectCard (FALSE);
					BackLog (1);
					for (i = tSrc + 1 - 'a' ; i < NumFcs ; i++)
					{
						if (card[0][i] != EMPTY)
						{
							loc = i + 'a' ;
							if (loc > 'g')
								loc += 3 ;
							SelectCard (loc);
					        if (gbProAids)
								TestPossMoves(loc) ;
							LogMove (loc);
							Scol = loc;  // needed for SaveMultMove
							break ;
						}
					}
					return TRUE ;
				}
			}
			if (MakeMoveStatus (gSel.location, loc))
			{
//MainMessage("MMS OK") ;
				// legal move - change move ID for next legal move
				// move ID is used to ID move sets for undo
				gbMoveID = !gbMoveID;
 				gnUserMoves++;
				tSrc = gSel.location ;
				DeselectCard (TRUE);

				if (gbProAids)
			    {
					TestPossMoves (0);  // clear arrows
					TestProLines ();
			    }

				// set to activate first pass of SaveMultMove

				locword = 256 + (WORD)loc ;
				smCnt = 0 ;

				while (HIBYTE(locword))
				{
					//SaveMultMove returns loc with hibyte zero
					// if no mult. move, or on last move
//MainMessage("PreSMM") ;

					locword = SaveMultMove(loc, Scol);

					if (HIBYTE(locword))
						loc = 0 ; // to signal non-first pass

					if (smCnt > 0)
						gnUserMoves++ ;  // if logging off, only reason

					smCnt++ ;
					if ((LOBYTE(locword) >= 'h') && (LOBYTE(locword) <= 'i'))
						LOBYTE(locword) += 3 ;
//MainMessage("Prelog") ;
					LogMove (LOBYTE(locword));
//MainMessage("Postlog") ;
				}

				// check if the game is still not lost
				// this subroutine posts a messagebox if the game
				// is lost, thats it.

				GameLost ();

				// only flourish once
				// dont have undo being animating from now on!

				gbFlourish = FALSE; 
				return TRUE;
			}
			else
			{
				// illegal move

				if ((gbMessages || gbLoadingSolution) &&
  								 !gbLoadingSolver)
				{
					if (gbSearchF || gbSearchF2 || gbSearchF3)
					{
						gbSearchF = gbSearchF2 = gbSearchF3 = FALSE ;
						KillTimer(hwnd, 1) ;
					}
					Message (hwnd, MB_ICONINFORMATION, 
								"That move is not allowed.%s%c->%c",
								CRLF, gSel.location, loc);

					// tell load file to stop!
					gbLoadingSolution = FALSE;

				}

				// tell solver what happened

				gbLoadingSolver = FALSE;

				return FALSE;
			}
		}
	}
	else
	{
		// location is the originating

		// originating from home?
//sprintf(szTemp, "loc- %c", loc) ;
//MessageBox(GetFocus(), szTemp, "GLC", MB_OK) ;
		if (loc != 'h')
		{
//MainMessage("Non-H") ;
			if (loc == '0')  // Keyboard request for freecell selection
			{
				for (i = 0 ; i < NumFcs ; i++)
				{
					if (card[0][i] != EMPTY)
					{
						loc = i + 'a' ;
						break ;
					}
				}
				if (loc == '0')
					return FALSE ;
			}
			//  cannot consider it a click if there is nothing 
			// in that column or freecell!
//MainMessage("O3 OK") ;
			if (!ValidateClick (loc))
			{
//MainMessage("VC False") ;
				return FALSE;									
			}
			// valid originating click
//MainMessage("O4 OK") ;
			SelectCard (loc);
	        if (gbProAids)
			  TestPossMoves(loc) ;
			if ((loc >= 'h') && (loc <= 'i'))
				loc += 3 ;
			LogMove (loc);
			Scol = loc;  // needed for SaveMultMove
//MainMessage("GCL True") ;
			return TRUE;
		}
		else
			return FALSE;
	}	
}
//
//	select card for inversion
//  //
VOID SelectCard (CHAR loc)
{
	// select the card
	gSel.location = loc;

	if (loc == 'h')
	{
		// this only points to first homecell

		gSel.column = 0;
		gSel.position = loc - 'h' + NUM_FCS; 
	}
	else if (gSel.location >= 'a')
	{
		// selected a freecell

		gSel.column = 0;
		gSel.position = loc - 'a';
#ifdef FC89
		if (gSel.position > 6)
			gSel.position -= 3 ;
#endif
	}
	else
	{
		// selected a column

		gSel.column = loc - '1' + 1;  // row 0 is freecell row
		gSel.position = ColLen[gSel.column-1] - 1;
	}

	InvalidateCard (gSel.column, gSel.position);

	StatusOut ("Selected...");
}

VOID DeselectCard (BOOL move)
{
	InvalidateCard (gSel.column, gSel.position);

	gSel.column = gSel.position = NONE_SELECTED;
	gSel.location = 0;

	if (!move)
	{
		StatusOut ("Deselected!");
	}
}

CHAR AddMove (INT col, INT pos, BOOL bAutoMove)
{
	CHAR ch;

	gMoves[gnSels/2].bAutoMove = bAutoMove;
	gMoves[gnSels/2].bMoveID   = gbMoveID;

	if (gnSels % 2)  // here is why we need gnSels instead of a gnMoves!
	{
		// dst

		AddMoveStruct (col, pos, &gMoves[gnSels/2].dst);  

		ch = gMoves[gnSels/2].dst.location;

#if SHOWAUTO
		if (bAutoMove)
		{
			gMoves[gnSels/2].bAutoMove = FALSE;
			gnUserMoves++;
		}
#endif

		if ( (gnAnimation == ANIMATE_ALL) ||  // animate all
			// dont animate loading
			((gnAnimation == ANIMATE_NOTSOLUTION) && !gbLoadingSolution) ||  
			// animate flourish only
			((gnAnimation == ANIMATE_FLOURISH) && !gbLoadingSolution && 
			  gbFlourish)) 
		{
			UpdateMain ();
		}
	}
	else
	{
		AddMoveStruct (col, pos, &gMoves[gnSels/2].src);  

		ch = gMoves[gnSels/2].src.location;
	}

	gnSels++;	

	if (!gbRedo)
	{
		// only change last move if not going forward in array via
		// redo

		gnLastMove = gnSels/2;  // set to users last move (after undo)

		if (gnLastMove >= (sizeof (gMoves) / sizeof (STD_MOVES)))
		{
			MainMessage ("Out of moves memory.");
		}
	}

	return ch;
}

PRIVATE VOID AddMoveStruct (INT col, INT pos, STD_CARD *crd)
{
	crd->column	  = col;
	crd->position = pos;

	if (col == 0)
	{
		// selected a freecell or homecell

		if (pos > (NUM_FCS - 1))
		{
			// homcell
			crd->location = 'h';
		}
		else
		{
			crd->location = pos + 'a';
			if (crd->location > 'g')
				crd->location += 3 ;
		}
	}
	else
	{
		// selected a column

		crd->location = col - 1 + '1';
	}
}

VOID GotDoubleClick (HWND hwnd, CHAR ch)
{
CHAR DCdest;
INT i ;
	//  cannot move card from home
	if (ch == 'h')
		return;
// cannot move card from empty column or freecell
	if (!ValidateClick (ch))
		return;	
	DCdest = 0 ;
		if (gnDblclkMode == 1) // home mode
		DCdest = 'h' ;
	else //freecell mode
	{
		for (i = 0; i < NumFcs; i++) //find empty freecell
			if (card[0][i] == EMPTY)
			{
				DCdest = i + 'a' ;
#ifdef FC89
				if (DCdest > 'g')
					DCdest += 3 ;
#endif
				break ;
			}
	}
	if (!DCdest)
		return ;
	// can card be moved?
	if (MakeMoveT (ch, DCdest))
	{
		// card can be moved!
		// deselect card if its been
		if (gSel.location)
		{
			// card has been selected!
			DeselectCard (TRUE);	// true, no status printing
			if (gbProAids)
				TestPossMoves (0); 
			// backup log
			BackLog (1);
		}
		// now select this card
		SelectCard (ch);
	    if (gbProAids)
			TestPossMoves (ch);
		if ((ch >= 'h') && (ch <= 'i')) ;
			ch += 3 ;
		LogMove (ch);
		Scol = ch;  // needed for SaveMultMove
		// now make the move
//		GotLiveClick (hwnd, ch);
//		GotLiveClick (hwnd, 'h');
		GotLiveClick (hwnd, DCdest);
		InvalidateSolution (TRUE);  // show move
	}
}
