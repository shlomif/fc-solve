/******************************************************************************\
* wilson callan, copyright 1997
\******************************************************************************/

#include <time.h>
#include "main.h"
#include "custom.h"
#include "fcsolve.h"
#include "settings.h"
#include "freecell.h"
#include "log.h"
#include "fcplay.h"
#include "cards.h"

/*
 * Macros to simplify working with menus.
 */
#define MyEnableMenuItem(hMenu, wIDEnableItem, fEnable) \
    EnableMenuItem((hMenu),(wIDEnableItem),(fEnable)?MF_ENABLED:MF_GRAYED)

#define MyCheckMenuItem(hMenu, wIDCheckItem, fCheck) \
    CheckMenuItem((hMenu),(wIDCheckItem),(fCheck)?MF_CHECKED:MF_UNCHECKED)

HWND ghwndMainApp;
HANDLE ghInst;
HANDLE ghSolverThread = NULL;
HANDLE ghSolverThread2 = NULL;
HANDLE ghSolverThread3 = NULL;
DWORDLONG gnGameNumber = 0xff0000000 ;
DWORDLONG gnOGameNumber = 0xff0000000 ;
int	FAR gnWidth, gnHeight, gnDefWidth, gnDefHeight;
int	FAR gnNorWidth, gnNorHeight, gnRedWidth, gnRedHeight;
INT gnToolbar;
HBRUSH ghBGBrush;
UCHAR gszWindowName[40];
WINDOWPLACEMENT gwndpl;
BOOL gbSolver = FALSE;
BOOL gbSolver2 = FALSE;
BOOL gbSolver3 = FALSE;
BOOL gbS2Hot = FALSE ;
BOOL gbS3Hot = FALSE ;
BOOL gbMessages;		//  got from registry
BOOL gbFastUndo;
BOOL gbReduced;
BOOL gbHumanPlaying ;
INT gnMaxRandGame;
CHAR gszCurDir[MAXSTRING];
INT gnLoadMoves;
INT gnFCRed, gnFCGreen, gnFCBlue, gnBGRed, gnBGGreen, gnBGBlue;

extern HPEN ghPenF;

PRIVATE HWND ghwndStatus;
PRIVATE HWND ghwndTool;
PRIVATE HANDLE ghaccelTbl;              // Accelerator table handle.
BOOL gbGameOn = FALSE;
BOOL gbStarted = FALSE;
PRIVATE BOOL gbFindCards = FALSE;
BOOL gbSupermove = TRUE;
BOOL gbLogging = TRUE;
BOOL gbProAids = FALSE;
BOOL gbStatus = TRUE;
BOOL gbTool = TRUE;
BOOL gbSpider = FALSE ;
INT SCUser = 0 ;
INT gnDblclkMode = 0 ;

char szPresortCS[3] ;
INT gnSolveS, gnMaxTimeS, gnMaxHandsS ;
BOOL gbFastSolve ;

PRIVATE BOOL MainInit(HANDLE hInstance, INT nCmdShow);
PRIVATE VOID InitMenu(HMENU hmenu);
PRIVATE LRESULT MainCommand(HWND hwnd, INT nCmd, INT nNotifyCode);
PRIVATE LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
PRIVATE BOOL CreateSolverThread (HWND hwnd);
#ifdef SOLVEVAL
PRIVATE BOOL CreateSolverThread2 (HWND hwnd);
PRIVATE BOOL CreateSolverThread3 (HWND hwnd);
#endif
PRIVATE LONG APIENTRY StatusWndProc (HWND hwnd, UINT message, DWORD wParam, LONG lParam);
PRIVATE VOID CreateStatusWindow (HWND hwnd);
BOOL TestQuit(HWND hwnd) ;
extern BOOL gbSearchF, gbSearchF2, gbSearchF3, gbSearchFC ;
extern BOOL SearchFNxtMove(HWND) ;
extern BOOL SearchFNxtGame(HWND) ;
extern VOID SearchFChk1Start(HWND) ;
extern VOID SearchFChk2Start(HWND) ;
extern VOID SearchFChk3Start(HWND) ;
extern BOOL SearchFCNxtMove(HWND) ;
#ifdef SOLVEVAL
extern char szPatMode[] ;
extern char cPatMode ;
extern int result ;
#endif
INT SearchFph ;
//#define MEMSTAT 1
#ifdef MEMSTAT
MEMORYSTATUS MemStat ;
char szTempM[50] ;
#endif
char lpszSolvEdition[40] ;
PRIVATE CHAR szTemp[40] ;

DWORDLONG gnSGameNo ;
BOOL gbFCSTest ;

/*****************************************************************************\
* WinMain
\*****************************************************************************/
INT WINAPI WinMain (
    HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    LPSTR lpCmdLine,
    INT nCmdShow)
{
    MSG msg;
	char szTemp[12] ;
    if (!MainInit (hInstance, nCmdShow))
        return FALSE;

// get game number from command line

	strncpy(szTemp, lpCmdLine, 10) ;
	szTemp[10] = 0 ;
	if (isdigit(szTemp[0]))
		gnGameNumber = CvGameNo (szTemp) ;
	else
		gnGameNumber = 0xff0000000 ;
	if (gnGameNumber < 0xf00000000)
	{
		MainStartGame (TRUE);
	}

    /*
     * Polling messages from event queue
     */

    while (GetMessage (&msg, NULL, 0, 0))
    {
        if (!TranslateAccelerator(ghwndMainApp, ghaccelTbl, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    if (IsWindow(ghwndMainApp))
    {
        if (DestroyWindow(ghwndMainApp))
        {
            ghwndMainApp = NULL;
        }
    }

    return (INT) msg.wParam;
}

/*****************************************************************************\
*
* Arguments:
*   HANDLE hInstance - handle to the instance of Main.
*   INT nCmdShow - show the window?
*
* Returns:
*   TRUE if successful, FALSE otherwise.
*
\*****************************************************************************/
PRIVATE BOOL MainInit (HANDLE hInstance, INT nCmdShow)
{
    WNDCLASS wc;

	CHAR szTemp[115] ;
	CHAR szUserQuery1[] = "The current user for statistical purposes is:\n\n          " ;
	CHAR szUserQuery2[] = "\n\n          Is this correct?" ;
	INT i, j ;

    ghInst = hInstance;

    if (!(ghaccelTbl = LoadAccelerators(ghInst, "main")))
	{
		ShowLastError (0, "ERROR_LOADACCELERATORS");
		return FALSE;
	}

    ReadRegistry();

    lstrcpy(gszWindowName, LoadResourceString (IDS_APPLICATION_NAME));

	// register main window class

	ghBGBrush = CreateSolidBrush (RGB(gnBGRed, gnBGGreen, 
									  gnBGBlue));

    wc.style          = CS_BYTEALIGNCLIENT | CS_DBLCLKS;
//    wc.style          = CS_BYTEALIGNCLIENT;
    wc.lpfnWndProc    = MainWndProc;
    wc.cbClsExtra     = 0;
    wc.cbWndExtra     = 0;
    wc.hInstance      = hInstance;
    wc.hIcon          = LoadIcon(hInstance, MAINAPPNAME);
    wc.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground  = NULL;  // handled by us
    wc.lpszMenuName   = MAINAPPNAME;
    wc.lpszClassName  = MAINCLASSNAME;

    if (!RegisterClass(&wc))
	{
		ShowLastError (0, "ERROR_REGISTERCLASS Main");
		return FALSE;
	}

    ghwndMainApp = CreateWindow (MAINCLASSNAME, 
		gszWindowName,
        WS_OVERLAPPEDWINDOW, 0, 0, 0, 0,
        NULL, // handle to parent
		NULL, // handle to menu
		hInstance, // handle to instance
		NULL);

    if (!ghwndMainApp)
	{
		ShowLastError (0, "ERROR_CREATEWINDOW");
		return FALSE;
	}
	
	// register status window class

    wc.style            = CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc      = (WNDPROC) StatusWndProc;
    wc.hIcon            = NULL;
    wc.hCursor          = LoadCursor (NULL, IDC_ARROW);
    wc.hbrBackground    = (HBRUSH) (COLOR_BTNSHADOW);
    wc.lpszMenuName     = NULL;
    wc.lpszClassName    = STATUSCLASSNAME;

    if (!RegisterClass(&wc))
	{
		ShowLastError (0, "ERROR_REGISTERCLASS Status");
		return FALSE;
	}

	wc.style = 0;
	wc.lpfnWndProc = (WNDPROC) ToolBarWndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = ghInst;
	wc.hIcon = NULL;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = GetStockObject(LTGRAY_BRUSH);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = TEXT("ToolBar");
	
    if (!RegisterClass(&wc))
	{
		ShowLastError (0, "ERROR_REGISTERCLASS Tool");
		return FALSE;
	}

    if (nCmdShow != SW_SHOWNORMAL)
        gwndpl.showCmd = nCmdShow;

	if (!SetWindowPlacement(ghwndMainApp, &gwndpl))
	{
		ShowLastError (ghwndMainApp, "ERROR_SETWINDOWPLACEMENT");
		return FALSE;
	}
	if (gbStatus)
	{
		CreateStatusWindow (ghwndMainApp);
		StatusOut ("Select Game");
	}
	if (gbTool)
	{
	ghwndTool = InitTB (ghwndMainApp);
	gnToolbar = TOOLBARHEIGHT;
	}
	else
		gnToolbar = 0 ;
#ifndef SOLVEVAL
	lstrcpy(lpszSolvEdition, "FcPro") ;
#else
	lstrcpy(lpszSolvEdition, "FcPro -- Solver Evaluation Edition") ;
#endif
	SendMessage(ghwndMainApp, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)lpszSolvEdition) ;
	GetCurrentDirectory (MAXSTRING, gszCurDir);

   /* Seed the random-number generator with current time so that
    * the numbers will be different every time we run. - for 
	* picking random game numbers
	*/
			
	srand ((unsigned) time (NULL));

	for (i = 0 ; i < NUMSTATUSERS ; i++)
		StatsMU.Stats[i].CurrW = StatsMU.Stats[i].CurrL = 0 ;  //Initalize current statistics
	if (StatsMU.StatAlert)
		return TRUE;
	j = 0 ;
	for (i = 0 ; i < NUMSTATUSERS ;	i++)
	{
		if (isalpha(StatsMU.Stats[i].UserName[0]))
			j++ ;
	}
	if (j && !StatsMU.StatEnbl)
	{
	if (Message (ghwndMainApp, MB_ICONQUESTION | MB_YESNO | MB_DEFBUTTON2,
				"Statistics are disabled ------ Is this OK?") != IDYES)
			MyDialogBox(ghwndMainApp, IDD_STATISTICS, StatisticsDlgProc) ;				
		return TRUE;
	}
	if (j > 1)
	{
		lstrcpy(szTemp, szUserQuery1) ;
		lstrcat(szTemp, StatsMU.Stats[StatsMU.CurStatUser].UserName) ;
		lstrcat(szTemp, szUserQuery2) ;
		if (Message (ghwndMainApp, MB_ICONQUESTION | MB_YESNO |	MB_DEFBUTTON2,szTemp)
							!= IDYES)
			MyDialogBox(ghwndMainApp, IDD_STATISTICS, StatisticsDlgProc) ;				
	}
	return TRUE;
}

/*****************************************************************************\
*
* Arguments:
*    HWND hwnd - handle to the Main window
*    UINT msg - message
*    WPARAM wParam - message parameter
*    LPARAM lParam - message parameter
*
* Returns:
*   The value that the window proc should return, based on the processing
*   of the specific WM_COMMAND message received.
\*****************************************************************************/
PRIVATE LRESULT CALLBACK MainWndProc (
    HWND hwnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam)
{
	PAINTSTRUCT		pnt;
	// BRUCE: START
	//static HANDLE	hmodCards;
	HMODULE hmodCards = NULL;
	// BRUCE: END

    switch (msg)
    {
        case WM_CREATE:
			// load cards.dll
			// BRUCE: START
			hmodCards = LoadLibrary("Cards.dll");
			if (!hmodCards) {
  				ShowLastError (hwnd, "ERROR_CANT_LOAD_DLL");
				return (-1);
			} 

			// Initialize cards.dll function pointers
		    (FARPROC) CdtAnimate = GetProcAddress (hmodCards, "cdtAnimate");
		    (FARPROC) CdtDraw	 = GetProcAddress (hmodCards, "cdtDraw");
		    (FARPROC) CdtDrawExt = GetProcAddress (hmodCards, "cdtDrawExt");
		    (FARPROC) CdtInit    = GetProcAddress (hmodCards, "cdtInit");
		    (FARPROC) CdtTerm    = GetProcAddress (hmodCards, "cdtTerm");

/*
			if (!(hmodCards = LoadLibrary("cards")))
			{
  				ShowLastError (hwnd, "ERROR_CANT_LOAD_DLL");
				return (-1);
			}

		    CdtTerm    = (TERMPROC)    GetProcAddress (hmodCards, "cdtTerm");
		    CdtAnimate = (ANIMATEPROC) GetProcAddress (hmodCards, "cdtAnimate");
		    CdtDrawExt = (DRAWEXTPROC) GetProcAddress (hmodCards, "cdtDrawExt");
		    CdtDraw	   = (DRAWPROC)	   GetProcAddress (hmodCards, "cdtDraw");
		    CdtInit    = (INITPROC)	   GetProcAddress (hmodCards, "cdtInit");
*/
			// BRUCE: END
			if (CdtInit)
			{
			(CdtInit) (&gnDefWidth, &gnDefHeight);
			if (!gnNorWidth || !gnNorHeight ||
					!gnRedWidth || !gnRedHeight)
				{
				// read from registery was valid - resetgnNorWidth  = gnRedWidth  = gnDefWidth;
					gnNorHeight = gnRedHeight = gnDefHeight;
				}

				// setup current

				if (gbReduced)
				{
					gnWidth  = gnRedWidth;
					gnHeight = gnRedHeight;
				}
				else
				{
					gnWidth  = gnNorWidth;
					gnHeight = gnNorHeight;
				}
			}
			else
			{
				ShowLastError (hwnd, "ERROR_GETPROCADDRESS");
			return (-1);
			}
			FreeCellDealInit ();
			break;

        case WM_INITMENU:
            if (GetMenu (hwnd) == (HMENU) wParam)
                InitMenu ((HMENU) wParam);
            break;

        case WM_COMMAND:
            return MainCommand (hwnd, LOWORD(wParam), HIWORD(wParam));
			break;

		case WM_PAINT:
			if (BeginPaint (hwnd, &pnt) != NULL)
			{
				if (pnt.fErase)
				{
					FillRect (pnt.hdc, &pnt.rcPaint, ghBGBrush);
				}
				
				ShowHand (&pnt);
				ShowSolution (&pnt, (HFILE) NULL, (LPSTR) NULL, FALSE);

			}
		   	EndPaint (hwnd, &pnt);
			break;

		case WM_SIZE:
			{
				WORD        wCx;
				int         iCyText;

				/*
				 * Size the status window to fit into the new client area size.
				 */

				iCyText = GetWindowLong (ghwndStatus, GWL_USERDATA);
				wCx = (WORD) (HIWORD(lParam) - iCyText);

				MoveWindow(ghwndStatus,
				   0,
				   wCx,
				   LOWORD(lParam),
				   iCyText,
				   TRUE);
			}
			break;

		case WM_LBUTTONDOWN:
			if (gbStarted)
			{
				// send click back to this function, but
				// as a char. this makes playback and 
				// normal play go thru the same routine
				PostMessage (hwnd, WM_USER+101, 
							(WORD) RcvdLeftButtonDown (LOWORD(lParam), HIWORD(lParam)),
							0L);
//				PostMessage (hwnd, WM_CHAR, wParam, 0L);
			}
			break;
//   This chain was once inserted in effort to quell resource leak, cause of which was later found.
//		Eliminated 12/1/01;  Should be tested for resource leak.  Keeping 101-103 reserved in case later needed
		case WM_USER+101:
			if (gbStarted)
			{
				// send click back to this function, but
				// as a char. this makes playback and 
				// normal play go thru the same routine
//				PostMessage (hwnd, WM_USER+102, wParam, 0L);
				PostMessage (hwnd, WM_CHAR, wParam, 0L);
			}
			break;
/*
		case WM_USER+102:
			if (gbStarted)
			{
				// send click back to this function, but
				// as a char. this makes playback and 
				// normal play go thru the same routine
				PostMessage (hwnd, WM_USER+103, wParam, 0L);
			}
			break;

		case WM_USER+103:
			if (gbStarted)
			{
				// send click back to this function, but
				// as a char. this makes playback and 
				// normal play go thru the same routine
				PostMessage (hwnd, WM_CHAR, wParam, 0L);
			}
			break;
*/
		case WM_USER+104:  // Start FIMP search
			SetTimer(hwnd, 1, 20, NULL) ;  //Initial start only
//			SetTimer(hwnd, 1, 1120, NULL) ;  //Initial start only
			SearchFNxtGame(hwnd) ;  //Search for FIMP 
			PostMessage(hwnd, WM_COMMAND, ID_SOLVEFAST, 0L) ;
			break;

		case WM_USER+105:  // Game end signal
			if (gbFCSTest)
			{
				if (gnGameNumber < (gnSGameNo + 100))
					PostMessage(hwnd, WM_COMMAND, ID_SOLVEFAST2FULL, 0L) ;
				else
					gbFCSTest = FALSE ;
			}
			if (!gbSolver)
				SearchFph = 1;
			break;

		case WM_USER+106:  // Start FIMP search for solver 2
			SetTimer(hwnd, 1, 20, NULL) ;  //Initial start only
			SearchFNxtGame(hwnd) ;  //Search for FIMP 
			PostMessage(hwnd, WM_COMMAND, ID_SOLVEFAST2, 0L) ;
			break;

		case WM_USER+107:  // Start FIMP search for solver 3
			SearchFNxtGame(hwnd) ;  //Search for FIMP 
			PostMessage(hwnd, WM_COMMAND, ID_SOLVEFAST3, 0L) ;
			break;

		case WM_USER+108:  // Start Single-game FIMP search for solver 1
			SetTimer(hwnd, 1, 20, NULL) ;  //Initial start only
			gnMaxTime = 2 ;
			if (SearchFCNxtMove(hwnd)) 				  //Search for FIMP 
				PostMessage(hwnd, WM_COMMAND, ID_SOLVEFAST, 0L) ;
			else
			{
				gbSearchF = gbSearchFC = FALSE ;
				KillTimer(hwnd, 1) ;
			}
			break;

		case WM_USER+109:  // Start FIMP search for solver 2
			SetTimer(hwnd, 1, 20, NULL) ;  //Initial start only
			gnMaxTime = 2 ;
			if (SearchFCNxtMove(hwnd)) 				  //Search for FIMP 
				PostMessage(hwnd, WM_COMMAND, ID_SOLVEFAST2, 0L) ;
			else
			{
				gbSearchF2 = gbSearchFC = FALSE ;
				KillTimer(hwnd, 1) ;
			}
			break;
#ifdef SOLVEVAL
		case WM_USER+110:  // Start FIMP search for solver 3
			SetTimer(hwnd, 1, 20, NULL) ;  //Initial start only
//			gnMaxTime = 2 ;
			cPatMode = 'X' ;
			if (SearchFCNxtMove(hwnd)) 				  //Search for FIMP 
				PostMessage(hwnd, WM_COMMAND, ID_SOLVEFAST3, 0L) ;
			else
			{
				gbSearchF3 = gbSearchFC = FALSE ;
				KillTimer(hwnd, 1) ;
			}
			break;
#endif
		case WM_RBUTTONDOWN:
			// right mouse click shows card
			if (TestSolver())  // or aborts solver hand
			  break ;
			pnt.hdc = GetDC (hwnd);
			pnt.rcPaint.bottom = (LONG) NULL; // so ShowCard () always does... show the card!
			ShowBuriedCard (&pnt, LOWORD(lParam), HIWORD(lParam));
			break;

		case WM_RBUTTONUP:
			// right mouse click un shows card
			HideBuriedCard ();
			break;

		case WM_LBUTTONDBLCLK:
#ifdef MEMSTAT
		GlobalMemoryStatus(&MemStat) ;
		wsprintf(szTempM, "c1AP p-%li  a-%li", MemStat.dwAvailPhys, MemStat.dwAvailVirtual);
		MainMessage(szTempM) ;
#endif
			if (gbGameOn && gnDblclkMode)
			{
				GotDoubleClick (hwnd, RcvdLeftButtonDown (LOWORD(lParam), HIWORD(lParam)));
			}
			break;

		case WM_MOUSEMOVE:
			if (gbFindCards)
			{
				gbFindCards = FALSE;
				InvalidateMain (NULL);
			}
			break;

		case WM_CHAR:
			GotChar (hwnd, (CHAR) wParam);
			break;

		case WM_KEYDOWN:
			TestSolverA(LOWORD(wParam)) ;
			if (wParam == VK_NEXT)
			{
			    PostMessage (hwnd, WM_CHAR, (WORD) VK_TAB, 0);
			}
			if ((wParam == VK_HOME) || (wParam == VK_END))
			{
			    PostMessage (hwnd, WM_CHAR, (WORD) wParam, 0);
			}
			break;

		case WM_USER+100:

			// for animation options to work we need playback 
			// from the same thread
			FCSolvePlay (hwnd);
		    gbSolver2 = gbSolver3 = FALSE ;   // In case set
			break;

		case WM_TIMER:
			if (!gbSolver && !gbSolver2 && !gbSolver3)
			{
				if (SearchFph == 0)
				{
				if (!gbSearchFC && !gbS3Hot && !gbS2Hot) 
				{
#ifdef SOLVEVAL
					if (!gbSearchF3 || (result == 0) || (cPatMode == 'E'))
#else
					if (!gbSearchF3)
#endif
					{
						if (!SearchFNxtMove(hwnd))	
						{
						SearchFph = 1 ;
						break ;
						}
					}
				}
				if (gbSearchFC || gbS3Hot)
				{
#ifdef SOLVEVAL
					if (!gbSearchF3 || (result == 0) || (cPatMode == 'E'))
#else
					if (!gbSearchF3)
#endif
					{
					if (!gbS3Hot)
						if (!SearchFCNxtMove(hwnd))
							SearchFph = 1 ;
					}
				}
				}
				else 
				{
				if (SearchFph == 1)
				{
					SearchFph = 0 ;
					if (gbSearchFC || (SearchFNxtGame(hwnd) == 0))
					{
					if (gbSearchFC)
					{
						gbStarted = TRUE ;
						gbSearchF = gbSearchF2 = gbSearchF3 = gbSearchFC = FALSE ;
					}
						KillTimer(hwnd, 1) ;
						gbStarted = TRUE ;
						break ;
					}
				}
				}
			if (gbSearchF)
			{
				PostMessage(hwnd, WM_COMMAND, ID_SOLVEFAST, 0L) ;
			}
#ifdef SOLVEVAL
			if (gbSearchF2)
				PostMessage(hwnd, WM_COMMAND, ID_SOLVEFAST2, 0L) ;
			else
			{
			if (gbS2Hot)
				{
				if ((PresortC[0] == '3') && (result <= 0))
					{
					PresortC[0] == '5' ;
					PostMessage(hwnd, WM_COMMAND, ID_SOLVEFAST2, 0L) ;
					}
				else
					gbS2Hot = FALSE ;
				KillTimer(hwnd, 1) ;
				}
			}
			if (gbSearchF3 || gbS3Hot)
			{
				if ((cPatMode == 'S') && (result != 0))
				{
					cPatMode = 'E' ;
					szPatMode[0] = 'E' ;
				}
				else
				{
					if (result != 0)
					{
					cPatMode = 'S' ;
					szPatMode[0] = 'S' ;
					}
				}
				KillTimer(hwnd, 1) ;
				if (gbS3Hot && (cPatMode == 'S'))
					gbS3Hot = FALSE ;
				else
					PostMessage(hwnd, WM_COMMAND, ID_SOLVEFAST3, 0L) ;
			}
#endif
			}
			break ;
        
		case WM_CLOSE:
			// we cannot close if solver thread is alive
			if (!TestQuit(hwnd))
				break ;
			if (ghSolverThread || ghSolverThread2 || ghSolverThread3)
			{
				Message (hwnd, MB_ICONEXCLAMATION, 
						"Solve in progress.\nTry Stopping it and then quiting again.");
				return -1;
			}
#if DLL
			if (hmodCards)
			{
				(CdtTerm) ();
			}
			FreeLibrary (hmodCards);
#else
			cdtTerm ();
#endif 
            WriteRegistry (hwnd);
			if (gbLogging)
			{
				StopLogging ();
			}
            DestroyWindow(hwnd);
            break;

        case WM_DESTROY:
            PostQuitMessage(0);   /* Kill the main window */
            ghwndMainApp = NULL;
            break;

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }

    return 0;
}

BOOL TestQuit(HWND hwnd)
{
	if (!gbGameOn)
	{
		gbHumanPlaying = TRUE ;
		return TRUE ;
	}
	if (StatsMU.StatEnbl)
	{
		if (!StatsMU.StatQuitConfirm)
		{
			if (Message (hwnd, MB_ICONQUESTION | MB_YESNO |	MB_DEFBUTTON2,
				"Are you sure you want to quit this game?") != IDYES)
				return FALSE ;
		}
		StatsUpdate(FALSE) ;
	}
	gbHumanPlaying = TRUE ;
	return TRUE ;
}

/*****************************************************************************\
* InitMenu
*
* This function grays/enables and checks/unchecks the menu items
* appropriately for the given state.
*
* Arguments:
*   HMENU hmenu - The menu handle.
*
* Returns:
*   VOID
\*****************************************************************************/
PRIVATE VOID InitMenu (HMENU hmenu)
{
//    MyEnableMenuItem(hmenu, ID_GAME_RESTARTGAME,  gbGameOn);
    MyEnableMenuItem(hmenu, ID_GAME_RESTARTGAME,  gbStarted);
    MyEnableMenuItem(hmenu, ID_GAME_UNDO, (gnUserUndoType == UNDO_UNLIMITED) ||
								  ((gnUserUndoType == UNDO_LIMITED) && 
								   (gyPrevAction < UNDO1)));
    MyCheckMenuItem (hmenu, ID_WINDOW_REDUCED,    gbReduced);
}

/*****************************************************************************\
*
* Arguments:
*   HWND hwnd       - Window handle of the main app window.
*   INT nCmd        - Command value.
*   INT nNotifyCode - The notify code.
*
* Returns:
*   The value that the window proc should return, based on the processing
*   of the specific WM_COMMAND message received.
\*****************************************************************************/
PRIVATE LRESULT MainCommand (HWND hwnd, INT nCmd, INT nNotifyCode)
{
	PAINTSTRUCT		pnt;
	
	if ((nCmd >= TBID_ACE) && (nCmd <= TBID_KING))
	{
		// commands from the toobar

		FindCards (GetDC (hwnd), nCmd - TBID_ACE);
		gbFindCards = TRUE;
	}

    switch (nCmd)
    {
		// comands from the menu

		case ID_FILE_LOAD:
			if (!MyDialogBox (hwnd, IDD_LOADSOLUTION, 
								LoadSolutionDlgProc))
			{
				break;
			}
			// replay a file
			gbCustomGame = FALSE;
			LoadSolution (hwnd, gbLogging);
			if (gbGameOn)
				MainStartGame (FALSE);
			break;

		case ID_FILE_OPEN:
			// open notepad
			OpenSolution (hwnd);
			break;

		case ID_FILE_SAVE:
			if (!SaveSolutionFast (hwnd))
			{
				StatusOut ("Moves NOT Saved."); 
			}
			break;

		case ID_FILE_SAVEAS:
			if (!SaveSolution (hwnd))
			{
				StatusOut ("Moves NOT Saved."); 
			}
			break;

		case ID_FILE_SAVEAUTO:
			// save user and automoves
			if (!SaveAuto (hwnd))
			{
				StatusOut ("Moves NOT Saved."); 
			}
			break;

        case ID_FILE_EXIT:
            PostMessage (hwnd, WM_CLOSE, 0, 0);
            break;

        case ID_GAME_NEWGAME:
			if (!TestQuit(hwnd))
				break ;
			srand ((unsigned) time (NULL));
			switch (gnMaxRandGame)
			{
				case RAND_32THOU:
					rand() ;
					gnGameNumber = rand() % 32000;
					break;
				case RAND_1MILL:
					gnGameNumber = (rand() * rand()) % 1000000;
					break;
				case RAND_4BILL:
					gnGameNumber = ((DWORDLONG)rand() * (DWORDLONG)rand()
								* (DWORDLONG)rand()) % 0x200000000 ;
					break;
				default:													 					
					gnMaxRandGame = RAND_32THOU;
					gnGameNumber = (rand() * rand()) % 32000;
					break;
			}
			gbCustomGame = FALSE;
			MainStartGame (TRUE);
			break;

			case ID_GAME_SELECTGAME:
			if (!TestQuit(hwnd))
				break ;
			if (gnGameNumber == 0xff0000000)
				gnGameNumber = 1;
			if (!MyDialogBox (hwnd, IDD_SELECTGAME, 
								SelectGameDlgProc))
			{
				break;
			}

			// start game using gnGameNumber
			gbCustomGame = FALSE;
			MainStartGame (TRUE);
			break;

		case ID_GAME_NEXTGAME:
			if (!TestQuit(hwnd))
				break ;
			gnGameNumber++;
			if (gnGameNumber > 0x1ffffffff)
				gnGameNumber = 0 ;  // No wrap-around (otherwise creates exact copy
									// of game no. 0x80000000 (4294967292)
			gbCustomGame = FALSE;
			MainStartGame (TRUE);
			break;

        case ID_GAME_RESTARTGAME:
			// deal hand
			if (!TestQuit(hwnd))
				break ;
			MainStartGame (TRUE);
			break;

		case ID_GAME_CUSTOMGAME:
			// read game from file
			if (!TestQuit(hwnd))
				break ;
			if (!MyDialogBox (hwnd, IDD_CUSTOMGAME,
								CustomGameDlgProc))
			{
				break;
			}
			gbCustomGame = TRUE;
			MainStartGame (TRUE);
			break;

		case ID_GAME_UNDO:
			SendMessage (hwnd, WM_CHAR, VK_BACK, 0);
			break;

		case ID_GAME_REDO:
			SendMessage (hwnd, WM_CHAR, VK_TAB, 0);
			break;

		case ID_GAME_UNDO10:
			SendMessage (hwnd, WM_CHAR, 'u', 0);
			break;

		case ID_GAME_REDO10:
			SendMessage (hwnd, WM_CHAR, 'r', 0);
			break;

		case ID_GAME_UNDOALL:
			SendMessage (hwnd, WM_CHAR, VK_HOME, 0);
			break;

		case ID_GAME_REDOALL:
			SendMessage (hwnd, WM_CHAR, VK_END, 0);
			break;

		case ID_GAME_COPY:
			// clipbard
			if (CopySolution (hwnd))
			{
				StatusOut ("Copied to Clipboard");
			}
			break;

		case ID_OPTIONS_STATISTICS:
			MyDialogBox (hwnd, IDD_STATISTICS, StatisticsDlgProc)	;
			break ;
			
		case ID_NFCS_UP:
#ifndef FC89
			if (NUM_FCS < 7)
#else
			if (NUM_FCS < 9)
#endif
				NumFcs++ ;
					// show new number
				InvalidateMain (NULL);
				if (gbStarted)
					{
						// recalc vacant fc number
						FCPlayReInit (hwnd);
						// show possible new number
						InvalidateMain (NULL);
						// check if game is now lost
						GameLost ();
					}
				break ;

		case ID_NFCS_DOWN:
			if (NUM_FCS != 0)
				NumFcs-- ;
					// show new number
				InvalidateMain (NULL);
				if (gbStarted)
					{
						// recalc vacant fc number
						FCPlayReInit (hwnd);
						// show possible new number
						InvalidateMain (NULL);
						// check if game is now lost
						GameLost ();
					}
				break ;
		
		case ID_OPTIONS_SETTINGS:
		{
			BOOL bLogging = gbLogging;
			BOOL bSuperMove = gbSupermove;
			BOOL bProAids = gbProAids;
			BOOL bStatus = gbStatus;
			BOOL bTool = gbTool;
			BOOL bSpider = gbSpider ;
			INT numFcs = NumFcs;

			if (MyDialogBox (hwnd, IDD_SETTINGS, SettingsDlgProc))
			{
				// process changes
				// control
				if (gbLogging != bLogging)
				{	 
					if (gbLogging)
					{
						StartLogging (hwnd, NULL, 0);
					}
					else
					{
						StopLogging ();
					}
				}
				if (gbSupermove != bSuperMove)
				{
					if (gbSupermove)
					{	 
						EnableSupermove ();
					}
					else
					{
						DisableSupermove ();
					}
				}
				if (gbProAids != bProAids)
				{
					if (gbProAids)
					{	 
						EnableProAids ();
					}
					else
					{
						DisableProAids ();
					}
					InvalidateMain (NULL);
				}
				// freecells
				if (NumFcs != numFcs)
				{
					// show new number
					InvalidateMain (NULL);
					if (gbStarted)
					{
						// recalc vacant fc number
						FCPlayReInit (hwnd);
						// show possible new number
						InvalidateMain (NULL);
						// check if game is now lost
						GameLost ();
					}
				}
				// window
				if (gbStatus != bStatus)
				{
					if (gbStatus)
					{
						CreateStatusWindow (hwnd);
					}
					else
					{
						SendMessage (ghwndStatus, WM_CLOSE, 0, 0);
					}
				}
				if (gbTool != bTool)
				{
					if (gbTool)
					{
						ghwndTool = InitTB (hwnd);
						gnToolbar = TOOLBARHEIGHT;
					}
					else
					{
						SendMessage (ghwndTool, WM_CLOSE, 0, 0);
						gnToolbar = 0;
					}
					InvalidateMain (NULL);
				}
				if (gbSpider != bSpider)
				{
					ShowHand(&pnt) ;
					InvalidateMain (NULL);
				}
			}
		}
		break;

		case ID_OPTIONS_SOLVE:
			if (gbSpider)
			{
				MainMessage("Sorry, you're on your own.\nWe don't solve Spider for you.") ;
				break ;
			}
			if (gbSolver)
			{
				gbSolver = FALSE;
				StatusOut ("Solver Aborting...");
				UpdateWindow (ghwndMainApp);
			}
			else
			{
				if (MyDialogBox (hwnd, IDD_SOLVE, SolveDlgProc))
				{
					gbSolver = TRUE;
					StatusOut ("Solving1...");
					UpdateWindow (ghwndMainApp);

					if (gnSolve == SOLVE_RANGE)
					{
						CHAR szTemp[10+20];

						sprintf (szTemp, "Range #%s-#", 
							FmtGameNo(gnFirstGame));
						lstrcat(szTemp, FmtGameNo(gnLastGame)) ;
						SetMainCaption (ghwndMainApp, szTemp);
					}

					if (gnSolve == SOLVE_LIST)
					{
						CHAR szTemp[20];

						lstrcpy(szTemp, "Solving from list") ;
						SetMainCaption (ghwndMainApp, szTemp);
					}

					// create solver thread
					// create solver thread

					if (!CreateSolverThread (hwnd))
					{
						Message (hwnd, MB_ICONEXCLAMATION, 
									"Solver Thread will not start.");
					}
				}
			}
			break;
#ifdef SOLVEVAL
		case ID_OPTIONS_SOLVE2:
			if (gbSpider)
			{
				MainMessage("Sorry, you're on your own.\nWe don't solve Spider for you.") ;
				break ;
			}
			if (gbSolver || gbSolver2 || gbSolver3)
			{
				gbSolver = gbSolver2 = gbSolver3 = FALSE;
				StatusOut ("Solver Aborting...");
				UpdateWindow (ghwndMainApp);
			}
			else
			{
				if (MyDialogBox (hwnd, IDD_SOLVE2, Solve2DlgProc))
				{
					gbSolver2 = TRUE;
					StatusOut ("Solving2...");
					UpdateWindow (ghwndMainApp);
					if (gnSolve == SOLVE_RANGE)
					{
						CHAR szTemp[10+20];

						sprintf (szTemp, "Range #%s-#", 
							FmtGameNo(gnFirstGame));
						lstrcat(szTemp, FmtGameNo(gnLastGame)) ;
						SetMainCaption (ghwndMainApp, szTemp);
					}

					if (gnSolve == SOLVE_LIST)
					{
						CHAR szTemp[20];

						lstrcpy(szTemp, "Solving from list") ;
						SetMainCaption (ghwndMainApp, szTemp);
					}

					// create solver thread
					if (!CreateSolverThread2 (hwnd))
					{
						Message (hwnd, MB_ICONEXCLAMATION, 
									"Solver Thread will not start.");
					}
				}
			}
			break;

		case ID_OPTIONS_SOLVE3:
			if (gbSpider)
			{
				MainMessage("Sorry, you're on your own.\nWe don't solve Spider for you.") ;
				break ;
			}
			if (gbSolver || gbSolver2 || gbSolver3)
			{
				gbSolver = gbSolver2 = gbSolver3 = FALSE;
				StatusOut ("Solver Aborting...");
				UpdateWindow (ghwndMainApp);
			}
			else
			{
				if (MyDialogBox (hwnd, IDD_SOLVE3, Solve3DlgProc))
				{
					gbSolver3 = TRUE;
					StatusOut ("Solving3...");
					UpdateWindow (ghwndMainApp);

					if (gnSolve == SOLVE_RANGE)
					{
						CHAR szTemp[10+20];

						sprintf (szTemp, "Range #%s-#", 
							FmtGameNo(gnFirstGame));
						lstrcat(szTemp, FmtGameNo(gnLastGame)) ;
						SetMainCaption (ghwndMainApp, szTemp);
					}

					if (gnSolve == SOLVE_LIST)
					{
						CHAR szTemp[20];

						lstrcpy(szTemp, "Solving from list") ;
						SetMainCaption (ghwndMainApp, szTemp);
					}

					// create solver thread
					if (!CreateSolverThread3 (hwnd))
					{
						Message (hwnd, MB_ICONEXCLAMATION, 
									"Solver Thread will not start.");
					}
				}
			}
#endif
			break;

		case ID_WINDOW_CARDSIZE:
            MyDialogBox (hwnd, IDD_CARDSIZE, CardSizeDlgProc);
			// change size
			if (gbReduced)
			{
				gnWidth  = gnRedWidth;
				gnHeight = gnRedHeight;
			}
			else
			{
				gnWidth  = gnNorWidth;
				gnHeight = gnNorHeight;
			}
			// show new size
			InvalidateMain (NULL);
			break;

		case ID_WINDOW_REDUCED:
			if (gbReduced)
			{
				// change to normal
				gnWidth  = gnNorWidth;
				gnHeight = gnNorHeight;
				StatusOut ("Normal Window");
			}
			else
			{
				gnWidth  = gnRedWidth;
				gnHeight = gnRedHeight;
				StatusOut ("Reduced Window");
			}
			gbReduced = !gbReduced;
			// show new size
			InvalidateMain (NULL);
			break;

		case ID_WINDOW_COLORS:
            MyDialogBox (hwnd, IDD_WINDOWCOLORS, WindowColorsDlgProc);
		    DeleteObject ((HANDLE) ghBGBrush);
			ghBGBrush = CreateSolidBrush (RGB(gnBGRed, gnBGGreen, 
											  gnBGBlue));
		    DeleteObject ((HANDLE) ghPenF);
			ghPenF = CreatePen (PS_SOLID, YPOS_FC_SEPERATOR, 
							RGB(gnFCRed, gnFCGreen, gnFCBlue));
			// show new colors
			InvalidateMain (NULL);
			break;

		case ID_HELP_NEEDEDFEATURES:
            MyDialogBox(hwnd, IDD_NEEDEDFEATURES, HelpDlgProc);
            break;

		case ID_HELP_README:
		{
			UINT rtn;

			// open notepad with readme
//	        WinExec ("NotePad ReadMe.txt", SW_SHOWNORMAL);
			if ((rtn = WinExec ("winhlp32.exe fcpro.hlp", SW_SHOWNORMAL)) <= 31)
			{
				switch (rtn)
				{
					case 0:	
						Message (hwnd, MB_ICONEXCLAMATION, 
								 "The system is out of memory or resources.");
						break;
					case ERROR_BAD_FORMAT:
						Message (hwnd, MB_ICONEXCLAMATION, 
									"The HLP file is invalid.");
						break;
					case ERROR_FILE_NOT_FOUND:
						Message (hwnd, MB_ICONEXCLAMATION, 
									"The HLP file was not found.");
						break;
					case ERROR_PATH_NOT_FOUND:
						Message (hwnd, MB_ICONEXCLAMATION, 
									"The specified path was not found.");
						break;
					default:
						Message (hwnd, MB_ICONEXCLAMATION, 
									"Unknown Error %d.", rtn);
						break;
				}
			}
		}
		break;

        case ID_HELP_ABOUT:
            MyDialogBox(hwnd, IDD_ABOUT, HelpDlgProc);
            break;

        case ID_SOLVEFAST:
			{
			if (gbSolver || gbSolver2 || gbSolver3)
				break ;  // already in operation
			lstrcpy(szPresortCS, PresortC) ;
			gnSolveS = gnSolve ;
			gnMaxTimeS = gnMaxTime ;
			gnMaxHandsS= gnMaxHands ;
			gnSolve = SOLVE_RESULT ;
			gbFastSolve = TRUE ;
			gbSolver = TRUE ;
			if (!CreateSolverThread (hwnd))
				{
				Message (hwnd, MB_ICONEXCLAMATION, 
								"Solver Thread will not start.");
				}
 			break;
			}
#ifdef SOLVEVAL
        case ID_SOLVEFAST2:
			{
			if (gbSolver2 || gbSolver)
				break ;  // already in operation
			lstrcpy(szPresortCS, PresortC) ;
			if (!gbSearchF2)
			{
				if ((NumFcs > 0) && !gbS2Hot)
				{
					PresortC[0] = '3' ;
					gbS2Hot = TRUE ;
				}
				else
					PresortC[0] = '5' ;
			}
			gnSolveS = gnSolve ;
			gnMaxTimeS = gnMaxTime ;
			gnMaxHandsS= gnMaxHands ;
			gnSolve = SOLVE_RESULT ;
			gbFastSolve = TRUE ;
			gbSolver2 = TRUE ;
			if (!CreateSolverThread2 (hwnd))
				{
				Message (hwnd, MB_ICONEXCLAMATION, 
								"Solver Thread will not start.");
				}
 			break;
			}

        case ID_SOLVEFAST3:
			{
			if (gbSolver3 || gbSolver2 || gbSolver)
				break ;  // already in operation
			lstrcpy(szPresortCS, PresortC) ;
			gnSolveS = gnSolve ;
			if (!gbSearchF3)
				gbS3Hot = TRUE ;
			gnSolve = SOLVE_RESULT ;
			gbFastSolve = TRUE ;
			gbSolver3 = TRUE ;
			if (cPatMode != 'E')
			{
			szPatMode[0] = 'X' ;
			cPatMode = 'X' ;
			}
			if (!CreateSolverThread3 (hwnd))
				{
				Message (hwnd, MB_ICONEXCLAMATION, 
								"Solver Thread will not start.");
				}
 			break;
			}
/*
        case ID_SOLVEFAST2FULL:  //Temporary to test solver 2
			{
			if (gbSolver2 || gbSolver)
				break ;  // already in operation
			SendMessage(hwnd, WM_COMMAND, ID_GAME_NEXTGAME, 0L) ;
			lstrcpy(szPresortCS, PresortC) ;
			gnSolveS = gnSolve ;
			gnMaxTimeS = gnMaxTime ;
			gnMaxHandsS= gnMaxHands ;
			gnSolve = SOLVE_SOLUTION ;
			gbFastSolve = TRUE ;
			gbSolver2 = TRUE ;
			if (!CreateSolverThread2 (hwnd))
				{
				Message (hwnd, MB_ICONEXCLAMATION, 
								"Solver Thread will not start.");
				}
 			break;
			}

        case ID_SOLVEFAST2FULLR:  //Temporary to test solver 2
			{
			if (gbSolver2 || gbSolver)
				break ;  // already in operation
			gnSGameNo = gnGameNumber ;
			gbFCSTest = TRUE ;
			PostMessage(hwnd, WM_COMMAND, ID_SOLVEFAST2FULL, 0L) ;
			break;
			}
*/
#endif
		case ID_CHKFI1:
			SearchFChk1Start(hwnd) ;
			break ;

		case ID_CHKFI2:
			SearchFChk2Start(hwnd) ;
			break ;

		case ID_CHKFI3:
			SearchFChk3Start(hwnd) ;
			break ;

		}

    return 0;
}

VOID MainStartGame (BOOL bDeal)
{
	CHAR szTemp[15+CUSTOM_MAXSTRING_NAME];
	if (gbCustomGame)
	{
		// read custom file to get game name

		if (!CustomReadName (ghwndMainApp))
		{
			return;
		}

		// change window title
		sprintf (szTemp, "Custom Game '%s'", gszCustomGameName);
	}
	else
	{
		// change window title
//		sprintf (szTemp, "Game #%u", gnGameNumber);
		sprintf (szTemp, "Game #%s", FmtGameNo(gnGameNumber));
	}

	SetMainCaption (ghwndMainApp, szTemp);

	if (bDeal)
	{
		// deal hand
		FreeCellInit (TRUE);
		StatusOut ("Begin Play");
	}
	else
	{
		StatusOut ("Continue Play");
	}

	gbGameOn = gbStarted = TRUE;
	if (bDeal && gbLogging)
	{
		StopLogging ();
		StartLogging (ghwndMainApp, NULL, 0);
	}

	// check first if game is lost - zero FC games

	if (bDeal)
	{
		GameLost ();
	}
}

/*****************************************************************************\
*
* Arguments: 
*    none
*
* Returns:
\*****************************************************************************/
PRIVATE BOOL CreateSolverThread (HWND hwnd)
{
    DWORD Id;

    //
    // create another thread to handle the new queue
    //
	if (NUM_FCS > 8)
	{
		gbSolver = FALSE ;
		MainMessage("Maximum freecells for this solver is 8.") ;
		return TRUE ;
	}
    if (!(ghSolverThread = CreateThread (NULL, 0, 
							(LPTHREAD_START_ROUTINE) Free1Main,
							hwnd, STANDARD_RIGHTS_REQUIRED, &Id)))
	{
        return FALSE;
	}

    return TRUE;
}
#ifdef SOLVEVAL
PRIVATE BOOL CreateSolverThread2 (HWND hwnd)
{
    DWORD Id;

    //
    if (!(ghSolverThread2 = CreateThread (NULL, 0, 
							(LPTHREAD_START_ROUTINE) Free2Main,
							hwnd, STANDARD_RIGHTS_REQUIRED, &Id)))
	{
        return FALSE;
	}

    return TRUE;
}

PRIVATE BOOL CreateSolverThread3 (HWND hwnd)
{
    DWORD Id;

    //
    // create another thread to handle the new queue
    //
	if (NUM_FCS > 8)
	{
		gbSolver3 = FALSE ;
		MainMessage("Maximum freecells for this solver is 8.") ;
		return TRUE ;
	}
  if (!(ghSolverThread3 = CreateThread (NULL, 0, 
							(LPTHREAD_START_ROUTINE) Free3Main,
							hwnd, STANDARD_RIGHTS_REQUIRED, &Id)))
	{
        return FALSE;
	}

    return TRUE;
}
#endif
VOID InvalidateMain (LPRECT rc)
{
	if (!InvalidateRect (ghwndMainApp, rc, TRUE))
	{
		MainOut (0, 170, "FAILURE!", 0);
	}
}
VOID MainOut (INT x, INT y, CHAR *s, INT d)
{
	StringOut (GetDC (ghwndMainApp), x, y, s, d);
}
VOID MainMessage (CHAR *s)
{
	Message (ghwndMainApp, MB_ICONEXCLAMATION, s);
}
VOID UpdateMain (VOID)
{
	UpdateWindow (ghwndMainApp);
}

PRIVATE VOID CreateStatusWindow (HWND hwnd)
{
	ghwndStatus = CreateWindow (STATUSCLASSNAME, NULL,
			WS_BORDER | SS_LEFT | WS_CHILD | WS_VISIBLE,
			0, 0, 0, 0,
			hwnd,
			(HMENU) 1, // child window id
			ghInst,
			NULL);
}

PRIVATE LONG APIENTRY StatusWndProc (HWND hwnd, UINT message, DWORD wParam, LONG lParam)
{
    static HFONT hFont = (HFONT) NULL;

    switch (message)
    {
		case WM_CREATE:
		{
			LOGFONT    lf;
			HDC        hDC;
			HFONT      hOldFont;
			TEXTMETRIC tm;
			RECT       rect;
			LONG       lHeight;

			SystemParametersInfo(SPI_GETICONTITLELOGFONT, sizeof(lf), (PVOID) &lf, FALSE);

			hDC = GetDC(hwnd);
			// this is the height for 8 point size font in pixels
			lf.lfHeight = 8 * GetDeviceCaps(hDC, LOGPIXELSY) / 50;
			lf.lfWeight = FW_BOLD;

			hFont = CreateFontIndirect(&lf);
			hOldFont = SelectObject(hDC, hFont);
			/* put window at bottom */
			GetTextMetrics(hDC, &tm);
			GetClientRect(GetParent(hwnd), &rect);

			// base the height of the window on size of text
			lHeight = tm.tmHeight+6*GetSystemMetrics(SM_CYBORDER)+2;
			// saved the height for later reference
			SetWindowLong(hwnd, GWL_USERDATA, lHeight);
			SetWindowPos(hwnd, NULL,
				0, rect.bottom-lHeight,			// pos
				rect.right-rect.left, lHeight,  // size
				SWP_NOZORDER | SWP_NOMOVE);

			// SetWindowPos should work but it doesnt
			MoveWindow (hwnd, 
				0, rect.bottom-lHeight,			// pos
				rect.right-rect.left, lHeight,  // size
				TRUE);

			ReleaseDC(hwnd, hDC);
			break;
		}

		case WM_LBUTTONDOWN: 
			{
				PostMessage(GetParent(hwnd), WM_USER+0xa, (DWORD)0L, (LONG)0L);
				break;
			}

		case WM_DESTROY:
			if (hFont)
				DeleteObject(hFont);
			break;

		case WM_SETTEXT:
			DefWindowProc(hwnd, message, wParam, lParam);
			InvalidateRect(hwnd,NULL,TRUE);
			return 0L;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			RECT   rc;
			char   ach[128];
			int    len, nxBorder, nyBorder;
			HFONT  hOldFont = NULL;

			BeginPaint(hwnd, &ps);

			GetClientRect(hwnd,&rc);

			nxBorder = GetSystemMetrics(SM_CXBORDER);
			rc.left  += 9*nxBorder;
			rc.right -= 9*nxBorder;

			nyBorder = GetSystemMetrics(SM_CYBORDER);
			rc.top    += 3*nyBorder;
			rc.bottom -= 3*nyBorder;

			// 3D Text
			len = GetWindowText(hwnd, ach, sizeof(ach));

			SetBkColor(ps.hdc, GetSysColor(COLOR_BTNFACE));
			SetBkMode(ps.hdc, TRANSPARENT);
			SetTextColor(ps.hdc, RGB(0,0,0));

			if (hFont)
				hOldFont = SelectObject(ps.hdc, hFont);

			ExtTextOut(ps.hdc, rc.left+2*nxBorder, rc.top, ETO_CLIPPED,
				&rc, ach, len, NULL);

			SetBkMode(ps.hdc, OPAQUE);

			if (hOldFont)
				SelectObject(ps.hdc, hOldFont);

			EndPaint(hwnd, &ps);
		}
		return 0L;
    }

    return DefWindowProc(hwnd, message, wParam, lParam);
}

VOID StatusOut (CHAR *str)
{
	SetWindowText (ghwndStatus, str);
}

