// wilson callan 1998

#include "main.h"
#include "custom.h"
#include "freecell.h"
#include "log.h"
#include "fcsolve.h"
#include "settings.h"

extern CHAR gszCurDir[MAXSTRING];
				   
PRIVATE HFILE gfhLogFile;
PRIVATE INT   gnAttemptNumber;
COLORREF ColorS ;

VOID InvalidateSolution (BOOL move);
VOID UpdateLogFile (BOOL bNewAttempt);

extern FILE *fpFile ;
extern BOOL PlayLog2 ;

VOID LogInit (VOID)
{
//	gfhLogFile = 0;
	StopLogging() ;	//Change 1/21/01 -- prevented file closing when new game selected
	gnAttemptNumber = 1;
}

PRIVATE VOID BuildStdTopLine (CHAR *szTemp, BOOL bShowAuto)
{
	char szType[11];

	// NUPDATE - diaglog to get user name (pull default from registry)
    // check name length!  
	// dont allow ':' or '#' in name
	// ex: #7 <name> Attempt: 1 (fcpro)

	if (gbSolverLoaded)
	{
		strcpy (szType, " - Solved)");
	}
	else if (bShowAuto)
	{
		strcpy (szType, " - Auto)");
	}
	else
	{
		strcpy (szType, ")");
	}

	if (gbCustomGame)
	{
	if (!gbSpider)
		sprintf (szTemp, "#%s Attempt: %d NumFcs=%d (FCPro%s%s", 
					gszCustomGameName, gnAttemptNumber, NumFcs, 
					szType, CRLF);
	else
		sprintf (szTemp, "#%s Attempt: %d NumFcs=%d/Spider (FCPro%s%s", 
					gszCustomGameName, gnAttemptNumber, NumFcs, 
					szType, CRLF);
	}
	else
	{
	if (!gbSpider)
		sprintf (szTemp, "#%s Attempt: %d NumFcs=%d (FCPro%s%s", 
				FmtGameNo(gnGameNumber), gnAttemptNumber, NumFcs,
				szType, CRLF);
	else
		sprintf (szTemp, "#%s Attempt: %d NumFcs=%d/Spider (FCPro%s%s", 
				FmtGameNo(gnGameNumber), gnAttemptNumber, NumFcs,
				szType, CRLF);
	}
}

VOID StartLogging (HWND hwnd, LPTSTR szLoad, INT nAttemptNumber)
{
	CHAR  szFile[MAXSTRING];
	CHAR  szTemp[STD_MAX_CHARS_TOP_LINE];

	strncpy (szFile, gszCurDir, MAXSTRING-10);

	if (gbCustomGame)
	{
		sprintf (szTemp, "\\%slog.txt", gszCustomGameName);
	}
	else
	{
		sprintf (szTemp, "\\%slog.txt", FmtGameNo(gnGameNumber));
	}

	strcat (szFile, szTemp);

	// never overwrite, just append
	if ((gfhLogFile = _lopen(szFile, OF_READWRITE)) != HFILE_ERROR)
	{
		// File exists
		// Number of attempts is in the file, scan for the last 
		// ':' in the 'Attempt:' string
	    _llseek(gfhLogFile, 0, FILE_END);

		if (!FileScan (gfhLogFile, ':', -1))
		{
			Message (hwnd, 0, "No Attempt Number in log file (1).  Continuing...");
			gnAttemptNumber = 0;  // it will be inc
		}
		else
		{
			// found ':', scan in number of attempts

			_lread(gfhLogFile, szTemp, 10);	// assume 9999999999 tries max
			if (sscanf (szTemp, "%ld", &gnAttemptNumber) != 1)
			{
				Message (hwnd, 0, "No Attempt Number in log file (2).  Continuing...");
				gnAttemptNumber = 0;  // it will be inc
			}
		}

		//  goto end

	    _llseek(gfhLogFile, 0, FILE_END);
		sprintf (szTemp, CRLF);
		_lwrite(gfhLogFile, szTemp, strlen (szTemp));
	}
	else
	{
		if ((gfhLogFile = _lcreat(szFile, 0)) == HFILE_ERROR)
		{
			//put up a message here.
			sprintf (szTemp, "ERROR_LCREAT: '%s'", szFile);
			ShowLastError (hwnd, szTemp);
			return;
		}

		gnAttemptNumber = 0;  // it will be inc
	}

	if (nAttemptNumber > gnAttemptNumber)
	{
		// if passed in attempt number is bigger, use it
		// the load file passes in its attempt number
		gnAttemptNumber = nAttemptNumber;
	}

	// start log

	if (szLoad)
	{
		sprintf (szTemp, "Load '");
		strncat (szTemp, szLoad, 
					sizeof (szTemp) - 6 - 4 - 2 - 1);
		strcat (szTemp, "'...");
		strcat (szTemp, CRLF);
		_lwrite(gfhLogFile, szTemp, strlen (szTemp));
	}
	else
	{
		// goto new attempt number. if this is a playback (load)
		// then we will inc attempt number when user makes first
		// move

		gnAttemptNumber++;
	}

	// show what of solution we have so far

	ShowSolution (NULL, gfhLogFile, NULL, FALSE);

	// make sure attempt number is shown

	InvalidateSolution (FALSE);  // top line
}

VOID StopLogging (VOID)
{
	if (gfhLogFile)
	{
		_lclose(gfhLogFile);
		gfhLogFile = 0;
	}
}

VOID BackLog (INT nBack)
{
	CHAR szTemp[1+1];  // space+NULL

	if (gfhLogFile)
	{
		while (nBack--)
		{
			// move ontop of last char
			_llseek(gfhLogFile, -1, FILE_CURRENT);

			// if character here is space, cr or lf, dont count 
			// that as a backup

			_lread(gfhLogFile, szTemp, 1);

			if ((szTemp[0] == CR) || (szTemp[0] == LF) ||
				(szTemp[0] == ' '))
			{
				nBack++;
			}

			// move back ontop of last char again
			_llseek(gfhLogFile, -1, FILE_CURRENT);

			// ovewrite last char
			sprintf (szTemp, " ");
			_lwrite(gfhLogFile, szTemp, 1);

			// move ontop of last char
			_llseek(gfhLogFile, -1, FILE_CURRENT);
		}
	}
	if (PlayLog2)
	{
		while (nBack--)
		{
			// move ontop of last char
			fseek(fpFile, -1, FILE_CURRENT);

			// if character here is space, cr or lf, dont count 
			// that as a backup

			fread(szTemp, 1, 1, fpFile);

			if ((szTemp[0] == CR) || (szTemp[0] == LF) ||
				(szTemp[0] == ' '))
			{
				nBack++;
			}

			// move back ontop of last char again
			fseek(fpFile, -1, FILE_CURRENT);

			// ovewrite last char
			sprintf (szTemp, " ");
			fprintf(fpFile, szTemp, 1);

			// move ontop of last char
//			fseek(fpFile, -1, FILE_CURRENT);
		}
	}
}

//
// updates top line in log file after user makes
// a move in a playback (load) move set 
//
VOID UpdateLogFile (BOOL bNewAttempt)
{		
	if (bNewAttempt)
	{
		gnAttemptNumber++;
	}
	if (gfhLogFile)
	{
		/*
		 * backup to just before '#' and re-save all moves
		 */

		// we dont care if we cant find the '#', 
		// just overwrite whole file then

		FileScan (gfhLogFile, '#', -1);

		// backup 1 to get on '#'

		_llseek(gfhLogFile, -1, FILE_CURRENT);

		// save new solution

		ShowSolution (NULL, gfhLogFile, NULL, FALSE);
	}
}
VOID LogMove (CHAR ch)
{
	CHAR szTemp[5];
//	CHAR szTempa[50] ;
	if (gfhLogFile || PlayLog2)  
	{
		sprintf (szTemp, "%c", ch);

		if (!gSel.location)
		{
			// odd numbered move, so append space

			strcat (szTemp, " ");

			// test for end of line

			if ((gnUserMoves % STD_MOVES_PER_LINE) == 0)
				strcat (szTemp, CRLF);
		}
//sprintf(szTempa, "ch-%c sl-%d st-%s ",ch, strlen(szTemp), szTemp);
//MainMessage(szTempa) ;
		if (gfhLogFile)
			_lwrite(gfhLogFile, szTemp, strlen (szTemp));
//		if ((PlayMode2) && (szTemp[0] != 'v'))
		if (PlayLog2)
		{
			if (szTemp[0] == 'k')
			szTemp[0] = 'h' ;
//MainMessage(szTemp) ;
			fprintf(fpFile, szTemp);
		}
  }
}

VOID ShowSolution (LPPAINTSTRUCT pnt, HFILE fhFile, LPSTR pb,
					BOOL bShowAuto)
{
	CHAR szTemp[STD_MAX_CHARS_TOP_LINE];
	RECT sol;
	INT  move, ch, line ;
	HDC hdcs ;

#ifdef SHOWAUTODIAG
CHAR mflag ;
#endif

	if ((gnGameNumber < 0xf00000000)|| gbCustomGame)
	{
		sol.top = SOL_Y_OFFSET;
		sol.bottom = sol.top + SOL_Y_DELTA;
		sol.left = SOL_X_OFFSET;
		sol.right = sol.left+SOL_X_DELTA;
		hdcs = GetDC (ghwndMainApp);// new 1/20/01
		if (pnt || fhFile || pb)
	{
			if (pnt && !fhFile && !pb)
			{
				// patch to use Main DC.  pnt->hdc was not working printing
				// last character when i switched to only invalidate
				// one line
// Following removed 1/19/01; cause of crashing when run under Windows 98 or 2000
// Causes resource leak of one GDI object, even if immediately followed by a ReleaseDC
// Actuallly is needed as described above by Wilson.  Changed to use hdcs instead of 
// pnt->hdc, which seems to work as intended without resource leak.
//				pnt->hdc = GetDC (ghwndMainApp);

#if DEBUG
				MainOut (000, 450, "pnt->rcPaint.top", pnt->rcPaint.top);
				MainOut (200, 450, "bottom", pnt->rcPaint.bottom);
				MainOut (350, 450, "left", pnt->rcPaint.left);
				MainOut (450, 450, "right", pnt->rcPaint.right);
				MainOut (000, 500, "sol.top", sol.top);
				MainOut (200, 500, "bottom", sol.bottom);
				MainOut (350, 500, "left", sol.left);
				MainOut (450, 500, "right", sol.right);
#endif
				if (!ObjectInRect (&sol, &pnt->rcPaint))
				{
					// solution doesnt need to be repainted
					ReleaseDC(ghwndMainApp, hdcs) ;
					return;
				}
			}

			BuildStdTopLine (szTemp, bShowAuto);
			if (pnt)
			{
				// NUPDATE - allow user to select font size
//        	    ColorS = SetBkColor(pnt->hdc, 
        	    ColorS = SetBkColor(hdcs, 
				//			RGB(gnBGRed, gnBGGreen, gnBGBlue));
							RGB(255, 255, 255));
				// -2 for crlf
//				TextOut (pnt->hdc, sol.left, SOL_Y_OFFSET, 
				TextOut (hdcs, sol.left, SOL_Y_OFFSET, 
							szTemp,	strlen (szTemp) - 2);
//				SetBkColor(pnt->hdc,ColorS);
				SetBkColor(hdcs,ColorS);
			}

			if (fhFile)
			{
				_lwrite(fhFile, szTemp, strlen (szTemp));
			}
			if (pb)
			{
				lstrcpy (pb, szTemp);
				pb += strlen (szTemp);
			}

			// textout line by line to make it fast

			ch = 0;
			line = 1; // moves start on second line
		    for (move = 0; move < (gnSels/2); move++)
			{
				// the whole move should be valid since
				// this isnt called in the middle of a move
#ifdef SHOWAUTODIAG
bShowAuto = 1 ;
#endif
				if (!gMoves[move].bAutoMove || bShowAuto)
				{
  					szTemp[ch++] = gMoves[move].src.location;
					szTemp[ch++] = gMoves[move].dst.location;
#ifndef SHOWAUTODIAG
					szTemp[ch++] = ' ';
#else
				mflag = 'A' ;
				if (gMoves[move].bAutoMove)
				  mflag += 2 ;
				if (gMoves[move].bMoveID)
				  mflag++ ;
				szTemp[ch++] = mflag;
#endif
					if ((ch % STD_CHARS_PER_LINE) == 0)
					{
						// print full line

						szTemp[ch] = 0;
						strcat (szTemp, CRLF);

						if (pnt)
						{
//		        	    ColorS = SetBkColor(pnt->hdc, RGB(0xc0, 0xc0, 0xc0));
		        	    ColorS = SetBkColor(hdcs, RGB(0xc0, 0xc0, 0xc0));
//						TextOut (pnt->hdc, sol.left, 
						TextOut (hdcs, sol.left, 
									(line++)*CHARS_PER_YPOS + SOL_Y_OFFSET, 
									szTemp, ch);
//						SetBkColor(pnt->hdc, ColorS);
						SetBkColor(hdcs, ColorS);
					}
						if (fhFile)
						{
							_lwrite(fhFile, szTemp, strlen (szTemp));
						}
						if (pb)
						{
							lstrcpy (pb, szTemp);
							pb += strlen (szTemp);
						}

						ch = 0;
					}
				}
			}

			if (gSel.location)
			{
				// add selected card to last line
				szTemp[ch++] = gSel.location;
#if DEBUG
   			    MainOut (300, 550, "Sel", 0);
#endif
			}
			else
			{
#if DEBUG
   			    MainOut (300, 550, "NoS", 0);
#endif
			}

			szTemp[ch] = 0;

			// print partial line

			if (pnt)
			{
//				ColorS = SetBkColor(pnt->hdc, RGB(0xc0, 0xc0, 0xc0));
				ColorS = SetBkColor(hdcs, RGB(0xc0, 0xc0, 0xc0));
//				TextOut (pnt->hdc, sol.left, 
				TextOut (hdcs, sol.left, 
							line*CHARS_PER_YPOS + SOL_Y_OFFSET,  
							szTemp, ch);
//				SetBkColor(pnt->hdc, ColorS);
				SetBkColor(hdcs, ColorS);
#if DEBUG
				MainOut (000, 550, "gnSelsPart", gnSels);
   			    MainOut (150, 550, "line", line);
				MainOut (450, 550, szTemp, ch);
#endif
			}
			if (fhFile)
			{
				_lwrite(fhFile, szTemp, strlen (szTemp));
			}
			if (pb)
			{
				lstrcpy (pb, szTemp);
			}

		}
		ReleaseDC(ghwndMainApp, hdcs) ;
	}
}

VOID InvalidateSolution (BOOL move)
{
	RECT sol;

	// only draw new part of solution

	if (move)
	{
		sol.top    = SOL_Y_OFFSET + SOL_Y_DELTA - CHARS_PER_YPOS;
		sol.bottom = sol.top + CHARS_PER_YPOS;
		sol.left   = SOL_X_OFFSET;
		sol.right  = sol.left + SOL_X_DELTA;
	}
	else
	{
		// invalidate top line

		sol.top    = SOL_Y_OFFSET;
		sol.bottom = sol.top + CHARS_PER_YPOS;
		sol.left   = SOL_X_OFFSET;
		sol.right  = sol.left + SOL_X_DELTA;
	}

	InvalidateMain (&sol);
}

