// wilson callan 1997, 1998

#include "main.h"
#include "settings.h"
#include "freecell.h"
#include "fcplay.h"
extern BOOL gbSearchF, gbSearchF2, gbSearchF3, gbSearchFGend ;
extern SearchFNxtGame(HWND) ;

extern BOOL gbFCSTest ;

// game lost/won detection
VOID GameLost (VOID)
{
	BOOL move;
	BYTE tcol, scol;
	BYTE yCol, yPos;
	char Ftofs, Fsofs ;
	// check if game won! 
	// (fixes problem in 0 fc game lost detection
	//  since 0 fc game has no vacant fcs)
//MessageBox(GetFocus(), "GL", "GL", MB_OK) ;
	yCol = 0;
	if (!gbSpider)
	{
		for (yPos = NUM_FCS; yPos < (NUM_FCS + NUM_SUITS); yPos++)
	{
		if (card[yCol][yPos] == EMPTY)
		{
			// cant win with empty homecells
			break;
		}
		else if (VALUE(card[yCol][yPos]) != KING)
		{
			// cant win without king in homecell
			break;
		}
	}
	}
	else
	{	//Spider mode win test
		if (Cvac == 4)
		{
			for (yCol = 1 ; yCol < (MAXCOL) ; yCol++)
			{
				if ((card[yCol][0] == EMPTY) || ((VALUE(card[yCol][0]) == KING)
						&& ColLen[yCol - 1] == 13))
				{
					if (VALUE(card[yCol][0]) == KING)
					{
						for (yPos =	0 ; yPos < 6 ;
												yPos++) // only top seven cards need to  
						{							   // be tested
							if ((VALUE(card[yCol][yPos]) == 
								(VALUE(card[yCol][yPos + 1]) + 1)) &&
								(COLOUR(card[yCol][yPos]) != COLOUR(card[yCol][yPos+1])))
								continue ;
							else
								break ;
//								yCol = MAXCOL + 1 ;	  //force exits
						}
					if (yPos != 6)
						break ;
					}
				continue ;
				}
				else
					break ;
			}
		}
	}
	if ((!gbSpider && (yPos == (NUM_FCS + NUM_SUITS))) ||
			(gbSpider && (yCol	== (MAXCOL))))
	{
		StatsUpdate(TRUE) ;
		gbGameOn = FALSE ;
//		if (!gbSearchF && !gbSearchF2 && !gbSearchF3)
		if (!gbSearchF && !gbSearchF2 && !gbSearchF3 && !gbFCSTest)
		{
//			if (!gbFCSTest)
				MessageBox (GetFocus (), "You've won!","FCPRO", MB_OK) ;
		}
		else
			PostMessage(ghwndMainApp, WM_USER+105, 0, 0L) ;  //Signal end of game
		return;
	}

	if (!Fvac)
	{
		// there are no vacant freecells - could be 0 fc game! 

		move = 0;

		// look for fc and col moves

			for (tcol = 1 ; tcol < 9+NumFcs ; tcol ++)
			{
			// check all 8 columns + fcs as source
				for (scol = 1 ; scol < 9+NumFcs ; scol ++)
				{
				// check all columns and fcs as destination
#ifdef FC89
				Ftofs = Fsofs = 0 ;
				if ((NumFcs > 7) && (tcol > (7+NumFcs)))
					Ftofs = 3 ;
				if ((NumFcs > 7) && (scol > (7+NumFcs)))
					Fsofs = 3 ;
#endif
				if (scol < 9)
				{
					// check the columns as destination

					if (scol != tcol)
					{
						if (tcol < 9)
						{
							// check for col->col moves

							if (MakeMoveT ((char) (LOBYTE(tcol) + '0'), 
										   (char) (LOBYTE(scol) + '0')))
							{
							    move = 1 ;
							    break ;
						    }
						}
						else
						{
							// check for fc->col moves
#ifndef FC89
							if (MakeMoveT ((char) (LOBYTE(tcol) - 9 + 'a'), 
										   (char) (LOBYTE(scol) + '0')))
#else
							if (MakeMoveT ((char) (LOBYTE(tcol) - 9 + Ftofs + 'a'), 
										   (char) (LOBYTE(scol) + '0')))
#endif
							{
								move = 1 ;
								break ;
							}
						}
					}
				}
				else
				{
					// check the freecells as destination

					if (tcol < 9)
					{
						// check for col->fc moves
#ifndef FC89
						if (MakeMoveT ((char) (LOBYTE(tcol) + '0'), 
									   (char) (LOBYTE(scol) - 9 + 'a')))
#else
						if (MakeMoveT ((char) (LOBYTE(tcol) + '0'), 
									   (char) (LOBYTE(scol) - 9 + Fsofs + 'a')))
#endif
						{
							move = 1 ;
							break ;
						}
					}
					else
					{
						// check for fc->fc moves
						// (not relevant since these are now disabled)
//						if (MakeMoveT ((char) (LOBYTE(tcol) - 0 + 'a'), 
//								       (char) (LOBYTE(scol) - 9 + 'd')))
						if (MakeMoveT ((char) (LOBYTE(tcol) - 9 + 'a'), 
								       (char) (LOBYTE(scol) - 9 + 'a')))
						{
							move = 1 ;
							break ;
						}
					}
				}		
		    }
		}

		// look for home moves

        for (tcol = 1 ; tcol < 9+NumFcs ; tcol++)
		{
			// check all 8 columns + fcs as source
#ifndef FC89
			Ftofs = 0 ;
			if ((NumFcs > 7) && (tcol > (7+NumFcs)))
				Ftofs = 3 ;
#endif
			if (tcol < 9)
			{
				// check for col->hc moves
				if (MakeMoveT ((char) (LOBYTE(tcol) + '0'), 'h'))
				{
					move = 1 ;
					break ;
				}
			}
			else
			{
				// check for fc->hc moves
#ifndef FC89
				if (MakeMoveT ((char) (LOBYTE(tcol) - 9 + 'a'), 'h'))
#else
				if (MakeMoveT ((char) (LOBYTE(tcol) - 9 + Ftofs + 'a'), 'h'))
#endif
				{
					move = 1 ;
					break ;
				}
			}
		}
		
		if (!move)
		{
			MessageBox (GetFocus (),
						"You've lost.\nBetter luck next time!",
						"FCPRO", MB_OK) ;
			StatsUpdate(FALSE) ;
			gbGameOn = FALSE ;
			return;
		}
	}

	return;
}  

VOID FlourishCheck (VOID)
{
	INT  ColLenT[NUM_COLS];
	INT  FvacT, CvacT;
	CARD cardT[MAXCOL][MAXPOS]; 
	BYTE i, yCol, yPos;

	// make copies of all global stuff

	for (i = 0; i < NUM_COLS; i++)
	{
		ColLenT[i] = ColLen[i];
	}

	FvacT = Fvac;
	CvacT = Cvac;

	yCol = 0;

	for (yPos = 0; yPos < (NUM_FCS + NUM_SUITS); yPos++)
	{
		cardT[yCol][yPos] = card[yCol][yPos];
	}

	for (yCol = 1; yCol < MAXCOL; yCol++)
	{
		for (yPos = 0; yPos < MAXPOS; yPos++)
		{
			cardT[yCol][yPos] = card[yCol][yPos];

			if (card[yCol][yPos] == EMPTY)
			{
				break;
			}
		}
	}

	// call auto poster in test mode

	MoveAuto (TRUE);

	// examine results

	if ((Cvac == NUM_COLS) && (Fvac == NUM_FCS))
	{
		gbFlourish = TRUE;
	}

	// restore global junk

	for (i = 0; i < NUM_COLS; i++)
	{
		ColLen[i] = ColLenT[i];
	}

	Fvac = FvacT;
	Cvac = CvacT;

	yCol = 0;

	for (yPos = 0; yPos < (NUM_FCS + NUM_SUITS); yPos++)
	{
		card[yCol][yPos] = cardT[yCol][yPos];
	}

	for (yCol = 1; yCol < MAXCOL; yCol++)
	{
		for (yPos = 0; yPos < MAXPOS; yPos++)
		{
			card[yCol][yPos] = cardT[yCol][yPos];

			if (cardT[yCol][yPos] == EMPTY)
			{
				break;
			}
		}
	}
}

VOID StatsUpdate(BOOL result)
{
	if ((gnGameNumber == gnOGameNumber) || !gbHumanPlaying || !StatsMU.StatEnbl)
		return ;
	gbHumanPlaying = FALSE ;
	if (result)
	{
		StatsMU.Stats[SCUser].CurrW++ ;
		StatsMU.Stats[SCUser].TotalW++ ;
		if (StatsMU.Stats[SCUser].StreaksC >= 0)
		{
			StatsMU.Stats[SCUser].StreaksC++ ;
			if (StatsMU.Stats[SCUser].StreaksC > (int)StatsMU.Stats[SCUser].StreaksW)
				StatsMU.Stats[SCUser].StreaksW = abs(StatsMU.Stats[SCUser].StreaksC) ;
		}
		else
			StatsMU.Stats[SCUser].StreaksC = 1 ;
	}
	else
	{
		StatsMU.Stats[SCUser].CurrL++ ;
		StatsMU.Stats[SCUser].TotalL++ ;
		if (StatsMU.Stats[SCUser].StreaksC <= 0)
		{
			StatsMU.Stats[SCUser].StreaksC-- ;
			if (StatsMU.Stats[SCUser].StreaksC < -(int)StatsMU.Stats[SCUser].StreaksL)
				StatsMU.Stats[SCUser].StreaksL = abs(StatsMU.Stats[SCUser].StreaksC) ;
		}
		else
			StatsMU.Stats[SCUser].StreaksC = -1 ;
	}
	gnOGameNumber = gnGameNumber ;
	return ;
}
