// 1997, wilson callan

#ifndef FREECELL_H
#define FREECELL_H

#include "fchand.h"

#define NUM_FCS			(NumFcs)
#define NUM_SUITS		(4)
#define NUM_COLS		(8)
#define NUM_CARDS		(52)
#define NUM_GAMES		(1000000)

#define XPOS_CARD_SIZE	((UINT) gnWidth)
#define YPOS_CARD_SIZE	((UINT) gnHeight)

// freecell locations

#define XPOS_FC_SIZE	(XPOS_CARD_SIZE+XPOS_CARD_SEPERATOR)
#define XPOS_FC_START	(0)
#define XPOS_FC_END		(XPOS_FC_START + (XPOS_FC_SIZE*NUM_FCS) - 1)

#define YPOS_FC_SIZE	(YPOS_CARD_SIZE)
#define YPOS_FC_START	(gnToolbar)
#define YPOS_FC_END		(YPOS_FC_START + YPOS_FC_SIZE)

// homecell location

#define XPOS_HC_SIZE	(XPOS_CARD_SIZE+XPOS_CARD_SEPERATOR)
#define XPOS_HC_START	(XPOS_FC_END+1)
#define XPOS_HC_END 	(XPOS_HC_START + (XPOS_HC_SIZE*NUM_SUITS) - 1) 

#define YPOS_HC_SIZE	(YPOS_CARD_SIZE)
#define YPOS_HC_START	(gnToolbar)
#define YPOS_HC_END		(YPOS_HC_START + YPOS_HC_SIZE)

//
// column locations 
//

#define XPOS_CL_OFFSET	(0x0)
#define XPOS_CL_SIZE	(XPOS_CARD_SIZE+XPOS_CARD_SEPERATOR)

#define YPOS_CL_START			(YPOS_FC_END+1+YPOS_FC_SEPERATOR)
#define YPOS_CARD_VISIBLE_SIZE	(YPOS_CARD_VISIBLE)
#define YPOS_LAST_CARD_SIZE		(YPOS_CARD_SIZE)
#define YPOS_LAST_CARD_DELTA	(YPOS_LAST_CARD_SIZE - YPOS_CARD_VISIBLE_SIZE) 

// standard notation

#define STD_MAX_LINES		(50)
#define STD_MOVES_PER_LINE	(10)
#define STD_CARDS_PER_MOVE	(2)
#define STD_CARDS_PER_LINE	(STD_MOVES_PER_LINE * STD_CARDS_PER_MOVE)
#define STD_CHARS_PER_LINE	(STD_MOVES_PER_LINE * 3) // card,card,space
#define STD_MAX_CHARS_TOP_LINE	(60) // includes CFLF

#define AUTO_PER_MOVE		(10)

// display the solution

#define CHARS_PER_XPOS		(8)
#define CHARS_PER_YPOS		(20)
#define SOL_X_OFFSET		((NUM_COLS*(gnWidth+XPOS_CARD_SEPERATOR))+XPOS_CARD_SEPERATOR)
#define SOL_X_DELTA			(STD_MAX_CHARS_TOP_LINE*CHARS_PER_XPOS)
//#define SOL_Y_OFFSET		(gnToolbar)											
//#define SOL_Y_OFFSET	(gnToolbar + !gbSpider * (((NumFcs - 1)/4) * (gnHeight + YPOS_FC_SEPERATOR)))
#define SOL_Y_OFFSET	(gnToolbar + !gbSpider * ((NumFcs - 9) ? ((NumFcs - 1)/4) : 1) * (gnHeight + YPOS_FC_SEPERATOR))
#define SOL_Y_DELTA 		(((gnUserMoves/STD_MOVES_PER_LINE)+2)*CHARS_PER_YPOS)

// write solution to disk

#define CR				'\15'
#define LF				'\12'
#define CRLF			"\15\12"

// dispay the hand

#define YPOS_CARD_VISIBLE	(gnHeight/4)
#define	XPOS_CARD_SEPERATOR	(4)

#define YPOS_FC_SEPERATOR	(5)

#define NONE_SELECTED	(MAXPOS);

typedef struct std_card
{
	CHAR location;		// ascii
	INT	 column;		// cards array info
	INT	 position;

} STD_CARD;

typedef struct std_moves
{
	STD_CARD src;		// original
	STD_CARD dst;		// new
	BOOL     bAutoMove;
	BOOL     bMoveID;	// ID move sets

} STD_MOVES; 

// colors

#define FCRED	(0)
#define FCGREEN	(0)
#define FCBLUE	(255)
#define BGRED	(75)
#define BGGREEN	(125)
#define BGBLUE	(100)

// undo state machine

#define START		(0)
#define MOVE		(1)
#define REDO		(2)
#define UNDO1		(3)
#define UNDO2		(4)
#define UNDOING		(5)

VOID FreeCellInit (BOOL update);
CHAR RcvdLeftButtonDown (UINT xPos, UINT yPos);
BOOL RcvdRightButtonDown (UINT xPos, UINT yPos, BYTE *col, BYTE *pos);
VOID GotChar (HWND hwnd, CHAR ch);
CHAR AddMove (INT col, INT pos, BOOL bAutoPost);
VOID GotDoubleClick (HWND hwnd, CHAR ch);

extern STD_CARD gSel;
extern int  ColLen[NUM_COLS];
//extern CARD card[MAXCOL][MAXPOS];
#ifndef FC89
extern CARD card[MAXCOL + 4][MAXPOS];  //TEST
#else
extern CARD card[MAXCOL + 5][MAXPOS];  //TEST
#endif
extern INT Fvac, Cvac;
extern INT gnUserMoves;
extern INT gnSels; 
extern STD_MOVES gMoves[]; 
extern BOOL gbFlourish;
extern BYTE gyPrevAction;
#endif // FREECELL_H













