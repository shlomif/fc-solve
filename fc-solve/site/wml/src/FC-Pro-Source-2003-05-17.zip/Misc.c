
/******************************************************************************\
* wilson callan, copyright 1997
\******************************************************************************/

#include "main.h"
#include "settings.h"
#include "freecell.h"

extern BOOL gbMessages, gbFastUndo, gbReduced;

PRIVATE HKEY ghkeyMain = NULL;
PRIVATE CHAR gszMainAppKey[] = "Software\\WCallan\\FCPro";
PRIVATE CHAR gszKeyPosition[] = "Position";
PRIVATE CHAR gszKeyNorSize[] = "NorSize";
PRIVATE CHAR gszKeyRedSize[] = "RedSize";
PRIVATE CHAR gszKeyMessages[] = "Messages";
PRIVATE CHAR gszKeyFastUndo[] = "FastUndo";
PRIVATE CHAR gszKeyAnimate[] = "Animate";
PRIVATE CHAR gszKeyFCColor[] = "FCColor";
PRIVATE CHAR gszKeyBGColor[] = "BGColor";
PRIVATE CHAR gszKeyProAids[] = "ProAids";
PRIVATE CHAR gszKeyNumFCs[] = "NumFCs";
PRIVATE CHAR gszKeyUndoType[] = "UndoType";
PRIVATE CHAR gszKeyRandMax[] = "RandMax";
PRIVATE CHAR gszKeyLogging[] = "Logging";
PRIVATE CHAR gszKeyCdFndToolBar[] = "CFndTBar";
PRIVATE CHAR gszKeySolRange[] = "SRngFmt";
PRIVATE CHAR gszKeyStatus[] = "Status";
PRIVATE CHAR gszKeyStatistics[] = "Statistc";
PRIVATE CHAR gszKeyDblclk[] = "Dblclk";
PRIVATE CHAR gszKeySpider[] = "Spider";

PRIVATE BOOL ObjectInRect2D (INT x, INT xPlus, INT r, INT rPlus);

/*****************************************************************************\
* ReadRegistry
*
* Arguments:
*    none
*
* Returns:
*    VOID
\*****************************************************************************/
VOID ReadRegistry (VOID)
{
    DWORD dwType;
    DWORD cbData;
	char  szTemp[13];

    RegCreateKey (HKEY_CURRENT_USER, gszMainAppKey, &ghkeyMain);

    cbData = gwndpl.length = sizeof(gwndpl);
    if (!ghkeyMain || RegQueryValueEx(ghkeyMain, gszKeyPosition, NULL, 
		&dwType, (LPVOID) &gwndpl, &cbData) != ERROR_SUCCESS)
    {
        gwndpl.length = 0;
    }

    //
    // If the Main process is killed while the registry key is open, the
    //  position data can be indeterminant...  Here we catch the case that
    //  the reg. data is not good, and we set sensible defaults.
    //

    if (gwndpl.length != sizeof(gwndpl))
    {
        gwndpl.length = sizeof(gwndpl);
        gwndpl.flags = 0;
        gwndpl.showCmd = SW_SHOWNORMAL;
        gwndpl.ptMinPosition.x = 0;
        gwndpl.ptMinPosition.y = 0;
        gwndpl.ptMaxPosition.x = 0;
        gwndpl.ptMaxPosition.y = 0;
        gwndpl.rcNormalPosition.left = 10;
        gwndpl.rcNormalPosition.top = 10;
        gwndpl.rcNormalPosition.right = (LONG)
            10 + (GetSystemMetrics(SM_CXSCREEN) / 2) +
				 (GetSystemMetrics(SM_CXSCREEN) / 3);
        gwndpl.rcNormalPosition.bottom =
            10 + (GetSystemMetrics(SM_CYSCREEN) / 2);
    }

	// default size
	gbReduced = FALSE;

	// invalidate so we update it from cdtInit
    gnRedWidth = 0;
    gnRedHeight = 0;

    cbData = sizeof (szTemp) * sizeof (TCHAR);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeyRedSize, 
		NULL, &dwType, (LPVOID) szTemp, &cbData) 
		== ERROR_SUCCESS))
    {
		sscanf (szTemp, "%ld %ld %ld", &gnRedWidth, &gnRedHeight, 
									   &gbReduced);
    }

	// invalidate so we update it from cdtInit
    gnNorWidth = 0;
    gnNorHeight = 0;

    cbData = sizeof (szTemp) * sizeof (TCHAR);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeyNorSize, 
		NULL, &dwType, (LPVOID) szTemp, &cbData) 
		== ERROR_SUCCESS))
    {
		sscanf (szTemp, "%ld %ld", &gnNorWidth, &gnNorHeight);
    }

    cbData = sizeof (BOOL);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeyMessages, 
		NULL, &dwType, (LPVOID) &gbMessages, &cbData) 
		!= ERROR_SUCCESS))
    {
		// default to no messages?
        gbMessages = TRUE;
    }

    cbData = sizeof (BOOL);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeyProAids, 
		NULL, &dwType, (LPVOID) &gbProAids, &cbData) 
		!= ERROR_SUCCESS))
    {
		// default 
        gbProAids = TRUE;
    }

    cbData = sizeof (BOOL);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeyFastUndo, 
		NULL, &dwType, (LPVOID) &gbFastUndo, &cbData) 
		!= ERROR_SUCCESS))
    {
		// default
        gbFastUndo = FALSE;
    }

    cbData = sizeof (INT);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeyAnimate, 
		NULL, &dwType, (LPVOID) &gnAnimation, &cbData) 
		!= ERROR_SUCCESS))
    {
		// default
        gnAnimation = ANIMATE_ALL;
    }

    cbData = sizeof (INT);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeyNumFCs, 
		NULL, &dwType, (LPVOID) &NumFcs, &cbData) 
		!= ERROR_SUCCESS))
    {
		// default
        NumFcs = 4;
    }

    cbData = sizeof (INT);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeyUndoType, 
		NULL, &dwType, (LPVOID) &gnUserUndoType, &cbData) 
		!= ERROR_SUCCESS))
    {
		// default
        gnUserUndoType = UNDO_UNLIMITED;
    }

    cbData = sizeof (INT);
        RegSetValueEx(ghkeyMain, gszKeyUndoType, 0, REG_DWORD,
            (LPBYTE) &gnUserUndoType, sizeof(INT));

    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeyRandMax, 
		NULL, &dwType, (LPVOID) &gnMaxRandGame, &cbData) 
		!= ERROR_SUCCESS))
    {
		// default
        gnMaxRandGame = RAND_1MILL; // highest a person can recognize
    }

    cbData = sizeof (BOOL);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeyLogging, 
		NULL, &dwType, (LPVOID) &gbLogging, &cbData) 
		!= ERROR_SUCCESS))
    {
		// default
        gbLogging = TRUE;
    }

    cbData = sizeof (BOOL);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeyCdFndToolBar, 
		NULL, &dwType, (LPVOID) &gbTool, &cbData) 
		!= ERROR_SUCCESS))
    {
		// default
       gbTool = FALSE ;
    }

    cbData = sizeof (INT);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeySolRange, 
		NULL, &dwType, (LPVOID) &SolrSel, &cbData) 
		!= ERROR_SUCCESS))
    {
		// default
        SolrSel = 0;
    }

    cbData = sizeof (BOOL);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeyStatus, 
		NULL, &dwType, (LPVOID) &gbStatus, &cbData) 
		!= ERROR_SUCCESS))
    {
		// default
       gbStatus = TRUE ;
    }

    cbData = sizeof (INT);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeyDblclk, 
		NULL, &dwType, (LPVOID) &gnDblclkMode, &cbData) 
		!= ERROR_SUCCESS))
    {
		// default
       gnDblclkMode = 0 ;
    }

    cbData = sizeof (BOOL);
    if (!ghkeyMain || (RegQueryValueEx(ghkeyMain, gszKeySpider, 
		NULL, &dwType, (LPVOID) &gbSpider, &cbData) 
		!= ERROR_SUCCESS))
    {
		// default
       gbSpider = FALSE ;
    }

	gnFCRed   = FCRED;
	gnFCGreen = FCGREEN;
	gnFCBlue  = FCBLUE;

    cbData = sizeof (szTemp) * sizeof (TCHAR);
    if (ghkeyMain && (RegQueryValueEx (ghkeyMain, gszKeyFCColor,
		NULL, &dwType, (LPVOID) szTemp, &cbData) 
		== ERROR_SUCCESS))
    {
		sscanf (szTemp, "%ld %ld %ld", &gnFCRed, &gnFCGreen, 
									   &gnFCBlue);
	}

	// default

	gnBGRed   = BGRED;
	gnBGGreen = BGGREEN;
	gnBGBlue  = BGBLUE;

    cbData = sizeof (szTemp) * sizeof (TCHAR);
    if (ghkeyMain && (RegQueryValueEx (ghkeyMain, gszKeyBGColor,
		NULL, &dwType, (LPVOID) szTemp, &cbData) 
		== ERROR_SUCCESS))
    {
		sscanf (szTemp, "%ld %ld %ld", &gnBGRed, &gnBGGreen, 
									   &gnBGBlue);
	}
	ReadSRegistry () ;
}
					   
VOID ReadSRegistry (VOID)
{
    DWORD dwType;
    DWORD cbData;
	INT i ;
    RegCreateKey (HKEY_CURRENT_USER, gszMainAppKey, &ghkeyMain);
    cbData = sizeof (StatsMU);
    if (ghkeyMain)
		RegQueryValueEx(ghkeyMain, gszKeyStatistics, 
			NULL, &dwType, (LPVOID) &StatsMU, &cbData) ; 
	for (i = 0 ; i < NUMSTATUSERS ; i++)
	{
		if (!isalpha(StatsMU.Stats[i].UserName[0]))
			StatsMU.Stats[i].UserName[0] = ' ' ;  //Clear garbage
	}
	SCUser = StatsMU.CurStatUser ;
}

VOID WriteSRegistry (HWND hwnd)
{
	StatsMU.CurStatUser = SCUser ;
	RegSetValueEx(ghkeyMain, gszKeyStatistics, 0, REG_BINARY,
            (LPBYTE) &StatsMU, sizeof(StatsMU));
}

/*****************************************************************************\
* WriteRegistry
*
* Writes out preference data to the registry when the app exits, then
* closes the registry key.
*
* Arguments:
*    none
*
* Returns:
*    VOID
\*****************************************************************************/
VOID WriteRegistry (HWND hwnd)
{
    WINDOWPLACEMENT wndpl;
	char			szTemp[13];

    if (ghkeyMain)
    {
        wndpl.length = sizeof(WINDOWPLACEMENT);
        GetWindowPlacement(hwnd, &wndpl);
        RegSetValueEx(ghkeyMain, gszKeyPosition, 0, REG_BINARY,
            (LPBYTE)&wndpl, sizeof(wndpl));

		sprintf (szTemp, "%ld %ld %ld", gnRedWidth, gnRedHeight, 
										gbReduced);

        RegSetValueEx (ghkeyMain, gszKeyRedSize, 0, REG_SZ,
            (LPBYTE) szTemp, (lstrlen (szTemp) + 1) * sizeof(TCHAR));

		sprintf (szTemp, "%ld %ld", gnNorWidth, gnNorHeight);

        RegSetValueEx (ghkeyMain, gszKeyNorSize, 0, REG_SZ,
            (LPBYTE) szTemp, (lstrlen (szTemp) + 1) * sizeof(TCHAR));

        RegSetValueEx(ghkeyMain, gszKeyMessages, 0, REG_DWORD,
            (LPBYTE) &gbMessages, sizeof(BOOL));

        RegSetValueEx(ghkeyMain, gszKeyProAids, 0, REG_DWORD,
            (LPBYTE) &gbProAids, sizeof(BOOL));

        RegSetValueEx(ghkeyMain, gszKeyFastUndo, 0, REG_DWORD,
            (LPBYTE) &gbFastUndo, sizeof(BOOL));

        RegSetValueEx(ghkeyMain, gszKeyAnimate, 0, REG_DWORD,
            (LPBYTE) &gnAnimation, sizeof(INT));

        RegSetValueEx(ghkeyMain, gszKeyNumFCs, 0, REG_DWORD,
            (LPBYTE) &NumFcs, sizeof(INT));

        RegSetValueEx(ghkeyMain, gszKeyUndoType, 0, REG_DWORD,
            (LPBYTE) &gnUserUndoType, sizeof(INT));

        RegSetValueEx(ghkeyMain, gszKeyRandMax, 0, REG_DWORD,
            (LPBYTE) &gnMaxRandGame, sizeof(INT));

        RegSetValueEx(ghkeyMain, gszKeyLogging, 0, REG_DWORD,
            (LPBYTE) &gbLogging, sizeof(BOOL));

        RegSetValueEx(ghkeyMain, gszKeyCdFndToolBar, 0, REG_DWORD,
            (LPBYTE) &gbTool, sizeof(BOOL));

        RegSetValueEx(ghkeyMain, gszKeySolRange, 0, REG_DWORD,
            (LPBYTE) &SolrSel, sizeof(INT));

        RegSetValueEx(ghkeyMain, gszKeyStatus, 0, REG_DWORD,
            (LPBYTE) &gbStatus, sizeof(BOOL));

		RegSetValueEx(ghkeyMain, gszKeyDblclk, 0, REG_DWORD,
            (LPBYTE) &gnDblclkMode, sizeof(INT));

		RegSetValueEx(ghkeyMain, gszKeySpider, 0, REG_DWORD,
            (LPBYTE) &gbSpider, sizeof(BOOL));

		sprintf (szTemp, "%ld %ld %ld", gnFCRed, gnFCGreen, 
										gnFCBlue);

        RegSetValueEx (ghkeyMain, gszKeyFCColor, 0, REG_SZ,
            (LPBYTE) szTemp, (lstrlen (szTemp) + 1) * sizeof(TCHAR));

		sprintf (szTemp, "%ld %ld %ld", gnBGRed, gnBGGreen, 
										gnBGBlue);

        RegSetValueEx (ghkeyMain, gszKeyBGColor, 0, REG_SZ,
            (LPBYTE) szTemp, (lstrlen (szTemp) + 1) * sizeof(TCHAR));
		WriteSRegistry(hwnd) ;
        RegCloseKey (ghkeyMain);
    }
}

/*****************************************************************************\
* Message
*
* Puts up a message box.
*
* Arguments:
*   UINT fuStyle    - Flags for MessageBox (MB_YESNOCANCEL, etc).
*   LPSTR pszFormat - Format string for the message.
*
* Returns:
*   Whatever MessageBox returns.
*
\*****************************************************************************/
INT Message (HWND hwnd, UINT fuStyle, LPSTR pszFormat, ...)
{
    va_list marker;
    INT RetCode;
    TCHAR szT[MAXSTRING];

    va_start(marker, pszFormat);
    wvsprintf(szT, pszFormat, marker);
    RetCode = MessageBox (hwnd, szT, gszWindowName, 
							fuStyle|MB_TASKMODAL);
    va_end(marker);

    return RetCode;
}

/*****************************************************************************\
* This routine sets the app's caption bar to display info on the window
*
* Arguments:
*
* Returns:
*    VOID
\*****************************************************************************/
VOID SetMainCaption (HWND hwnd, CHAR *str)
{
    CHAR szText[MAXSTRING];

    if (lstrlen(gszWindowName) + lstrlen(str) + 3 > MAXSTRING)
        str[MAXSTRING - 3 - lstrlen(str)] = 0;

    wsprintf(szText, "%s - %s", gszWindowName, str);

    SetWindowText (hwnd, szText);
}

#if 0
/*****************************************************************************\
* StripExtension
*
*   Strips the extension off of a filename.
*
* Arguments:
*   LPSTR pszFileName - File name to process.
*
* Returns:
*   Returns a pointer to the beginning of the filename.  The extension
*   will have been stripped off.
*
\*****************************************************************************/
PRIVATE LPSTR StripExtension (LPSTR pszFileName)
{
    LPSTR p = pszFileName;

    while (*p)
        p++;

    while (p > pszFileName && *p != '\\' && *p != ':') {
        p = CharPrev(pszFileName, p);
        if (*p == '.') {
            *p = 0;
        }
    }
    if (*p == '\\' || *p == ':') {
        p++;
    }
    return p;
}
#endif

/*****************************************************************************\
* LoadResourceString
*
* Arguments:
*   wId        - resource string id
*
* Returns:
*   Returns a pointer to the string.
*
\*****************************************************************************/
LPTSTR LoadResourceString (UINT wId)
{
    static TCHAR lpBuf[1024];

    LoadString (GetModuleHandle(NULL), wId, lpBuf, sizeof(lpBuf));

    return lpBuf;
}

VOID ShowLastError (HWND hwnd, CHAR *id_str)
{
	DWORD  err;
	CHAR   szTemp[100];
	LPVOID lpMsgBuf;

	FormatMessage( 
	FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
	NULL,
	err = GetLastError(),
	MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
	(LPTSTR) &lpMsgBuf,
	0,
	NULL);

	// Display the string.
	
	sprintf(szTemp, "%s (%x)\n%s", id_str, err, lpMsgBuf);

	Message (hwnd, MB_OK | MB_ICONEXCLAMATION, szTemp);
}

VOID StringOut (HDC hdc, INT x, INT y, CHAR *str, INT num)
{
	CHAR szTemp1[100 - 8];
	CHAR szTemp[100];

	strncpy (szTemp1, str, sizeof (szTemp1));
	sprintf (szTemp, "%s 0x%04x ", szTemp1, num);
	TextOut (hdc, x, y, szTemp, strlen (szTemp));
}

BOOL ObjectInRect (LPRECT object, LPRECT rc)
{
	if (ObjectInRect2D (object->top, object->bottom, rc->top, rc->bottom) && 
		ObjectInRect2D (object->left, object->right, rc->left, rc->right))
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

// #1 is rect is below card
// #2 is rect starts to overlap
// #3 is rect is inside
// #4 is rect is ending overlap
// #5 is rect is above 
// #6 is rect overlaps both sides
PRIVATE BOOL ObjectInRect2D (INT x, INT xPlus, INT r, INT rPlus)
{
	BOOL rtn = FALSE;

	if (r < x)
	{ // #1,2,6
		if (rPlus > x)
		{ // #2,6
			rtn = TRUE;
		}
	}
	else
	{ // #3,4,5
		if (rPlus < xPlus)
		{ // #3
			rtn = TRUE;
		}
		else
		{ // #4,5
			if (r < xPlus)
			{ // #4
				rtn = TRUE;
			}
		}
	}

	return rtn;
}

BOOL FileScan (HFILE fhFile, CHAR ch, INT dir)
{
	BOOL fFound = FALSE;
	INT  nFilePointer = -1;
	CHAR szTemp[1];

	while (1)
	{
		if ((_lread(fhFile, szTemp, 1) == 0) && (dir > 0))
		{
			// reached end of file!
			break;
		}

		if (szTemp[0] == ch)
		{
			// found character
			fFound = TRUE;
			break;
		}

		if (dir < 0)
		{
			if (nFilePointer == 0)
			{
				// reached begining of file!
				break;
			}
			// backup 2  since we just read 1
			nFilePointer = _llseek(fhFile, -2, FILE_CURRENT);
			if (nFilePointer == HFILE_ERROR)
				break ;
		}
	} 

	return fFound;
}

char szrtn[12] ;

LPSTR FmtGameNo(DWORDLONG gnum)
{
UINT GNLo ;
int GNHi, i  ;
	if (gnum > 0x7fffffff)
	{
		GNHi = (int)(gnum / 1000000000) ;
		GNLo = (UINT)(gnum % 1000000000) ;
		sprintf(szrtn, "%d%9u", GNHi, GNLo) ;
	}
	else
		sprintf(szrtn, "%u", gnum) ;
	for (i = 1; i < 10 ; i++)
		if (szrtn[i] == ' ')
			szrtn[i] = '0' ;
		else
			break ;
	return szrtn ;
}

DWORDLONG CvGameNo(LPSTR szGNo) 
{	   
char HiDig ;
UINT LoDec ;
DWORDLONG Gno ;
	HiDig = 0 ;
	if (lstrlen(szGNo) >= 10)
		{
			HiDig = szGNo[0] ;
			szGNo[0] = '0' ;
			LoDec = 0 ;
			if (szGNo[1] == '0') // Protect against 9-digit leading zero
			{
				LoDec = 1000000000 ;
				szGNo[0] = '1' ;
			}	
		}
		Gno = atoi(szGNo) ;
		if (HiDig)
			Gno += ((DWORDLONG)(HiDig - '0') * 1000000000 - LoDec) ;
			if (Gno > 0x1ffffffff)  // do not allow overflow beyond 33-bit value
				Gno = 0 ;
		return Gno ;
}
