// copyight 1997 wilson callan

/*don
 * Program for testing winnability of opening positions in Free Cell.
 * Can also generate random positions, optionally filtered for winnability.
 * Does not actually support interactive playing of the game.  See below for
 * a brief explanation of the rules.
 *
 * (c) Copyright 1994, Donald R. Woods.  Shareware: Right is granted to
 *	freely redistribute this source provided this notice is retained.
 */


/*****************************************************************************
Brief summary of the game:


Deal four columns of six cards each, and four of seven cards each, spreading
each column so the cards are all visible.  These columns form the "tableau".
There is a "holding area" that can hold a maximum of four cards.  The only
cards that can be moved are the bottommost card in each column and the cards
in the holding area.  As Aces become available (i.e., can be moved) they are
moved to start four "foundation" piles, which are then built up in suit to
Kings.  The object is to move all the cards to the foundations.


A move consists of moving one card.  A card can move onto a tableau column
if the card being moved is the opposite color and one rank lower than the
card it is being played onto (i.e., the tableau builds down, alternating
color).  Any card can be moved to an empty holding area spot, or to an empty
column in the tableau.


There is a variant using ten column of five cards each (with the other two
cards starting in the holding area), where the tableau builds down in suit
instead of alternating color, and only kings can be moved into empty tableau
columns.  This is sometimes called Seahaven Towers.  It is a somewhat easier
game to solve since more moves are "forced" (in the sense of being provably
good).



General approach: Depth-first search seems to be fast enough, so we won't try
anything fancier.


Positions are hashed and cached so the search doesn't expand them 
more than
once.  A position is cached in canonical form, obtained by sorting 
the cards
in the holding area and -- for the purposes of comparison of 
positions --
sorting the tableau columns based on the cards at the head of each 
column.
(Actually sorting the columns fails due to the need to maintain a 
matching
data structure that maps each card to its position.)


Part of the data structure representing a position gives just ranks and
colors.  A separate part notes, for each card (rank+suit, not just color),
where the card is located, and whether it is eligible to be interchanged
with the like-color card (because the resulting position was reached
elsewhere in the search tree), or whether it MUST be interchanged (because
at some point the only accessible card of the pair was moved to a
foundation pile).  A newly-reached position can be ignored if the first
part of the data structure matches a previously-reached position and the
second part has no cards that can be interchanged where the previous
position didn't.


The only "forced moves" entail moving a card to the foundation piles if
(a) it is eligible to be moved there and (b) both of the cards that could
be played on this one (i.e., next lower rank and opposite color) are
either already on the foundations or are eligible to be played there.
Forced moves are made one card at a time to simplify undoing them, but no
other moves are considered if a forced move is available.


Input format is 52 cards represented either as rank then suit or suit then
rank, where suit is one of CDHS and rank is one of A23456789TJQK.  Lower-case
is okay too.  Other characters such as spaces and line breaks are ignored and
can be used for readability.  E.g.:


7h 9s Kc 5d 8h 3h 6d 9d
7d As 3c Js 8c Kd 2d Ac
2s Qc Jh 8d Th Ts 9h 5h
Qs 6c 4s 6h Ad 8s 2h 4d
Ah 7s 3d Jd 9c 3s Qd Kh
7c 4c Jc Qh 2c Tc 5s 4h
5c Td Ks 6s


*****************************************************************************/

#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "main.h"
#include "FCSolve.h"
#include "custom.h"
#include "settings.h"
#include "freecell.h"

void FCSolveReadOriginal (void);
BOOL FCSolveMove (char);
void MainMessage (char *s);
void StatusOut (char *str);
void UpdateMain (void);
//void FreeCellInit (boolean);
//void InvalidateMain (void *);
//void MainStartGame (boolean);
extern BOOL gbSolver;
extern HANDLE ghSolverThread;
extern DWORDLONG gnGameNumber, gnFirstGame, gnLastGame  ;
#define SWAPIT  (1)  // allow swaps
#define SWAPITX  (1)  // allow DidSwap mode
#define FC4		(1)	 // use 4 fcs instead of 1 big one
#define FC5U	(1)  // allow for 5 up freecells
#define F5DIAG (1)
#define printf	MyPrintf
#define DEBUG	(0)
FILE *gfpSolFile;
int gnSolve, SMode ;
BOOL gbAbort, gbAbortA, gbAbortM, gbMemOver, gbStackOver ;
int AppError ;
DWORDLONG gnFirstGame = 1, gnLastGame = 1 ;
int gnMaxHands = 0 ;
int gnMaxTime = 0 ;
int gnMaxTimeB = 0 ;
int gnMaxSpace = 0 ;
int SolrSel, gnPrtEnbl, gnRptEnbl ;
char szPCOrig[3] ;
int gnMaxTOrig, gnMaxHOrig ;
BOOL gbDidSwap, gbDidSwapHlt ;
void MyPrintf (char *szFormat, ...)
{
#if DEBUG
    va_list marker;
    va_start (marker, szFormat);
	vfprintf (gfpSolFile, szFormat, marker);
    va_end (marker);
#endif
}

#define true  (1==1)
#define false (1==0)

#define Rank(card)	((card) & 0x0F)
#define Suit(card)	((card) >> 4)
#define Colormate(card)	((card) ^ 0x20)
//#define Either(card)	((card) & 0x1F)

#define FC8S 1

#ifndef FC5U
#define HOLDINGA		0x1C
#define HOLDINGB		0x1D
#define HOLDINGC		0x1E
#define HOLDINGD		0x1F
#define HOLDING_MASK	HOLDINGA
#define HOLDING			HOLDINGD // used by non FC5U code only!
#else
//#ifndef FC8S
//#ifdef FC89
#define HOLDINGA		0x18
#define HOLDINGB		0x19
#define HOLDINGC		0x1A
#define HOLDINGD		0x1B
#define HOLDINGE		0x1C
#define HOLDINGF		0x1D	 
#define HOLDINGG		0x1E	 
#define HOLDING_MASK	HOLDINGA
#ifdef FC8S
#define HOLDINGH 0x1F
#endif
//#define HOLDINGH 0x20
//#define HOLDINGI 0x21

/*
#define HOLDINGA		0x31
#define HOLDINGB		0x32
#define HOLDINGC		0x33
#define HOLDINGD		0x34
#define HOLDINGE		0x35
#define HOLDINGF		0x36	 
#define HOLDINGG		0x37
#define HOLDINGH		0x38
#define HOLDINGI		0x39
*/
/*
#define HOLDINGA		0x37
#define HOLDINGB		0x38
#define HOLDINGC		0x39
#define HOLDINGD		0x3a
#define HOLDINGE		0x3b
#define HOLDINGF		0x3c 
#define HOLDINGG		0x3d
#define HOLDINGH		0x3e
#define HOLDINGI		0x3f
#define HOLDING_MASK	0x30  //HOLDINGA
*/
/*
#define HOLDINGA		0x30
#define HOLDINGB		0x31
#define HOLDINGC		0x32
#define HOLDINGD		0x33
#define HOLDINGE		0x34
#define HOLDINGF		0x35	 
#define HOLDINGG		0x36
#define HOLDINGH		0x37
#define HOLDINGI		0x38
#define HOLDING_MASK	HOLDINGA
*/
#endif
//#endif
#define HOLDING_BASE	HOLDINGA

#define FOUNDATION		0xFF

#define Col(loc)	((loc) >> 5)
#define Index(loc)	((loc) & 0x1F)

#define NO_SWAP		0
#define CAN_SWAP	1
#define DID_SWAP	2

#define SortedCol(pos, index)	&(pos)->tableau[(pos)->colSeq[index]]

int cardToIndex[0x3F];		/* maps Card -> index in info[] (0-51) */

static int verbosity = 0;	/* how much to print out while running */
static int show = false;	/* whether to show solution if found */
static int showorig = false;	/* whether to show original layout */
static int maxdepth = 100000;	/* max search depth before giving up a line */

#define TRACTABLE 200000	/* max distinct positions before giving up */

/* statistics gathering */
static long generated = 0;	/* # times AddToTree called */
static long distinct = 0;	/* # different positions reached */
static long hashes = 0;		/* # hash table slots used */
static long rejected = 0;	/* # rejected due to repeated column */
static long swaps = 0;		/* # positions combining lines via swaps */
static long maxout = 0;		/* # trees pruned for hitting max depth,
				   or max depth reached if no limit imposed */
static long maxfree = 0;	/* max of (open holds+1) * (2^spaces) */
static long brokeSeq = 0;	/* # trees pruned due to breaking sequences */
static long windepth;		/* depth of winning line */
//MEMORYSTATUS memstat ;


/* Random number package.  Roll our own since so many systems seem to have
 * pretty bad ones.  Include code for both MSDOS and UNIX time functions to
 * initialise it.
 */
//#ifdef __MSDOS__
#ifdef WIN32
#include "time.h"
#define GET_TIME(var) {time(&var);}
time_t	 stime, etime, oetime ;
#else
#include "sys/time.h"
#define GET_TIME(var) { \
	struct timeval now; \
	gettimeofday(&now, 0); \
	var = now.tv_sec + now.tv_usec; \
}
#endif
#ifdef SWAPIT
BOOL Swapit ;
Card holdA[10] ;
#endif
int EitherM ;
uchar Either(card)
{
  return card & EitherM ;
}

#if DON
#define RAND_BUFSIZE	98
#define RAND_HASHWORD	27
#define RAND_BITSUSED	29
#define RAND_MASK	((1 << RAND_BITSUSED) - 1)
static long rand_buf[RAND_BUFSIZE], *rand_bufLoc;
static long Rand();
static char rand_flips[1<<6];
static short rand_flipper;
#endif

Position orig;	/* special in that only tableau[] is set, and it
			   stores Cards instead of Pairs */

#define RAND_FLIPMASK (sizeof(rand_flips) - 1)
#define POS_BLOCK 2000
typedef struct pos_block {
	Position block[POS_BLOCK];
	struct pos_block *link;
} Block;

static int pos_avail = 0;
static Block *block = NULL;

int foobar = 0;
static int depth = 0;
//int dup ;
int i, j, x, xx ;
//int k ;

Column *col;
Position *prev;
Column *oldcol;

//int opp1, opp2 ;
Column *coldf ;

int OMode = 0 ;  //order of types of moves to try in DFS()
int OMode2 = 0 ;  //order of types of moves to try in DFS()
int gnExtendTry ;
int WinCount, AboCount, ImpCount, P1ACount ;
//#define MEMSTAT 1
#ifdef MEMSTAT
MEMORYSTATUS MemStat ;
char szTempM[50] ;
#endif
#define DIAGD 1
#ifdef DIAGD
int ChainCnt, MaxChainCnt ;
int MaxHashCnt ;
#endif
#define WILSON1 1
//#define WILSON2 1
#define WILSON3 1
#define	WILSON4 1
//#define WILSON6 1
//#define WILSON7 1
//#define SWAPREM1 1
//#define LOCCMP 1
#define HASH_SIZE 19001
#define HASH_SUB 30
static Position **tree;
static Position **tree1[HASH_SIZE] ;
static Position **tree2[HASH_SIZE] ;
//static uchar treeLCnt[HASH_SIZE] ;
//static uchar treeL2Cnt[HASH_SIZE] ;
static INT treeLCnt[HASH_SIZE] ;
static INT treeL2Cnt[HASH_SIZE] ;

static Position *DFS(); /* forward decl */
static void SortHoldingArea(Position *pos);
PRIVATE VOID Free1ErrorAbort (LPSTR pszFormat, ...);

void Free1Solver (HWND hwnd);
char szTemp[100] ;
int EnblDiag ;
extern BOOL gbSearchF, gbSearchF2, gbSearchF3 ;

#if DON

static void RandFlipInit(loc) int loc;
{
	static char f[] =
	   " 11 111 1  1    11 1 111 1  11      11 11111   11 1 1 11  1 11  ";


	rand_flipper = loc;
	for (loc=0; loc<=RAND_FLIPMASK; loc++)
		rand_flips[loc] = (f[loc]==' '? 0 : -1);
}


static void RandInit(seed) long seed;
{
	int n;


	if (seed == 0) GET_TIME(seed);
	memset(rand_buf, 0, sizeof(rand_buf));
	for (n=0; n<RAND_BITSUSED; n++)
	{	rand_buf[n] = RAND_MASK >> n;
		rand_buf[n+RAND_BITSUSED+3] = 1 << n;
	}
	for (n=RAND_BITSUSED*2+3; n<RAND_BUFSIZE; n++)
	{	rand_buf[n] = seed & RAND_MASK;
		seed = seed * 3 + 01234567;
	}
	rand_bufLoc = rand_buf;
	RandFlipInit(0);
	for (n=(seed & 0377); n<50000; n++) Rand();
}


static long Rand()
{
	long f;


	if (!rand_bufLoc) RandInit(0);
	rand_bufLoc = (rand_bufLoc == rand_buf ?
		rand_bufLoc+RAND_BUFSIZE-1 : rand_bufLoc-1);
	*rand_bufLoc ^= *(rand_bufLoc >= rand_buf+RAND_HASHWORD ?
		rand_bufLoc-RAND_HASHWORD
		: rand_bufLoc+(RAND_BUFSIZE-RAND_HASHWORD));
	f = rand_flips[rand_flipper++ & RAND_FLIPMASK];
	return(*rand_bufLoc ^ (f & RAND_MASK));
}

/* End of random number package
 *******************************/

/* Read original position from stdin into orig.
 */
static void ReadOriginal(filename) char *filename;
{
	int count = 0;
	Card cd = 0;
	FILE *f = stdin;


	if (filename != NULL && (f = fopen(filename, "r")) == NULL) {
		printf("free_cell: can't open %s\n", filename);
		exit(1);
	}
	memset(&orig, 0, sizeof(orig));
	while (count < 104) {
		int c = getc(f);
		if (c == EOF) {
			printf("Insufficient input.\n");
			exit(1);
		}
		if (c >= '2' && c <= '9') cd += c - '0';
		else if ((c |= 0x20) == 'a') cd += 1;
		else if (c == 't') cd += 10;
		else if (c == 'j') cd += 11;
		else if (c == 'q') cd += 12;
		else if (c == 'k') cd += 13;
		else if (c == 'c') cd += CLUBS;
		else if (c == 'd') cd += DIAMONDS;
		else if (c == 'h') cd += HEARTS;
		else if (c == 's') cd += SPADES;
		else continue;
		if (count++ % 2 != 0) {
			Column *col = &orig.tableau[((count-1)>>1)%8];
			col->cards[col->count++] = (Pair) cd;
			cd = 0;
		}
	}
	if (filename != NULL) fclose(f);
}


/* Build original as simple sorted deck.
 */
static void BuildOriginal()
{
	int i;


	memset(&orig, 0, sizeof(orig));
	for (i=0; i<52; i++) {
		Column *col = &orig.tableau[i%8];
		Card cd = (i>>2)+1 + ((i&3)<<4);
		col->cards[col->count++] = (Pair) cd;
	}
}

/* Shuffle the starting positions in orig.
 */
static void Shuffle()
{
	int i = 52;
	
	while (i > 1) {
		int swap = Rand() % (i--);
		Pair *c1 = &orig.tableau[i%8].cards[i/8];
		Pair *c2 = &orig.tableau[swap%8].cards[swap/8];
		Pair temp = *c1;
		*c1 = *c2;
		*c2 = temp;
	}
}
#endif  // DON only

/* Initialise a Position record based on orig.
 */
static void InitialPosition(pos) Position *pos;
{
	int i, x, col, index;
	Card c;
//sprintf(szTemp, "Pos- %x, %x, %x, %x  ", orig.tableau->cards[0],orig.tableau->cards[1],
//		orig.tableau->cards[2],orig.tableau->cards[3]);
//MessageBox(GetFocus(), szTemp, "F2M", MB_OK) ;

	// clear locations
#ifndef SPEEDTRY4
	for (i=0; i<52; i++) 
	{
		cardToIndex[((i/13)<<4)+(i%13)+1] = i;
		pos->location[i] = FOUNDATION;
	}
#endif
	// load pos from orig

//	for (index = 0; index <= 3; index++)
	for (index = 0; index <= (NUM_FCS - 1); index++)
	{
		if (orig.hold[index] != 0)
		{
			c = (Card) orig.hold[index];
			x = cardToIndex[c];
#ifndef SPEEDTRY4		
			if (pos->location[x] != 0xFF) 
			{
MainMessage("FC") ;
				Free1ErrorAbort ("Card %02x appears twice!", c);
				return;
			}
#endif
			pos->hold[index] = c;
#ifndef SPEEDTRY4
			pos->location[x] = HOLDING_BASE + index;
//#ifdef F5DIAG
//		sprintf (szTemp, "posl:%x x- %d  c- %x", pos->location[x], x, c) ;
//		MainMessage(szTemp) ;
//#endif
#endif
		}
	}

	for (index = 0; index <= 3; index++)
//	for (index = 0; index <= (NUM_FCS - 1); index++)
	{
		if (orig.foundations[index] != 0)
		{
#ifndef WILSON1
			c = (Card) orig.foundations[index];
#else
			c = (Card) (index << 4) + ((orig.foundations[index]) & 0xf) ;
#endif
			x = cardToIndex[c];
//#ifdef F5DIAG
//		sprintf (szTemp, "FND: in-%x fnd- %x c-%x x-%d",
//			index, orig.foundations[index], c, x) ;
//		MainMessage(szTemp) ;
//#endif
#ifndef SPEEDTRY4		
			if (pos->location[x] != 0xFF) 
			{
				Free1ErrorAbort ("Card %02x appears twice!", c) ;
				return;
			}
#endif
			pos->foundations[index] = c & 0xf;
/*  Removed because it's redundant 4/1/98
#ifndef SPEEDTRY4		
			pos->location[x] = FOUNDATION;
#endif
*/
		}
	}

	for (col = 0; col < 8; col++)
	{
		for (index = 0; index < 19; index++)
		{
			if (index >= orig.tableau[col].count)
			{
				// no more cards in this column
				break;
			}

			c = (Card) orig.tableau[col].cards[index];
			x = cardToIndex[c];
#ifndef SPEEDTRY4		
			if (pos->location[x] != 0xFF) 
			{
MainMessage("Tab") ;
				Free1ErrorAbort ("Card %02x appears twice!", c);
				return;
			}
#endif
#ifdef SWAPIT
if (Swapit)
			pos->tableau[col].cards[index] = Either(c);
else
			pos->tableau[col].cards[index] = c;
#else
			pos->tableau[col].cards[index] = c;
#endif
			pos->tableau[col].count++;
#ifndef SPEEDTRY4		
			pos->location[x] = (col<<5) + index;
#endif
		}
	}

	// set to no swap
#ifndef SPEEDTRY5
	memset(pos->swappable, NO_SWAP, sizeof(pos->swappable));
#endif
	// set column sequence 

	for (i=0; i<8; i++) 
		pos->colSeq[i] = i;
}

/* Allocate a new Position structure.  Allocates many at a time 
	to reduce
 * malloc overhead.  Saves linked list of blocks of positions to 
	enable
 * freeing the storage, which can be necessary if we're examining 
	hundreds of positions in a single run of the program.
 */
static Position *NewPosition()
{
//	if (pos_avail-- == 0) {
	if (pos_avail-- < 2) {
		Block *more = (Block *) calloc(1, sizeof(Block));
#ifdef MEMSTAT
//		MainMessage("calloc1") ;
		GlobalMemoryStatus(&MemStat) ;
		wsprintf(szTempM, "c1AP p-%li  a-%li", MemStat.dwAvailPhys, MemStat.dwAvailVirtual);
		MainMessage(szTempM) ;
#endif
		if (more == NULL) 
		{
			if ((gnSolve != SOLVE_RANGE) &&	(gnSolve != SOLVE_LIST))
			{
				Free1ErrorAbort ("Intractable.\n(Out of memory.)");
			}
			return 0;
		}
		more->link = block;
		block = more;
		pos_avail = POS_BLOCK - 1;
	}
	return (block->block + pos_avail);
}

/* Show a card; rank in uppercase, suit in lowercase, trailing space.
 */
void ShowCard(card) Card card;
{
	static char *rank = "?A23456789TJQK", *suit = "cdsh";
	
	if (card == 0) printf(".. ");
	else printf("%c%c ", rank[Rank(card)], suit[Suit(card)]);
}

/* Show the topmost card on a foundation pile.
 */
void ShowFoundation(pos, s) 
Position *pos; 
int s;
{
	uchar r = pos->foundations[s];
	if (r == 0) 
	{
		printf("   "); 
	}
	else
	{
		// this shows that the foundation has to be in order
		ShowCard((s<<4)+r);
	}
}

/* Show a position as a rectangular layout.
 */
void ReadablePosition(pos) Position *pos;
{
	int suit, rank, h = 0;
	int row=0, col;

	// fill in tableau from location
	for (suit=3; suit>=0; suit--) 
		for (rank=13; rank>0; rank--) 
	{
		Card c = (suit<<4) + rank;
		Loc where = pos->location[cardToIndex[c]];
		switch (where)
		{
#if FC4
if (NUM_FCS > 0)
			case HOLDINGA: pos->hold[0] = c; break;
if (NUM_FCS > 1)
			case HOLDINGB: pos->hold[1] = c; break;
if (NUM_FCS > 2)
			case HOLDINGC: pos->hold[2] = c; break;
if (NUM_FCS > 3)
			case HOLDINGD: pos->hold[3] = c; break;
#ifdef FC5U
if (NUM_FCS > 4)
			case HOLDINGE: pos->hold[4] = c; break;
if (NUM_FCS > 5)
			case HOLDINGF: pos->hold[5] = c; break;
if (NUM_FCS > 6)
			case HOLDINGG: pos->hold[6] = c; break;
#ifdef FC8S
if (NUM_FCS > 7)
			case HOLDINGH: pos->hold[7] = c; break;
//if (NUM_FCS > 8)
//			case HOLDINGI: pos->hold[8] = c; break;
#endif
#endif
#else
			case HOLDING: pos->hold[h++] = c; break;
#endif
			case FOUNDATION: break;
			default:
			pos->tableau[Col(where)].cards[Index(where)] = c;
		}
	}

	// show freecells
//	for (col=0; col<4; col++) {
	for (col=0; col<NUM_FCS; col++) {
		ShowCard(pos->hold[col]);
//		pos->hold[col] &= 0x1F;
		pos->hold[col] = Either(pos->hold[col]);
	}

	// show homecells
	for (col=0; col<4; col++) ShowFoundation(pos, col);

	// show columns
	printf("\n");
	while (true) {
		int none = true;
		for (col=0; col<8; col++) {
			int cd = pos->tableau[col].cards[row];
//			pos->tableau[col].cards[row] &= 0x1F;
			pos->tableau[col].cards[row] = Either(pos->tableau[col].cards[row]) ;
			if (cd) {ShowCard(cd); none = false;}
			else printf("   ");
		}
		printf("\n");
		if (none) break;
		row++;
	}
	fflush(stdout);
}

//
// return 1 if holds are equal
//

static int HoldCmp (Position *probe, Position *pos)
{
//	memcmp((*probe)->hold, pos->hold, 4*sizeof(Card)) == 0
	int i, j;

	if (NUM_FCS == 0)
		return 1 ;
	for (i = 0; i <= (NUM_FCS - 1) ; i++)
	{
		if (probe->hold[i] != 0)
		{
			// see if this card is in pos' holds

			for (j = 0; j <= (NUM_FCS - 1); j++)
			{
				if (probe->hold[i] == pos->hold[j])
				{
					break;
				}
			}

//			if (j >= 4)
			if (j >= NUM_FCS)
			{
				// card not found
							   
				return 0;
			}
		}
	}

	return 1;
}

//static void AddToTreeL(int hashM, Position *pos, LPSTR TLc, Position **atree[])
static void AddToTreeL(int hashM, Position *pos, LPINT TLc, Position **atree[])
{
//	Position* TLTemp[4 * HASH_SUB] ;
	Position* TLTemp[15 * HASH_SUB] ;

//	if (TLc[hashM] > (5 * HASH_SUB - 1))
	if (TLc[hashM] > (16 * HASH_SUB - 1))
	{
		Free1ErrorAbort ("Internal table overflow") ;
		return ;
	}
	if (TLc[hashM] && ((TLc[hashM] % HASH_SUB) == 0))
	{
		memcpy(TLTemp, atree[hashM], TLc[hashM] * sizeof(Position*)) ;
		free(atree[hashM]) ;
		atree[hashM] = calloc(TLc[hashM] + HASH_SUB, sizeof (Position*)) ;
#ifdef MEMSTAT
		MainMessage("calloc2") ;
#endif
		memcpy(atree[hashM], TLTemp, TLc[hashM] * sizeof(Position*)) ;
	}
	#ifdef DIAGD
		if (TLc[hashM] > MaxHashCnt)
			MaxHashCnt = TLc[hashM] ;
	#endif
	atree[hashM][TLc[hashM]] = pos ; 
	TLc[hashM]++ ;
	return ;
}

/* See if this position is already in the search tree.  If so, 
	return false. Else add it and return true.
 */
static int AddToTree (Position *pos)
{
//#ifdef DIAGD
//	char szTempB[50] ;
//#endif
	long hash = 0;
	long hash2 = 0 ;
	int j, hashM, hashM2 ;
	Position temp2 ;
	int i, AddInd ;
	Position temp ;
	Position **probe;
	uchar poll, prll, polm ;

//	long hashp, hash2p ;
//	char prc0, prc1, prc2, prc3, poc0, poc1, poc2, poc3 ;

if ((++generated % 1000) == 0)
	{
#ifndef DIAGD
		sprintf (szTemp, "Generated %d Hands...", generated);
#else
//memstat.dwLength = sizeof(MEMORYSTATUS) ;
//GlobalMemoryStatus(&memstat) ;
	 if (!SMode)
//		sprintf (szTemp, "Gen. %d Hands. pcm-%d tp-%d fm-%d", generated, memstat.dwMemoryLoad,
//							memstat.dwTotalPhys/1024, memstat.dwAvailPhys/1024);
		sprintf (szTemp, "Generated %d Hands...", generated);
	 else
		 sprintf (szTemp, "Generated %d Hands...D:%d H:%d C:%d", generated, distinct, 
				MaxHashCnt, MaxChainCnt);
#endif
		StatusOut (szTemp);
		UpdateMain ();
	}

	// get start hash value

	// sort holds for index into hash
	/*debug*/	if(temp.hold == 0 || pos->hold == 0 || pos == 0)
					return 0;
	
#ifndef FC5U
	memcpy (temp.hold, pos->hold, 4 * sizeof (Card));
#else
	memcpy (temp.hold, pos->hold, 7 * sizeof (Card));
#endif
	SortHoldingArea (&temp);

	for (i = 0; i<= (NUM_FCS - 1); i++)
	{
	if (NUM_FCS <= 4)
		hash = hash*3 + temp.hold[i];
	else
#ifndef FC8S
		hash = hash*2 + temp.hold[i];
#else
	if (NUM_FCS <= 7)
		hash = hash*2 + temp.hold[i] ;
	else
		hash = hash*3/2 + temp.hold[i] ;
#endif
	}

	for (i=0; i<8; i++) 
	{
		Column *col = SortedCol(pos, i);
		int ct;

		/*debug*/if(col == 0) 
					return 0;

		ct = col->count;
		hash *= 5;
		if (ct) 
			hash += col->cards[ct-1];
	}
	pos->hash = hash;
  if (SMode)
//#ifdef DHASH
  {
	  memcpy (temp2.hold, pos->foundations, 4 * sizeof (Card));
	 for (i = 0; i<= (NUM_FCS - 1); i++)
	{
	if (NUM_FCS <= 4)
	{
if (!Swapit)  // in 6x  -- hold for possible use
		hash2 = hash2*2 + temp.hold[i] + temp2.hold[i] ;
else
		{
		hash2 = hash2*3 + temp.hold[NUM_FCS - 1 - i] + temp2.hold[NUM_FCS - 1 - i] ;
//		MainMessage("Hash") ;
		}
	}
	else
		hash2 = hash2*3/2 + temp.hold[i] + temp2.hold[i] ;
	}
	for (i=0; i<8; i++) 
	{
		Column *col = SortedCol(pos, i);
		int ct;
if (Swapit)
	col = SortedCol(pos, 7 - i);
		if(col == 0) 
					return 0;
		ct = col->count;
if (Swapit)   // per 6x -- hold for possible use
		hash2 *= 5;
else
		hash2 *= 3;
//		if (ct > 1) 
//			hash2 += col->cards[ct-2] ;

		if (ct > 1) 
			hash2 += (col->cards[ct-2] + col->cards[ct - 1]) ;
		else
		{
			if (ct)
				hash2 += col->cards[ct-1];
		}

	}
	pos->hash2 = hash2;
  }
//sprintf(szTempB, "%ld   %ld  %ld  ", hash, hash2, generated) ;
//MainMessage(szTempB) ;
//#endif
#ifndef SPEEDTRY5
	pos->swapvia = NULL;
#endif
//#ifndef DHASH
//MainMessage("Point 1") ;
if (!SMode)
	probe = &tree[hash % HASH_SIZE];
//#else
else
{
    hashM = hash % HASH_SIZE ;
    hashM2 = hash2 % HASH_SIZE ;
	if (treeLCnt[hashM] && treeL2Cnt[hashM2])
	{
	for (i = 0 ; i < (int)treeLCnt[hashM] ; i++)
		{
		for (j = 0 ; j < (int)treeL2Cnt[hashM2] ; j++)
			{
			if (tree1[hashM][i] == tree2[hashM2][j])
				{
				break ;
				}	
			}
		if (j != treeL2Cnt[hashM2])
			break ;
		}
	}
}
//#endif
//#ifdef DHASH
AddInd = 0 ;
if (SMode)
{
	if ((treeLCnt[hashM] && treeL2Cnt[hashM2]) && 
		((i != (int)treeLCnt[hashM]) || (j != (int)treeL2Cnt[hashM2])))
	{
		probe = &tree1[hashM][i] ;
#ifdef DIAGD
ChainCnt = 0 ;
#endif	
	}
else
	AddInd = 1 ;
}
//#endif
//MainMessage("Point 2") ;
	if (AddInd || (*probe == NULL)) 
	{
//MainMessage("Point 2A") ;
		AddInd = 1 ;
		hashes++;
	}
	else while (*probe != NULL) 
	{
//MainMessage("Point 2B") ;
#ifndef WILSON4
		if (((*probe)->hash == hash) && HoldCmp (*probe, pos))
#else
/*
hashp =	(*probe)->hash ;
hash2p = (*probe)->hash2 ;
prc0 = (*probe)->hold[0] ;
prc1 = (*probe)->hold[1] ;
prc2 = (*probe)->hold[2] ;
prc3 = (*probe)->hold[3] ;
poc0 = pos->hold[0] ;
poc1 = pos->hold[1] ;
poc2 = pos->hold[2] ;
poc3 = pos->hold[3] ;
*/
		if (((*probe)->hash == hash) && HoldCmp (*probe, pos)&& HoldCmp (pos,*probe))
#endif
		{
			// probe holds == pos holds 
//MainMessage("Point 2C") ;
#ifndef LOCCMP
			for (i=0; i<8; i++) 
			{
				Column *c1 = SortedCol(pos, i);
				Column *c2 = SortedCol(*probe, i);

				/*debug*/if(c1 == 0 || c2 == 0)
							return 0;
									 			
				if (c1->count != c2->count) 
					break;

				if (c1->count == 0) 
				{
					i=8; 
					break;
				}

				/*debug*/if(c1->cards == 0 || c2->cards == 0)
							return 0;
				
				if (memcmp(c1->cards, c2->cards,
				      c1->count*sizeof(Card)) != 0) 
					break;
			}

#ifndef SPEEDTRY5
			if (i == 8) 
				for (i=0; i<26; i++) 
				{
					if (pos->swappable[i] > (*probe)->swappable[i])
						break;
				}
	
			if (i == 26) 
			{
				int latest = cardToIndex[pos->moved],
				    mate = cardToIndex[Colormate(pos->moved)],
				    either = cardToIndex[Either(pos->moved)];
				poll = pos->location[latest] ;
				prll = (*probe)->location[latest] ;
				polm = pos->location[mate] ;
					if ((poll != FOUNDATION) && ((poll & HOLDING_MASK) == HOLDING_MASK))
						poll = HOLDING_BASE ;
					if ((prll != FOUNDATION) && ((prll & HOLDING_MASK) == HOLDING_MASK))
						prll = HOLDING_BASE ;
					if ((polm != FOUNDATION) && ((polm & HOLDING_MASK) == HOLDING_MASK))
					{
						polm = HOLDING_BASE ;
					  }
			
				if ((pos->swappable[either] == NO_SWAP) &&
//				    (pos->location[latest] !=
//				            (*probe)->location[latest]) &&
//				    (pos->location[mate] ==
//				            (*probe)->location[latest])) 
					(poll != prll) && (polm == prll))
				{
#if SWAPIT
//MainMessage("Can Swap") ;
if (Swapit)
					pos->swappable[either] = CAN_SWAP;	// not swapped, but ready to...
#endif
					pos->swapvia = *probe;
//#endif
				}
				else
				{
#ifdef DIAGD
	if ((ChainCnt > MaxChainCnt) && SMode)
		MaxChainCnt = ChainCnt ;
#endif
					return(false);
				}
			}
#else

			  if (i == 8)
				{
					//hands are equal
					return (false) ;
				}
#endif
#else
				if (memcmp(pos->location, (*probe)->location, 52) != 0)
			break;
		else
			return (false) ;
#endif
		}
		probe = &((*probe)->chain);
#ifdef DIAGD
		ChainCnt++ ;
//sprintf(szTemp, "h-%ld   ph-%ld  h2-%ld   ph2-%ld  g-%d cc-%d \n pr0-%x pr1-%x pr2-%x pr3-%x  \npo0-%x po1-%x po2-%x po3-%x   ",
//		hash, hashp, hash2, hash2p, generated, ChainCnt, prc0, prc1, prc2, prc3, 
//		poc0, poc1, poc2, poc3) ;
//sprintf(szTemp, "ph-%ld g-%d  ", hashp, generated) ;
//MainMessage(szTemp) ;
#endif
	}
if (!SMode || (SMode && !AddInd))
{
#ifndef SPEEDTRY5
	if (pos->swapvia) swaps++;
#endif
	*probe = pos;
}
//#ifdef DHASH
//}
//else
//{
//#endif												i
//MainMessage("Point 3") ;
if (SMode && AddInd)
{
//#endif
//#ifdef DHASH
//MainMessage("Point 3A") ;
AddToTreeL(hashM, pos, treeLCnt, tree1) ;			 
//MainMessage("Point 3B") ;
AddToTreeL(hashM2, pos, treeL2Cnt, tree2) ;
//MainMessage("Point 3C") ;
}
//#endif
	pos->chain = NULL;
if ((distinct++ & 0x7FFF) == 0x7FFF && verbosity == 1) {
		printf("%d distinct positions...\n", distinct);
		fflush(stdout);
	}
#ifdef DIAGD
	if (ChainCnt > MaxChainCnt)
		MaxChainCnt = ChainCnt ;
#endif
	return(true);
}

/* Return true if tableau has an empty column.
 */
static int HasSpace(pos) Position *pos;
{
	return(pos->tableau[pos->colSeq[7]].count == 0);
}


/* Return card at bottom of column (resolving Pair to single Card).
 */
static Card Bottom(pos, i) Position *pos; int i;
{
	Column *col = &pos->tableau[i];
	Card cd = col->cards[col->count - 1];
	if (pos->location[cardToIndex[cd]] != (i<<5) + col->count - 1)
		cd ^= 0x20;
	return(cd);
}


/* Return true if card is available to be played.
 */
static int Available(pos, card) 
Position *pos; 
Card card;
{
	Loc where;

	if (card == 0) return(false);

	where = pos->location[cardToIndex[card]];
	switch (where)
	{
#if FC4
		case HOLDINGA: return(true);
		case HOLDINGB: return(true);
		case HOLDINGC: return(true);
		case HOLDINGD: return(true);
#ifdef FC5U
		case HOLDINGE: return(true);
		case HOLDINGF: return(true);
		case HOLDINGG: return(true);
#ifdef FC8S
		case HOLDINGH: return(true);
//		case HOLDINGI: return(true);
#endif
#endif
#else
		case HOLDING: return(true);
#endif
		case FOUNDATION: return(false);
	}

	if (pos->tableau[Col(where)].count == Index(where)+1) 
	{
		return(true);
	}
	return(false);
}

/* Sort the holding area into descending order 
	(hence spaces come last).
 * Use homogeneous sorting network. */
static void SortHoldingArea (Position *pos)
{
	Card *h = pos->hold;
	Card temp;
#ifdef FC5U
	for (i = NUM_FCS ; i < 8 ; i++)
		pos->hold[i] = 0 ;   // clear high positions
#endif
#ifndef SWAPIT
#define SWAP(i,j) if (h[i]<h[j]) {temp=h[i]; h[i]=h[j]; h[j]=temp;}
#else
#define SWAP(i,j) if (h[i]<h[j]) {temp=h[i]; h[i]=h[j]; h[j]=temp;temp = holdA[i]; holdA[i] = holdA[j]; holdA[j] = temp;}
#endif
	SWAP(0,1)
	SWAP(2,3)
if (NUM_FCS <= 4)
	{
	SWAP(0,2)
	SWAP(1,3)
	SWAP(1,2)
	}
else
	{
    SWAP(4,5)
	SWAP(0,2)
	SWAP(3,5)
	SWAP(1,3)
	SWAP(2,4)
	SWAP(0,2)
	SWAP(3,5)
	SWAP(0,1)
	SWAP(1,2)
	SWAP(3,4)
	SWAP(4,5)
	}
}

/* Sort the tableau columns based on the top cards of the columns.
 * Only called when the top card of a column actually changes.  Note
 * that the columns will be mostly sorted already.
 */
static void SortColumns(pos) Position *pos;
{
	int thru = 7;


	while (thru > 0) {
		int i, need = 0;
		for (i=1; i<=thru; i++) {
			if (pos->tableau[pos->colSeq[i]].cards[0] > 
			    pos->tableau[pos->colSeq[i-1]].cards[0]) {
				uchar temp = pos->colSeq[i];
				pos->colSeq[i] = pos->colSeq[i-1];
				pos->colSeq[i-1] = temp;
				need = i-1;
			}
		}
		thru = need;
	}
}


/* Move the specified card from wherever it is to new location.  
	If this
 * requires swapping a swappable pair, update struct accordingly.  
	Assumes destination of move is legal for card being moved.
 */
//static Loc MoveCard(pos, card, whither) Position *pos; Card card; Loc whither;
static char MoveCard(pos, card, whither) 
Position *pos; 
Card card; 
Loc whither; // to
{
	Loc *where = &pos->location[cardToIndex[card]]; // from
	if (!Available(pos, card)) 
	{
#ifndef SPEEDTRY5
//#if SWAPIT  // ??? In 6x -- SWAPITX ?? not defined anywhere
#ifdef SWAPITX
if (Swapit && gbDidSwap)
{
		Loc temp, *where2 = &pos->location[cardToIndex[Colormate(card)]];
		Swap *swap = &pos->swappable[cardToIndex[Either(card)]];
/*
if (gbDidSwapHlt)
{
sprintf(szTemp, "DS ca-%x ge-%d", card, generated) ;
MainMessage(szTemp) ;
//gbDidSwapHlt = FALSE ;
}
*/
		if (*swap != CAN_SWAP || !Available(pos, Colormate(card))) 
		{
			Free1ErrorAbort ("Bug! Move of unavailable card.");
			return 0;
		}

		printf("Performing swap\n");
//MainMessage("Did Swap") ;
//		*swap = DID_SWAP;
		temp = *where;
		*where = *where2;
		*where2 = temp;
}
//#else
else
		return 0;
//#endif
#else
		return 0 ;
#endif
#else
		return 0 ;
#endif
	}						 

	pos->mustTry = (-1);

	switch (*where)
	{
#if FC4
		case HOLDINGA:
#ifndef SWAPREM1
			if (pos->hold[0] == Either(card)) 
#else
			if (pos->hold[0] == card) 
#endif
			{
				pos->hold[0] = 0;
				if (Swapit)
					holdA[0] = 0 ;
			}	
			else
				Free1ErrorAbort ("Needed card is not in FreeCell A.");
			break;

		case HOLDINGB:
//			if (pos->hold[1] == Either(card)) 
#ifndef SWAPREM1
			if (pos->hold[1] == Either(card)) 
#else
			if (pos->hold[1] == card) 
#endif
			{
				pos->hold[1] = 0;
				if (Swapit)
					holdA[1] = 0 ;
			}	
			else
				Free1ErrorAbort ("Needed card is not in FreeCell B.");
			break;

		case HOLDINGC:
//			if (pos->hold[2] == Either(card)) 
#ifndef SWAPREM1
			if (pos->hold[2] == Either(card)) 
#else
			if (pos->hold[2] == card) 
#endif
			{
				pos->hold[2] = 0;
				if (Swapit)
					holdA[2] = 0 ;
			}	
			else
				Free1ErrorAbort ("Needed card is not in FreeCell C.");
			break;

		case HOLDINGD:
//			if (pos->hold[3] == Either(card)) 
#ifndef SWAPREM1
			if (pos->hold[3] == Either(card)) 
#else
			if (pos->hold[3] == card) 
#endif
			{
				pos->hold[3] = 0;
				if (Swapit)
					holdA[3] = 0 ;
			}	
			else
				Free1ErrorAbort ("Needed card is not in FreeCell D.");
			break;
#ifdef FC5U
		case HOLDINGE:
//			if (pos->hold[4] == Either(card)) 
#ifndef SWAPREM1
			if (pos->hold[4] == Either(card)) 
#else
			if (pos->hold[4] == card) 
#endif
			{
				pos->hold[4] = 0;
				if (Swapit)
					holdA[4] = 0 ;
			}	
			else
				Free1ErrorAbort ("Needed card is not in FreeCell E.");
			break;

		case HOLDINGF:
//			if (pos->hold[5] == Either(card)) 
#ifndef SWAPREM1
			if (pos->hold[5] == Either(card)) 
#else
			if (pos->hold[5] == card) 
#endif
			{
				pos->hold[5] = 0;
				if (Swapit)
					holdA[5] = 0 ;
			}	
			else
				Free1ErrorAbort ("Needed card is not in FreeCell F");
			break;

		case HOLDINGG:
//			if (pos->hold[6] == Either(card)) 
#ifndef SWAPREM1
			if (pos->hold[6] == Either(card)) 
#else
			if (pos->hold[6] == card) 
#endif
			{
				pos->hold[6] = 0;
				if (Swapit)
					holdA[6] = 0 ;
			}	
			else
				Free1ErrorAbort ("Needed card is not in FreeCell G");
			break;
#ifdef FC8S
		case HOLDINGH:
//			if (pos->hold[7] == Either(card)) 
#ifndef SWAPREM1
			if (pos->hold[7] == Either(card)) 
#else
			if (pos->hold[7] == card) 
#endif
			{
				pos->hold[7] = 0;
				if (Swapit)
					holdA[7] = 0 ;
			}	
			else
				Free1ErrorAbort ("Needed card is not in FreeCell H");
			break;
/*
		case HOLDINGI:
//			if (pos->hold[8] == Either(card)) 
#ifndef SWAPREM1
			if (pos->hold[8] == Either(card)) 
#else
			if (pos->hold[8] == card) 
#endif
			{
				pos->hold[8] = 0;
				if (Swapit)
					holdA[8] = 0 ;
			}	
			else
				Free1ErrorAbort ("Needed card is not in FreeCell I");
			break;
*/
#endif
#endif
#else
		case HOLDING:
		{
			// move card from freecell
			int i;
			for (i=0; i<4; i++) 
			{
//				if (pos->hold[i] == Either(card)) 
#ifndef SWAPREM1
				if (pos->hold[i] == Either(card)) 
#else
			if (pos->hold[i] == card) 
#endif
				{
					pos->hold[i] = 0;
					break;
				}
			}

			SortHoldingArea(pos);
		}
		break;
#endif
		default:
		{
			Column *col = &pos->tableau[Col(*where)];
			col->count--;
			col->cards[col->count] = 0;
			if (col->count == 0) SortColumns(pos);
			else if (whither != FOUNDATION &&
#ifndef SWAPREM1
				col->cards[col->count-1] == ((Either(card)+1) ^ 0x10))
#else
				col->cards[col->count-1] == ((card+1) ^ 0x10))
#endif
				pos->mustTry = Col(*where);
		}
	}

	*where = whither;
	switch (whither)
	{
		case FOUNDATION:
			pos->foundations[Suit(card)]++;
			break;
#if FC4
		case HOLDINGA:
#ifndef SWAPREM1
			pos->hold[0] = Either(card);
			if (Swapit)
				holdA[0] = card ;
#else
			pos->hold[0] = card ;
#endif
			break;

		case HOLDINGB:
//			pos->hold[1] = Either(card);
#ifndef SWAPREM1
			pos->hold[1] = Either(card);
			if (Swapit)
				holdA[1] = card ;
#else
			pos->hold[1] = card ;
#endif
			break;

		case HOLDINGC:
//			pos->hold[2] = Either(card);
#ifndef SWAPREM1
			pos->hold[2] = Either(card);
			if (Swapit)
				holdA[2] = card ;
#else
			pos->hold[2] = card ;
#endif
			break;

		case HOLDINGD:
//			pos->hold[3] = Either(card);
#ifndef SWAPREM1
			pos->hold[3] = Either(card);
			if (Swapit)
				holdA[3] = card ;
#else
			pos->hold[3] = card ;
#endif
			break;
#ifdef FC5U
		case HOLDINGE:
#ifndef SWAPREM1
			pos->hold[4] = Either(card);
			if (Swapit)
				holdA[4] = card ;
#else
			pos->hold[4] = card ;
#endif
			break;

		case HOLDINGF:
#ifndef SWAPREM1
			pos->hold[5] = Either(card);
			if (Swapit)
				holdA[5] = card ;
#else
			pos->hold[5] = card ;
#endif
			break;

		case HOLDINGG:
#ifndef SWAPREM1
			pos->hold[6] = Either(card);
			if (Swapit)
				holdA[6] = card ;
#else
			pos->hold[6] = card ;
#endif
			break;
#ifdef FC8S
		case HOLDINGH:
#ifndef SWAPREM1
			pos->hold[7] = Either(card);
			if (Swapit)
				holdA[7] = card ;
#else
			pos->hold[7] = card ;
#endif
			break;
/*
		case HOLDINGI:
#ifndef SWAPREM1
			pos->hold[8] = Either(card);
			if (Swapit)
				holdA[8] = card ;
#else
			pos->hold[8] = card ;
#endif
			break;
*/
#endif
#endif
#else
		case HOLDING:
			// move card to freecell
			pos->hold[3] = Either(card);
			SortHoldingArea(pos);
			break;
#endif
		default:
		{
			Column *col = &pos->tableau[Col(whither)];
#ifndef SWAPREM1
			col->cards[col->count++] = Either(card);
#else
			col->cards[col->count++] = card;
#endif
			if (col->count == 1) SortColumns(pos);
			
			if (Index(whither) != col->count-1) 
			{
				Free1ErrorAbort ("Bug! Moved to wrong index %x in column.",
								whither);
				return 0;
			}
		}
	}

	pos->moved = card;

	return 1;
}

BOOL PrintMove (Loc whither)
{
BOOL retc ;
	switch (whither)
	{
#if FC4
		case HOLDINGA: 
			printf("freecellA");	
			retc = FCSolveMove ('a') ;
			break;
		case HOLDINGB: 
			printf("freecellB");	
			retc = FCSolveMove ('b');
			break;
		case HOLDINGC: 
			printf("freecellC");	
			retc = FCSolveMove ('c');
			break;
		case HOLDINGD: 
			printf("freecellD");	
			retc = FCSolveMove ('d');
			break;
#ifdef FC5U
		case HOLDINGE: 
			printf("freecellE");	
			retc = FCSolveMove ('e');
			break;
		case HOLDINGF: 
			printf("freecellF");	
			retc = FCSolveMove ('f');
			break;
		case HOLDINGG: 
			printf("freecellG");	
			retc = FCSolveMove ('g');
			break;
#ifdef FC8S
		case HOLDINGH: 
			printf("freecellH");	
			retc = FCSolveMove ('k');
			break;
/*
		case HOLDINGI: 
			printf("freecellI");	
			retc = FCSolveMove ('l');
			break;
*/
#endif
#endif
#else
		case HOLDING: 
			printf("freecell"); 
			retc = FCSolveMove ('d');
			break;
#endif
		case FOUNDATION: 
			printf("homecell"); 
			retc = FCSolveMove ('h');
			break;
		default: 
			printf("column %d", 1+Col(whither));
			retc = FCSolveMove ((char) ('1' + Col(whither)));
	}
return (retc) ;
}

static BOOL ShowMove(pos, tag, swap) 
Position *pos; 
char *tag; 
int swap;
{
	Card moved = pos->moved;
	// we dont know the location of the card before the 
	// move, we have to get that from previous position
	// we cant simply use the via pointer tho due to the
	// swapvia situation, so its done in FollowPath
	Loc whither = pos->location[cardToIndex[moved]];

	printf("%4d: ", depth);

	ShowCard (swap ? Colormate(moved) : moved);
	
	printf("-> ");

	if (!PrintMove (whither))
		return FALSE ;
	if (tag) printf(" (%s)", tag);
	printf("\n");
	
	if (verbosity > 2) fflush(stdout);
	return TRUE ;
}

//
// return pointer to via or swapvia, if it was used
//
static Position	*GetVia (Position *pos, Position *p)
{
	Position *prev_p = p->via;
#ifndef SWAPREM1
	int index = cardToIndex[Either(p->moved)];
#else
	int index = cardToIndex[p->moved];
#endif

#ifndef SPEEDTRY5
if (pos->swappable[index] == DID_SWAP)
{
	sprintf(szTemp, "SVds posd-%d pcs-%d", pos->swappable[index], p->swappable[index]) ;
	MainMessage(szTemp) ;
}
	if (pos->swappable[index] == DID_SWAP &&
       	  p->swappable[index] == CAN_SWAP) 
	{									
//MainMessage("SV") ;
		if (p->swapvia) 
		{
			prev_p = p->swapvia;
		}
	}
#endif

	return prev_p;
}

/* Show the winning path, in reverse order 
	(because it's convenient - for the code!).
 */
/*
static int FollowPath(pos, tally) Position *pos; int tally;
{
	Position *p = pos;
	int steps = 0;


	while (p->moved) {
		int swap = false, index = cardToIndex[Either(p->moved)];
		if (pos->swappable[index] == DID_SWAP &&
		    p->swappable[index] == CAN_SWAP) {
			if (p->swapvia) {
				if (!tally) {
					printf("  Bypassing seq that swaps ");
					ShowCard(p->moved);
					printf(" with ");
					ShowCard(Colormate(p->moved));
					printf("\n");
				}
				p = p->swapvia;
				continue;
			}
			else swap = true;
		}
		if (tally) steps++;
		else {ReadablePosition(p); ShowMove(p, NULL, swap); depth--;}
		p = p->via;
	}
	if (tally) windepth = steps;
	return(steps);
}
*/
static int FollowPath(pos, tally) 
Position *pos;  // position to start from
int tally;
{
	Position *p = pos, *prev_p;
	int steps = 0;
//	Loc  temp;

	while (p->moved) 
	{

#ifndef SPEEDTRY5
		int swap = false, index = cardToIndex[Either(p->moved)];

if (pos->swappable[index] == DID_SWAP)
{
	sprintf(szTemp, "FPds posd-%d pcs-%d", pos->swappable[index], p->swappable[index]) ;
	MainMessage(szTemp) ;
}

		if (pos->swappable[index] == DID_SWAP &&
       	      p->swappable[index] == CAN_SWAP) 
		{									
			Free1ErrorAbort ("Swap in solution.");
			return 0;

			if (p->swapvia) 
			{
				if (!tally) 
				{
					printf("[[[Bypassing seq that swaps ");
					ShowCard(p->moved);
					printf(" with ");
					ShowCard(Colormate(p->moved));
					printf("\n");

					// we cannot bypass this for playback.
					// try to swap them using a freecell.
// Below section begins here
// Below section ends here
				}
				p = p->swapvia;
				continue;
			}
			else
			{
				swap = true;
			}
		}
#endif
		if (tally) 
		{
			steps++;
		}
		else 
		{
			ReadablePosition(p); 
			// get position we moved to
#ifndef SPEEDTRY5
			if (!ShowMove(p, NULL, swap))
				return -1 ;
#else			
			if (!ShowMove(p, NULL, false))
				return -1 ;
#endif
			// get the via or swapvia pointer
			prev_p = GetVia (pos, p);

			// get position of card we moved in last position
			printf("From ");
			if (!PrintMove (prev_p->location[cardToIndex[p->moved]]))
				return -1 ;
			printf("\n");
			depth--;
		}
		p = p->via;
	}
	if (tally) 
	{
		windepth = steps;
	}

	return(steps);
}

// begin -- moved from above
/*					temp = FOUNDATION;
					for (i = 0; i <= 3; i++)
					{
						if (p->hold[i] == 0)
						{
							temp = HOLDING_BASE + i;
							break;
						}
					}

			  		if (temp != FOUNDATION) 
					{
						// we found a freecell
						;
					}
					// try to swap them using columns
					else if (HasSpace(p))
					{
						temp = p->colSeq[7] << 5;
					}
					// we cant swap them!
					else
					{
						MainMessage ("We cannot perform needed swap!");
						return 0;
					}

					// these have to be backwards since we are
					// following path - it reads the same 
					// backwards and forwards!
					PrintMove (p->location[cardToIndex[Colormate(p->moved)]]);
					PrintMove (temp);
					printf("\n");
					PrintMove (p->location[cardToIndex[p->moved]]);
					PrintMove (p->location[cardToIndex[Colormate(p->moved)]]);
					printf("\n");
					PrintMove (temp);
					PrintMove (p->location[cardToIndex[p->moved]]);
					printf("]]]\n");
*/
// end -- moved from above

static BOOL ShowPath(pos) 
Position *pos;
{
	//Position *p = pos;
	printf("Winning path (in reverse order):\n");
	depth = FollowPath(pos, true);
//	(void) FollowPath(pos, false);
	if (FollowPath(pos, false) == -1)
		return FALSE ;
	printf("\n");
	return TRUE ;
}

/* Make (and if verbose, print) a move, then recursively call 
	DFS if the resulting position is new.
 */
static Position *TryMove(via, pos, card, whither, calling_code)
Position *via, *pos; Card card; Loc whither; char calling_code;
{
	int dup = false;

//	dup = false;
	printf("calling_code:%d\n", calling_code);

	// move card

	depth++;
	
	*pos = *via;
	pos->via = via;
if (!Swapit)
{
	if (MoveCard (pos, card, whither, calling_code))
	{
		// check if the result is a new tree
		
		// if not holding
	//	if ((whither & 0x1F) != 0x1F) 
		if ((whither & HOLDING_MASK) != HOLDING_MASK) 
		{
			/* moved to col; check for repetition */
		
//			int i = Col(whither);
//			Column *col = &pos->tableau[i];
//			Position *prev;
			i = Col(whither);
			col = &pos->tableau[i];
			
			for (prev=via; prev; prev=prev->via) 
			{
//				Column *oldcol = &prev->tableau[i];
				oldcol = &prev->tableau[i];
				if (oldcol->count != 0 &&
					oldcol->cards[0] != col->cards[0]) break;
				if (oldcol->count == col->count &&
					memcmp(oldcol->cards, col->cards,
					   col->count*sizeof(Card)) == 0) {
//					int j;
					for (j=0; j<col->count; j++) {
//						int x = cardToIndex[col->cards[j]];
//						int xx = x;
						x = cardToIndex[col->cards[j]];
						xx = x;
						if (pos->location[x] != (i<<5)+j)
							xx += 26;
#ifndef SPEEDTRY5
						if (prev->location[xx] != pos->location[xx]
							|| prev->swappable[x] != pos->swappable[x]) break;
#else
						if (prev->location[xx] != pos->location[xx]) break;
#endif
					}
					if (j >= col->count) dup = true;
					break;
				}
			}
		}

	}
	else
	{
		// move required swap, which we didnt do, so this is not
		// a new tree
		
	if ((gnSolve != SOLVE_RANGE) &&	(gnSolve != SOLVE_LIST))
	{
		Free1ErrorAbort ("Swap requested for solution (%d).",
							calling_code);
	}	
	else
	{
		AppError = 1 ;
	}
    dup = true;
		
		// will we simply keep trying this move tho?
	}
}
else
{
	MoveCard(pos, card, whither);
//	if ((whither & 0x1F) != 0x1F) {
		if ((whither & HOLDING_MASK) != HOLDING_MASK) 
		{
			/* moved to col; check for repetition */
//			Column *col = &pos->tableau[i];
//			Position *prev;
			i = Col(whither);
			col = &pos->tableau[i];
		for (prev=via; prev; prev=prev->via) {
//				Column *oldcol = &prev->tableau[i];
				oldcol = &prev->tableau[i];
			if (oldcol->count != 0 &&
			    oldcol->cards[0] != col->cards[0]) break;
			if (oldcol->count == col->count &&
			    memcmp(oldcol->cards, col->cards,
				   col->count*sizeof(Card)) == 0) {
//				int j;
				for (j=0; j<col->count; j++) {
					int x = cardToIndex[col->cards[j]];
					int xx = x;
					if (pos->location[x] != (i<<5)+j)
						xx += 26;
					if (prev->location[xx] != pos->location[xx]
					    || prev->swappable[x] != pos->swappable[x]) break;
				}
				if (j >= col->count) dup = true;
				break;
			}
		}
	}
}
	if (dup) 
	{
		if (verbosity >= 2) ShowMove(pos, "rejected", false);
		rejected++;
	}
	else if (AddToTree(pos)) 
	{
#ifndef SPEEDTRY5
		if (verbosity >= 2)
			ShowMove(pos, (pos->swapvia ? "merged" : NULL), false);
#endif
		// does merged lose us hands we need?

		pos = DFS(pos, NewPosition());
		if (pos == NULL) return(NULL);
	}
	else if (verbosity >= 2) 
	{
		ShowMove(pos, "old", false);
	}
	depth--;
	return(pos);
}

/* Depth-first search.  Generate all positions reachable from 
   "via".  (If
 * there is a forced move, just do the forced move.)  Use "pos" 
	as the
 * place to construct new positions; ask for a new pos struct as 
	needed.
 * For positions that haven't already been reached, add them and 
	call DFS
 * recursively via TryMove.  If a winning position is found, 
	return NULL.
 * Else return a pointer to a not-yet-used Position struct.
 */
static Position *DFS(via, pos) Position *via, *pos;
{
//register int i, j, intab = 0, goodcols = 0; Card moved, below ; Loc onto;
register int i = 0, j = 0, intab = 0, goodcols = 0; Card moved ; Loc onto;
//register int ia, ib, ic, id, ie, ig, ih, ii, ij, ik, il, im, in, io, ip, iq, ir, is, it, iu, iv ;
//register int ja, jb, jc, jd, je, jg, jh, ji, jj, jk, jl, jm, jn, jo, jp, jq, jr, js, jt, ju, jv ;
//ia= ib= ic= id= ie= ig= ih= ii= ij= ik= il= im= in= io= ip= iq= ir= is= it= iu= iv= 0 ;
//ja= jb= jc= jd= je= jg= jh= ji= jj= jk= jl= jm= jn= jo= jp= jq= jr= js= jt= ju= jv= 0 ;
	// check for Max. Hands (V4.3)
//Position *pos2 ;
gbMemOver = gbStackOver = FALSE ;
if (pos == NULL)
{
	gbAbort = gbAbortM = TRUE ;
	gbMemOver = TRUE ;
	return (NULL) ;
} 
if (depth > 254000) // Limit empirically determined for stack size of 32 megs.
{
	gbAbort = gbAbortM = TRUE ;
	gbStackOver = TRUE ;
	if ((gnSolve != SOLVE_RANGE) && (gnSolve != SOLVE_LIST))
		Free1ErrorAbort ("Intractable.\n(Out of stack space.)");
	return (NULL) ;
} 
  if ((!SMode) || (gnRptEnbl == 2))
  {
	  if ((gnMaxHands && (generated % 100 == 0) && (generated > gnMaxHands))
			|| gbAbort || gbAbortA) 
	  {
 	    gbAbort = TRUE ;
	    return (NULL) ;
	  }
	if (gnMaxTime && (generated % 1000 == 0))
	  {
	  time (&etime) ;
	  if ((etime - stime) > gnMaxTime)
	    { 
	    gbAbort = TRUE ;
	    return (NULL) ;
	    }
	 }
  }
  else
//	if ((generated > 1000000) || gbAbort || gbAbortA)
	if (gbAbortA)
	    { 
	    gbAbort = TRUE ;
	    return (NULL) ;
	    }
//	if (SMode && (PresortC[0] == 'X') && ((gnRptEnbl == 4) || (gnRptEnbl == 1)))
	if (SMode && (PresortC[0] == 'X') && (gnRptEnbl == 4))
//  if (SMode && (PresortC[0] == 'X'))
//	if (SMode)
	{
	if	((gnMaxSpace && (generated % 100 == 0))
			&& (distinct > gnMaxSpace * 1000000 / (long)sizeof(Position)))
		{
 			gbAbort = gbAbortM = TRUE ;
//			if (gnRptEnbl == 1)
//				gnRptEnbl = 0 ;
			if (PresortC[1] == 'P')
				PresortC[1] = '-' ; 
			else
				PresortC[1] = '/' ;
			return (NULL) ;
		}
	if (gnMaxTimeB && (generated % 1000 == 0))
	  {
	  time (&etime) ;
	  if ((etime - stime) > gnMaxTimeB * 60)
	    { 
//sprintf(szTemp, "TO re- %d", gnRptEnbl) ;
//MainMessage(szTemp) ; 
		gbAbort = gbAbortM = TRUE ;
			if (gnRptEnbl == 1)
				gnRptEnbl = 0 ;
//		gnRptEnbl = 0 ;
		if (PresortC[1] == 'P')
			PresortC[1] = '-' ; 
		else
			PresortC[1] = '/' ;
//MainMessage("TimeOut 1") ;
		return (NULL) ;
	    }
	  }
	}
  // check for user break
	if (!gbSolver)
	{
		return (NULL);
	}

	/* check for victory */
	if (via->foundations[0] == 13 && via->foundations[1] == 13
		&& via->foundations[2] == 13 && via->foundations[3] == 13) 
//	if (generated > 100)	// to show intermediate state for diagnostic
	{
		if (show) 
		{
			if (!ShowPath(via))
			{
				gbAbort = TRUE ;
				return (NULL) ;
			}	
		}
		else if (verbosity > 0) (void) FollowPath(via, true);
		return(NULL);
	}

	if (maxdepth > 99999) 
	{
		if (depth > maxout) maxout = depth;
	}
	else if (depth >= maxdepth) 
	{
		maxout++;
		return(pos);
	}

//	if (distinct >= TRACTABLE) return(pos);	/* give up */

	// depends on holding fc3
//	for (i=3; i>=0 && via->hold[i]==0; i--) 
//	{ }

	// count empty holding cells
	for (j = 0, i = 0; j <= (NUM_FCS - 1); j++)
	{
#ifndef WILSON3
		if (via->hold[j] == 0) 
#else
		if (via->hold[j] != 0) 
#endif
		{
			i++;
		}
	}

	for (j=7; j>=0 && via->tableau[via->colSeq[j]].count==0; j--)
	{ }

	i = (3 - i + 1) << (7 - j);

	if (i > maxfree) 
	{
		maxfree = i;
		/* if (i == 6) ReadablePosition(via); */
	}

	/* check for forced moves to foundation */

	for (i=0; i<4; i++) 
	{
		int opp1 = (i^1), opp2 = (opp1^2);	/* other color suits */
//		opp1 = (i^1) ;
//		opp2 = (opp1^2) ;	/* other color suits */
		j = via->foundations[i]+1;	/* next rank to go here */

		if (j > 13 || via->foundations[opp1]+2 < j ||
		    via->foundations[opp2]+2 < j) continue;
		
		/* move is forced if card is available; note that if card
	   is swappable with its colormate, then if either card is
	   available they both are, since next lower cards of other
	   color are by definition already moved to foundations */
		
		moved = (i<<4) + j;
		
		if (Available(via, moved))
		{
#ifndef WILSON6
			return TryMove(via, pos, moved, (Loc) FOUNDATION, 0);
/*
			pos2 = TryMove(via, pos, moved, (Loc) FOUNDATION, 0) ;
			if (pos2)
				return pos2 ;
			else
				sprintf(szTemp, "FHR card- %x", moved) ;
				MainMessage(szTemp) ;
*/
#else
			pos = TryMove(via, pos, moved, (Loc) FOUNDATION, 0) ;
			if (pos == NULL) return (NULL) ;
#endif
		}

		/* card not available, but note good column to dig in */
		
		goodcols |= (1 << Col(via->location[cardToIndex[moved]]));
	}
	
	/* if previous move broke a sequence (and didn't move to 
		foundation),
	   then mustTry will be >= 0, saying we must move to/from 
	   that 
	   column if it is possible to do so */
	
	if (via->mustTry >= 0) 
	{
		Column *col = &via->tableau[via->mustTry];
//		int tried = false;
		j = false ;			// j substitued for tried to reduce no. of internal variables
		
		moved = Bottom(via, via->mustTry);
		
		/* if not a King, try moving to another non-empty column */
		
		if (Rank(moved) < 13) 
		{
			onto = (moved+1) ^ 0x10;

			for (i=0; i<2; i++) 
			{
				Loc loc = via->location[cardToIndex[onto]];

//				if (Available(via, onto) && loc != HOLDING) 
				// use holding mask
				if (Available(via, onto) && 
					((loc & HOLDING_MASK) != HOLDING_MASK))
				{
					j = true;
					pos = TryMove(via, pos, moved, loc+1, 1);
					if (pos == NULL) return(NULL);
				}
				onto = Colormate(onto);
			}
		}

		/* if can't move within tableau, try moving to holding 
			area or, if that's full, to empty column */

		onto = FOUNDATION;
//		if (via->hold[3] == 0) onto = HOLDING;
//		else if (HasSpace(via)) onto = (via->colSeq[7]<<5) + 0;
		// have to check all fcs, not just fc3
//		for (i = 3; i >= 0; i--)
		for (i = NUM_FCS - 1 ; i >= 0; i--)
		{
			if (via->hold[i] == 0)
			{
				onto = HOLDING_BASE + i;
				break;
			}
		}

		if ((onto == FOUNDATION) && HasSpace(via)) 
			onto = (via->colSeq[7]<<5) + 0;

		if (!j && onto != FOUNDATION &&
		    (col->count>1 || !HasSpace(via))) 
		{
			j = true;
			pos = TryMove(via, pos, moved, onto, 2);
			if (pos == NULL) return(NULL);
		}

		/* if neither of the above, try move to foundation 
			(if can move
		   elsewhere, will try moving to foundation from there) */

		if (!j && (via->foundations[Suit(moved)]+1 == Rank(moved))) 
		{
			j = true;
			pos = TryMove(via, pos, moved, (Loc) FOUNDATION, 3);
			if (pos == NULL) return(NULL);
		}
		
		/* move colormate of just-moved card onto revealed card */

		if (Available(via, Colormate(via->moved))) 
		{
			j = true;
			pos = TryMove(via, pos, Colormate(via->moved),
				      (via->mustTry<<5) + col->count, 4);
			if (pos == NULL) return(NULL);
		}
		
		/* if this column is a singleton and the only place it 
			can
		   move is into another empty column, abandon the line */

		if (col->count == 1 && via->tableau[via->colSeq[7]].count == 0)
		{
			j = true;
		}

		if (j) 
		{
			brokeSeq++;
#ifndef WILSON7
			return(pos);
#else
			if (pos == NULL) return(NULL);
#endif
		}
	}

if (!OMode)
{
	/* try non-forced moves to foundation, but don't move the second
	   of colormates up if both lower cards are still in play */
   for (i=0; i<4; i++) 
	{
		j = via->foundations[i]+1;	/* next rank to go here */
		if (j > 13) continue;
		if (via->foundations[i^2] >= j 
			&& via->foundations[i^1]+2 < j
		    && via->foundations[i^3]+2 < j) continue;
		moved = (i<<4) + j;

		/* if card & colormate both avail, moving original 
			suffices;
		   other must then be able to move to where original was 
		*/

		if (Available(via, moved))
		{
			pos = TryMove(via, pos, moved, (Loc) FOUNDATION, 5);
			if (pos == NULL) return(NULL);
		}

#ifndef SPEEDTRY5
//		else if (via->swappable[cardToIndex[Either(moved)]] &&
		else if (Swapit && via->swappable[cardToIndex[Either(moved)]] &&
	    		 Available(via, Colormate(moved))) 
		{
			pos = TryMove(via, pos, moved, (Loc) FOUNDATION, 6);
			if (pos == NULL) return(NULL);
		}
#endif

  }
if ((!OMode2) || ((OMode2 == 2) && (generated < gnMaxHands)))
{
	/* next preference is moves onto the bottoms of non-empty 
		columns;
	   cards which can do this never need to move to empty cols 
	   or holding cells (though in some odd cases they may end up 
	   moving from the other col to a holding cell) */

	for (i=0; i<8; i++) 
	{
//		Column *col = &via->tableau[i];
		coldf = &via->tableau[i];
		if (coldf->count == 0) continue;
		/* bottom card guaranteed to be > Ace else force-move 
			above */
		moved = (coldf->cards[coldf->count - 1] - 1) ^ 0x10;
		onto = (i<<5) + coldf->count;
		for (j=0; j<2; j++) 
		{
			if (Available(via, moved)) 
			{
				Loc where;
				pos = TryMove(via, pos, moved, onto, 7);
				if (pos == NULL) return(NULL);
				where = via->location[cardToIndex[moved]];
//				if (where != HOLDING)
				// use mask
				if ((where & HOLDING_MASK) != HOLDING_MASK)
				{
					intab |= 1 << (Col(where));
				}
			}
			moved ^= 0x20;
		}
	}
}
	/* next try moving from columns with 2+ cards to hold; if no 
		hold,
	   move to empty columns; (if both, can get to empty cols 
		via hold) */
	onto = FOUNDATION;
//	if (via->hold[3] == 0) onto = HOLDING;
	// can just check fc3!
//	for (i = 3; i >= 0; i--)
	for (i = NUM_FCS - 1; i >= 0; i--)
	{
		if (via->hold[i] == 0)
		{
				onto = HOLDING_BASE + i;
			break;
		}
	}

	if ((onto == FOUNDATION) && 
	    (via->tableau[via->colSeq[7]].count == 0))
	{
		onto = (via->colSeq[7]<<5) + 0;
	}

	if (onto != FOUNDATION) 
	{
		for (i=0; i<8; i++)
		{
			if (((goodcols & (1<<i)) != 0)
				&& ((intab & (1<<i)) == 0))
			{
				if (via->tableau[i].count < 2) continue;
				pos = TryMove(via, pos, Bottom(via, i), onto, 8);
				if (pos == NULL) return(NULL);
			}
		}
		
		for (i=0; i<8; i++)
		{
			if (((goodcols & (1<<i)) == 0) 
				&& ((intab & (1<<i)) == 0))
			{
				if (via->tableau[i].count < 2) continue;
				pos = TryMove(via, pos, Bottom(via, i), onto, 9);
				if (pos == NULL) return(NULL);
			}
		}
	}
if (OMode2)
{
	/* next preference is moves onto the bottoms of non-empty 
		columns;
	   cards which can do this never need to move to empty cols 
	   or
	   holding cells (though in some odd cases they may end up 
	   moving from the other col to a holding cell) */

	for (i=0; i<8; i++) 
	{
//		Column *col = &via->tableau[i];
		coldf = &via->tableau[i];
		if (coldf->count == 0) continue;
		/* bottom card guaranteed to be > Ace else force-move 
			above */
		moved = (coldf->cards[coldf->count - 1] - 1) ^ 0x10;
		onto = (i<<5) + coldf->count;
		for (j=0; j<2; j++) 
		{
			if (Available(via, moved)) 
			{
				Loc where;
				pos = TryMove(via, pos, moved, onto, 7);
				if (pos == NULL) return(NULL);
				where = via->location[cardToIndex[moved]];
//				if (where != HOLDING)
				// use mask
				if ((where & HOLDING_MASK) != HOLDING_MASK)
				{
					intab |= 1 << (Col(where));
				}
			}
			moved ^= 0x20;
		}
	}
}
	/* try moving from holding area to empty column; vary which 
		one is
	   tried first, in case the key move we're looking for is 
		hold[3] */
	if (via->tableau[via->colSeq[7]].count == 0) 
	{
//		for (i=0; i<4; i++) 
		for (i=0; i<NUM_FCS; i++) 
		{
//			Card below;
/*
			if (NUM_FCS > 1)
			  moved = via->hold[((i+(depth>>2))&3)%(NUM_FCS - 1)];
			else
			  moved = via->hold[0];
*/
#ifndef FC5U
			moved = via->hold[(i+(depth>>2))&3];
#else
		  if (NUM_FCS <= 4)
		  {
			  moved = via->hold[(i+(depth>>2))&3];
			  if (NUM_FCS == 3)
				  moved = via->hold[(i+(depth>>2))%3];
			  if (NUM_FCS == 2)
				  moved = via->hold[(i+(depth>>2))&1];
			  if (NUM_FCS == 1)
				  moved = via->hold[0];
		  }
		  else
		    moved = via->hold[((i+(depth>>2))&7)];
#endif
			if (moved == 0) continue;
//			if (via->location[cardToIndex[moved]] != HOLDING)
			// use mask
			if (((via->location[cardToIndex[moved]] & HOLDING_MASK) 
				!= HOLDING_MASK) || (via->location[cardToIndex[moved]] == FOUNDATION))
			{
				moved ^= 0x20;
			}

			/* don't move a card down if both cards that could
			   use it are already on foundations */

#if SWAPIT
			if ((!Swapit && (via->location[cardToIndex[(moved-1)^0x10]] != FOUNDATION
			    || (via->location[cardToIndex[((moved-1)^0x10)^0x20]] != FOUNDATION))
				&& (Available(pos, moved)))	||
				(Swapit && (via->location[cardToIndex[(moved-1)^0x10]] != FOUNDATION
			    || (via->location[cardToIndex[((moved-1)^0x10)^0x20]] != FOUNDATION))))
#else
			if ((via->location[cardToIndex[(moved-1)^0x10]] != FOUNDATION
			    || (via->location[cardToIndex[((moved-1)^0x10)^0x20]] != FOUNDATION))
				&& Available(pos, moved))  // dont swap 
#endif
			{
				pos = TryMove(via, pos, moved,
					      (Loc) ((via->colSeq[7]<<5)+0), 10);
				if (pos == NULL) return(NULL);
			}
		}
	}

	/* try moving from singleton columns to holding area, but 
		only if
	   there isn't another empty column already */
//	if (via->hold[3] == 0 && !HasSpace(via)) 
	// cant just check fc3
/*
	if (NUM_FCS && 
#ifdef FC5U
		((NUM_FCS == 7) && (via->hold[6] == 0 || via->hold[5] == 0 || via->hold[4] == 0 ||
		via->hold[3] == 0 || via->hold[2] == 0 || via->hold[1] == 0 ||
		via->hold[0] == 0)) || 
		((NUM_FCS == 6) && (via->hold[5] == 0 || via->hold[4] == 0 || via->hold[3] == 0 ||
		via->hold[2] == 0 || via->hold[1] == 0 || via->hold[0] == 0)) || 
		((NUM_FCS == 5) && (via->hold[4] == 0 || via->hold[3] == 0 || via->hold[2] == 0 || 
	     via->hold[1] == 0 || via->hold[0] == 0)) || 
#endif
		 ((NUM_FCS == 4) && (via->hold[3] == 0 || via->hold[2] == 0 || 
	     via->hold[1] == 0 || via->hold[0] == 0)) || 
		((NUM_FCS == 3) && (via->hold[2] == 0 || via->hold[1] == 0 || via->hold[0] == 0)) ||
		((NUM_FCS == 2) && (via->hold[1] == 0 || via->hold[0] == 0)) ||
		((NUM_FCS == 1) && (via->hold[0] == 0))
		&& !HasSpace(via)) 
//	if ((via->hold[3] == 0 || via->hold[2] == 0 || via->hold[1] == 0 || via->hold[0] == 0) 
//		&& !HasSpace(via)) 
*/
	for (i = 0 ; i < NUM_FCS ; i++)
	{
		if (via->hold[i] == 0)
			break ;
	}
	if (NUM_FCS && (i != NUM_FCS) && !HasSpace(via))
	{ 
		for (i=0; i<8; i++) 
		{
			if ((intab & (1<<i)) == 0) 
			{
				if (via->tableau[i].count != 1) continue;

//				pos = TryMove (via, pos, Bottom(via, i), 
//								(Loc) HOLDING);
				// move to holding
//				for (j = 3; j >= 0; j--)
				for (j = NUM_FCS - 1; j >= 0; j--)
				{
					if (via->hold[j] == 0)
					{
						pos = TryMove (via, pos, Bottom(via, i), 
							(Loc) (HOLDING_BASE + j), 11);
						break;
					}
				}

				if (pos == NULL) return(NULL);
			}
		}
	}

  /* last, try non-forced moves to foundation, where we're 
		moving
	   up the second of colormates and both lower cards are in 
		play */
	for (i=0; i<4; i++) 
	{
		j = via->foundations[i]+1;	/* next rank to go here */
		if (j > 13) continue;
		if (!(via->foundations[i^2] >= j 
			&& via->foundations[i^1]+2 < j
		    && via->foundations[i^3]+2 < j)) continue;
		moved = (i<<4) + j;
		if (Available(via, moved)) 
		{
			pos = TryMove(via, pos, moved, (Loc) FOUNDATION, 12);
			if (pos == NULL) return(NULL);
		}
	}
}  //!OMode
else
{	
	/* next preference is moves onto the bottoms of non-empty 
		columns;
	   cards which can do this never need to move to empty cols 
	   or
	   holding cells (though in some odd cases they may end up 
	   moving from the other col to a holding cell) */

	for (i=0; i<8; i++) 
	{
		coldf = &via->tableau[i];
		if (coldf->count == 0) continue;
		/* bottom card guaranteed to be > Ace else force-move 
			above */
		moved = (coldf->cards[coldf->count - 1] - 1) ^ 0x10;
		onto = (i<<5) + coldf->count;
		for (j=0; j<2; j++) 
		{
			if (Available(via, moved)) 
			{
				Loc where;
				pos = TryMove(via, pos, moved, onto, 7);
				if (pos == NULL) return(NULL);
				where = via->location[cardToIndex[moved]];
//				if (where != HOLDING)
				// use mask
				if ((where & HOLDING_MASK) != HOLDING_MASK)
				{
					intab |= 1 << (Col(where));
				}
			}
			moved ^= 0x20;
		}
	}

if ((NUM_FCS > 3) && (OMode == 1))
  {
	/* next try moving from columns with 2+ cards to hold; if no 
		hold,
	   move to empty columns; (if both, can get to empty cols 
		via hold) */
	onto = FOUNDATION;
//	if (via->hold[3] == 0) onto = HOLDING;
	// can just check fc3!
//	for (i = 3; i >= 0; i--)
	for (i = NUM_FCS - 1; i >= 0; i--)
	{
		if (via->hold[i] == 0)
		{
			onto = HOLDING_BASE + i;
			break;
		}
	}

	if ((onto == FOUNDATION) && 
	    (via->tableau[via->colSeq[7]].count == 0))
	{
		onto = (via->colSeq[7]<<5) + 0;
	}

	if (onto != FOUNDATION) 
	{
		for (i=0; i<8; i++)
		{
			if (((goodcols & (1<<i)) != 0)
				&& ((intab & (1<<i)) == 0))
			{
				if (via->tableau[i].count < 2) continue;
				pos = TryMove(via, pos, Bottom(via, i), onto, 8);
				if (pos == NULL) return(NULL);
			}
		}
		
		for (i=0; i<8; i++)
		{
			if (((goodcols & (1<<i)) == 0) 
				&& ((intab & (1<<i)) == 0))
			{
				if (via->tableau[i].count < 2) continue;
				pos = TryMove(via, pos, Bottom(via, i), onto, 9);
				if (pos == NULL) return(NULL);
			}
		}
	}

	/* try moving from holding area to empty column; vary which 
		one is
	   tried first, in case the key move we're looking for is 
		hold[3] */
	if (via->tableau[via->colSeq[7]].count == 0) 
	{
//		for (i=0; i<4; i++) 
		for (i=0; i<NUM_FCS; i++) 
		{
//			Card below;
/*
			if (NUM_FCS > 1)
			  moved = via->hold[((i+(depth>>2))&3)%(NUM_FCS - 1)];
			else
			  moved = via->hold[0];
*/
#ifndef FC5U
			moved = via->hold[(i+(depth>>2))&3];
#else
		  if (NUM_FCS <= 4)
		  {
			  moved = via->hold[(i+(depth>>2))&3];
			  if (NUM_FCS == 3)
				  moved = via->hold[(i+(depth>>2))%3];
			  if (NUM_FCS == 2)
				  moved = via->hold[(i+(depth>>2))&1];
			  if (NUM_FCS == 1)
				  moved = via->hold[0];
		  }
		  else
		    moved = via->hold[((i+(depth>>2))&7)];
#endif
			if (moved == 0) continue;
//			if (via->location[cardToIndex[moved]] != HOLDING)
			// use mask
			if (((via->location[cardToIndex[moved]] & HOLDING_MASK) 
				!= HOLDING_MASK) || (via->location[cardToIndex[moved]] == FOUNDATION))
			{
				moved ^= 0x20;
			}

			/* don't move a card down if both cards that could
			   use it are already on foundations */

#if SWAPIT
			if ((!Swapit && (via->location[cardToIndex[(moved-1)^0x10]] != FOUNDATION
			    || (via->location[cardToIndex[((moved-1)^0x10)^0x20]] != FOUNDATION))
				&& (Available(pos, moved)))	||
				(Swapit && (via->location[cardToIndex[(moved-1)^0x10]] != FOUNDATION
			    || (via->location[cardToIndex[((moved-1)^0x10)^0x20]] != FOUNDATION))))
#else
			if ((via->location[cardToIndex[(moved-1)^0x10]] != FOUNDATION
			    || (via->location[cardToIndex[((moved-1)^0x10)^0x20]] != FOUNDATION))
				&& Available(pos, moved))  // dont swap 
#endif
			{
				pos = TryMove(via, pos, moved,
					      (Loc) ((via->colSeq[7]<<5)+0), 10);
				if (pos == NULL) return(NULL);
			}
		}
	}

	/* try moving from singleton columns to holding area, but 
		only if
	   there isn't another empty column already */
//	if (via->hold[3] == 0 && !HasSpace(via)) 
	// cant just check fc3
/*
	if (NUM_FCS &&
#ifdef FC5U
		((NUM_FCS == 7) && (via->hold[6] == 0 || via->hold[5] == 0 || via->hold[4] == 0 ||
		via->hold[3] == 0 || via->hold[2] == 0 || via->hold[1] == 0 ||
		via->hold[0] == 0)) || 
		((NUM_FCS == 6) && (via->hold[5] == 0 || via->hold[4] == 0 || via->hold[3] == 0 ||
		via->hold[2] == 0 || via->hold[1] == 0 || via->hold[0] == 0)) || 
		((NUM_FCS == 5) && (via->hold[4] == 0 || via->hold[3] == 0 || via->hold[2] == 0 || 
	     via->hold[1] == 0 || via->hold[0] == 0)) || 
#endif
		((NUM_FCS == 4) && (via->hold[3] == 0 || via->hold[2] == 0 || 
	     via->hold[1] == 0 || via->hold[0] == 0)) || 
		((NUM_FCS == 3) && (via->hold[2] == 0 || via->hold[1] == 0 || via->hold[0] == 0)) ||
		((NUM_FCS == 2) && (via->hold[1] == 0 || via->hold[0] == 0)) ||
		((NUM_FCS == 1) && (via->hold[0] == 0))
		&& !HasSpace(via)) 
//	if ((via->hold[3] == 0 || via->hold[2] == 0 || via->hold[1] == 0 || via->hold[0] == 0) 
//		&& !HasSpace(via)) 
*/
	for (i = 0 ; i < NUM_FCS ; i++)
	{
		if (via->hold[i] == 0)
			break ;
	}
	if (NUM_FCS && (i != NUM_FCS) && !HasSpace(via))
	{
		for (i=0; i<8; i++) 
		{
			if ((intab & (1<<i)) == 0) 
			{
				if (via->tableau[i].count != 1) continue;

//				pos = TryMove (via, pos, Bottom(via, i), 
//								(Loc) HOLDING);
				// move to holding
//				for (k = 3; k >= 0; k--)
				for (j = NUM_FCS - 1; j >= 0; j--)
				{
					if (via->hold[j] == 0)
					{
						pos = TryMove (via, pos, Bottom(via, i), 
							(Loc) (HOLDING_BASE + j), 11);
						break;
					}
				}

				if (pos == NULL) return(NULL);
			}
		}
	}

	/* try non-forced moves to foundation, but don't move the second
	   of colormates up if both lower cards are still in play */
   for (i=0; i<4; i++) 
	{
		j = via->foundations[i]+1;	/* next rank to go here */
		if (j > 13) continue;
		if (via->foundations[i^2] >= j 
			&& via->foundations[i^1]+2 < j
		    && via->foundations[i^3]+2 < j) continue;
		moved = (i<<4) + j;

		/* if card & colormate both avail, moving original 
			suffices;
		   other must then be able to move to where original was 
		*/

		if (Available(via, moved))
		{
			pos = TryMove(via, pos, moved, (Loc) FOUNDATION, 5);
			if (pos == NULL) return(NULL);
		}

#ifndef SPEEDTRY5
//		else if (via->swappable[cardToIndex[Either(moved)]] &&
		else if (Swapit && via->swappable[cardToIndex[Either(moved)]] &&
	    		 Available(via, Colormate(moved))) 
		{
			pos = TryMove(via, pos, moved, (Loc) FOUNDATION, 6);
			if (pos == NULL) return(NULL);
		}
#endif

  }

  /* last, try non-forced moves to foundation, where we're 
		moving
	   up the second of colormates and both lower cards are in 
		play */
	for (i=0; i<4; i++) 
	{
		j = via->foundations[i]+1;	/* next rank to go here */
		if (j > 13) continue;
		if (!(via->foundations[i^2] >= j 
			&& via->foundations[i^1]+2 < j
		    && via->foundations[i^3]+2 < j)) continue;
		moved = (i<<4) + j;
		if (Available(via, moved)) 
		{
			pos = TryMove(via, pos, moved, (Loc) FOUNDATION, 12);
			if (pos == NULL) return(NULL);
		}
	}

   } //NUM_FCS > 3 or OMode == 1
else   // OMode > 1
    {
	/* try non-forced moves to foundation, but don't move the second
	   of colormates up if both lower cards are still in play */
   for (i=0; i<4; i++) 
	{
		j = via->foundations[i]+1;	/* next rank to go here */
		if (j > 13) continue;
		if (via->foundations[i^2] >= j 
			&& via->foundations[i^1]+2 < j
		    && via->foundations[i^3]+2 < j) continue;
		moved = (i<<4) + j;

		/* if card & colormate both avail, moving original 
			suffices;
		   other must then be able to move to where original was 
		*/

		if (Available(via, moved))
		{
			pos = TryMove(via, pos, moved, (Loc) FOUNDATION, 5);
			if (pos == NULL) return(NULL);
		}

#ifndef SPEEDTRY5
//		else if (via->swappable[cardToIndex[Either(moved)]] &&
		else if (Swapit && via->swappable[cardToIndex[Either(moved)]] &&
	    		 Available(via, Colormate(moved))) 
		{
			pos = TryMove(via, pos, moved, (Loc) FOUNDATION, 6);
			if (pos == NULL) return(NULL);
		}
#endif

  }

  /* last, try non-forced moves to foundation, where we're 
		moving
	   up the second of colormates and both lower cards are in 
		play */
	for (i=0; i<4; i++) 
	{
		j = via->foundations[i]+1;	/* next rank to go here */
		if (j > 13) continue;
		if (!(via->foundations[i^2] >= j 
			&& via->foundations[i^1]+2 < j
		    && via->foundations[i^3]+2 < j)) continue;
		moved = (i<<4) + j;
		if (Available(via, moved)) 
		{
			pos = TryMove(via, pos, moved, (Loc) FOUNDATION, 12);
			if (pos == NULL) return(NULL);
		}
	}

	/* try moving from holding area to empty column; vary which 
		one is
	   tried first, in case the key move we're looking for is 
		hold[3] */
	if (via->tableau[via->colSeq[7]].count == 0) 
	{
//		for (i=0; i<4; i++) 
		for (i=0; i<NUM_FCS; i++) 
		{
//			Card below;
/*
			if (NUM_FCS > 1)
			  moved = via->hold[((i+(depth>>2))&3)%(NUM_FCS - 1)];
			else
			  moved = via->hold[0];
*/
#ifndef FC5U
			moved = via->hold[(i+(depth>>2))&3];
#else
		  if (NUM_FCS <= 4)
		  {
			  moved = via->hold[(i+(depth>>2))&3];
			  if (NUM_FCS == 3)
				  moved = via->hold[(i+(depth>>2))%3];
			  if (NUM_FCS == 2)
				  moved = via->hold[(i+(depth>>2))&1];
			  if (NUM_FCS == 1)
				  moved = via->hold[0];
		  }
		  else
			moved = via->hold[((i+(depth>>2))&7)];
#endif			
			if (moved == 0) continue;
//			if (via->location[cardToIndex[moved]] != HOLDING)
			// use mask
			if (((via->location[cardToIndex[moved]] & HOLDING_MASK) 
				!= HOLDING_MASK) || (via->location[cardToIndex[moved]] == FOUNDATION))
			{
				moved ^= 0x20;
			}

			/* don't move a card down if both cards that could
			   use it are already on foundations */

#if SWAPIT
			if ((!Swapit && (via->location[cardToIndex[(moved-1)^0x10]] != FOUNDATION
			    || (via->location[cardToIndex[((moved-1)^0x10)^0x20]] != FOUNDATION))
				&& (Available(pos, moved)))	||
				(Swapit && (via->location[cardToIndex[(moved-1)^0x10]] != FOUNDATION
			    || (via->location[cardToIndex[((moved-1)^0x10)^0x20]] != FOUNDATION))))
#else
			if ((via->location[cardToIndex[(moved-1)^0x10]] != FOUNDATION
			    || (via->location[cardToIndex[((moved-1)^0x10)^0x20]] != FOUNDATION))
				&& Available(pos, moved))  // dont swap 
#endif
			{
				pos = TryMove(via, pos, moved,
					      (Loc) ((via->colSeq[7]<<5)+0), 10);
				if (pos == NULL) return(NULL);
			}
		}
	}

	/* next try moving from columns with 2+ cards to hold; if no 
		hold,
	   move to empty columns; (if both, can get to empty cols 
		via hold) */
	onto = FOUNDATION;
//	if (via->hold[3] == 0) onto = HOLDING;
	// can just check fc3!
//	for (i = 3; i >= 0; i--)
	for (i = NUM_FCS - 1; i >= 0; i--)
	{
		if (via->hold[i] == 0)
		{
			onto = HOLDING_BASE + i;
			break;
		}
	}

	if ((onto == FOUNDATION) && 
	    (via->tableau[via->colSeq[7]].count == 0))
	{
		onto = (via->colSeq[7]<<5) + 0;
	}

	if (onto != FOUNDATION) 
	{
		for (i=0; i<8; i++)
		{
			if (((goodcols & (1<<i)) != 0)
				&& ((intab & (1<<i)) == 0))
			{
				if (via->tableau[i].count < 2) continue;
				pos = TryMove(via, pos, Bottom(via, i), onto, 8);
				if (pos == NULL) return(NULL);
			}
		}
		
		for (i=0; i<8; i++)
		{
			if (((goodcols & (1<<i)) == 0) 
				&& ((intab & (1<<i)) == 0))
			{
				if (via->tableau[i].count < 2) continue;
				pos = TryMove(via, pos, Bottom(via, i), onto, 9);
				if (pos == NULL) return(NULL);
			}
		}
	}

	/* try moving from singleton columns to holding area, but 
		only if
	   there isn't another empty column already */
//	if (via->hold[3] == 0 && !HasSpace(via)) 
	// cant just check fc3
/*
	if (NUM_FCS &&
#ifdef FC5U
		((NUM_FCS == 7) && (via->hold[6] == 0 || via->hold[5] == 0 || via->hold[4] == 0 ||
		via->hold[3] == 0 || via->hold[2] == 0 || via->hold[1] == 0 ||
		via->hold[0] == 0)) || 
		((NUM_FCS == 6) && (via->hold[5] == 0 || via->hold[4] == 0 || via->hold[3] == 0 ||
		via->hold[2] == 0 || via->hold[1] == 0 || via->hold[0] == 0)) || 
		((NUM_FCS == 5) && (via->hold[4] == 0 || via->hold[3] == 0 || via->hold[2] == 0 || 
	     via->hold[1] == 0 || via->hold[0] == 0)) || 
#endif
		((NUM_FCS == 4) && (via->hold[3] == 0 || via->hold[2] == 0 || 
	     via->hold[1] == 0 || via->hold[0] == 0)) || 
		((NUM_FCS == 3) && (via->hold[2] == 0 || via->hold[1] == 0 || via->hold[0] == 0)) ||
		((NUM_FCS == 2) && (via->hold[1] == 0 || via->hold[0] == 0)) ||
		((NUM_FCS == 1) && (via->hold[0] == 0))
		&& !HasSpace(via)) 
//	if ((via->hold[3] == 0 || via->hold[2] == 0 || via->hold[1] == 0 || via->hold[0] == 0) 
//		&& !HasSpace(via)) 
*/
	for (i = 0 ; i < NUM_FCS ; i++)
	{
		if (via->hold[i] == 0)
			break ;
	}
	if (NUM_FCS && (i != NUM_FCS) && !HasSpace(via))
	{
		for (i=0; i<8; i++) 
		{
			if ((intab & (1<<i)) == 0) 
			{
				if (via->tableau[i].count != 1) continue;

//				pos = TryMove (via, pos, Bottom(via, i), 
//								(Loc) HOLDING);
				// move to holding
//				for (j = 3; j >= 0; j--)
				for (j = NUM_FCS - 1; j >= 0; j--)
				{
					if (via->hold[j] == 0)
					{
						pos = TryMove (via, pos, Bottom(via, i), 
							(Loc) (HOLDING_BASE + j), 11);
						break;
					}
				}

				if (pos == NULL) return(NULL);
			}
		}
	  }
    }
  }
	return(pos);
}

#if DON
void main(argc, argv) int argc; char *argv[];
{
	Position *pos0;
	int i, reps = 1, make_random = false;
	char *filename = NULL;

	//wcal
	printf ("\nDon Wood's Freecell Solver.\n");

	if (argc == 1)
	{
		printf ("\nEnter 'free1 -?' for help.\n");
		exit (1);
	}

	for (i=1; i<argc; i++) 
	{
		char *arg = argv[i];

		if (*arg == '-') 
		{
			while (*++arg) 
			{
				switch (*arg) 
				{
					case 'i':
						showorig = true;
						break;
					case 'm':
						if (maxdepth > 99999) maxdepth = 300;
						else maxdepth += 200;
						break;
					case 'r':
						make_random = true;
						break;
					case 's':
						show = true;
						break;
					case 'v':
						if (verbosity++ < 3) break;
						/* FALL THROUGH */
					default:
						printf("\
Usage: free1 [-imrsvv] [file]\n\n\
-i:  show initial layout\n\
-m:  set max search depth of 300 (+200 per extra m)\n\
-r:  if no 'file' arg, generate random winnable position\n\
     else convert filename to int, generate and test that many positions\n\
-s:  show solution if found (else just report whether one exists)\n\
-v:  verbose; give some statistics when done\n\
-vv: very verbose; dump entire search tree as it is traversed\n\
-vvv: same as -vv but does fflush after each step\n");
						exit(1);
				}
			}
		}
		else if (filename == NULL) 
		{
			filename = arg;
		}
	}

	if (make_random) {
		BuildOriginal();
		if (filename != NULL) reps = atoi(filename);
		if (reps <= 0) reps = 1;
	}
	else
		ReadOriginal(filename);
	
	tree = (Position **) calloc(HASH_SIZE, sizeof(Position*));
#ifdef MEMSTAT
		MainMessage("calloc3") ;
#endif
	if (tree == NULL) {
		printf("\nERROR: Out of memory!\n");
		exit(2);
	}


	for (i=0; i<reps; i++) {
		if (make_random) Shuffle();
		pos0 = NewPosition();
		InitialPosition(pos0);
		pos0->mustTry = (-1);
		if (showorig) ReadablePosition(pos0);
		SortColumns(pos0);

		(void) (pos0);

		if (DFS(pos0, NewPosition()) == NULL) {
			if (make_random && filename==NULL && !showorig)
				ReadablePosition(pos0);
			  {
//		  if ((gnMaxHands && (generated > gnMaxHands)) || gbAbort) 
		  if (gbAbort) 
		  {
			  if (!AppError)
				printf("Aborted.\n") ;
			  else
				printf("Abort/Illegal/Swap\n") ;
		  }
				else
			    printf("Winnable.\n");
			  }
		}
		else {
//			printf(distinct>=TRACTABLE? "Intractable.\n"
//				: "Impossible.\n");
			printf("Impossible.\n") ;
			if (make_random && filename==NULL) i--;
		}


		if (verbosity > 0) {
			printf("\n");
			if (windepth)
				printf("Winning line of %d steps.\n", windepth);
			printf("\
Generated %d positions (%d distinct).\n\
Rejected %d due to repeated columns.\n\
Pruned %d lines due to broken sequences.\n\
Combined %d lines via pair-swapping.\n",
			       generated, distinct, rejected, brokeSeq, swaps);
			if (!windepth)
				printf("Maximum freedom was %d.\n", maxfree);
			if (maxdepth < 100000) printf("\
Abandoned %d lines for exceeding %d moves.\n", maxout, maxdepth);
			else printf("\
Maximum depth was %d.\n", maxout);
			printf("Used %d of %d hash table slots.\n",
			       hashes, HASH_SIZE);
		}

		if (i < reps) {
			/* clean up to prepare for next position */
			generated = distinct = rejected = swaps = windepth =
			  maxout = maxfree = brokeSeq = hashes = depth = 0;
			memset(tree, 0, HASH_SIZE * sizeof(Position*));
			while (block->link != NULL) {
				Block *link = block->link;
				free(block);
				block = link;
			}
			pos_avail = POS_BLOCK;
			memset(block, 0, sizeof(*block));
			fflush(stdout);
		}
	}

	exit(0);
}
#endif


DWORD Free1Main (HWND hwnd)
{
	// set below normal priority so we can use menu

	SetThreadPriority (GetCurrentThread (), 
						THREAD_PRIORITY_BELOW_NORMAL);
	Free1Solver (hwnd);
//MainMessage("F1Main exit") ;
//	if (gbSearchF)
//		PostMessage(hwnd, WM_COMMAND, WM_USER+104, 0L) ;
//		SearchFNxtMove(hwnd) ;
	ghSolverThread = NULL;
    ExitThread (0);

	return 0; // not reached
}

// this is a thread so that user can shut it down
// using Option | Solve
void Free1Solver (HWND hwnd)
{
	Position *pos0;
//	time_t	 stime, etime;
//	char	 szTemp[20];
	DWORDLONG nGame;
	INT		gnMaxTimeS, gnMaxHandsS,gnColSeq, gnMode, gnFlag ;
	int is ;
	char szPrSv[20] ;

	gbDidSwapHlt = 1 ;
	if ((gnSolve != SOLVE_RANGE) &&	(gnSolve != SOLVE_LIST))
	  gfpSolFile = fopen ("solution.txt", "w");
	else
		{
		gfpSolFile = fopen ("solrange.txt", "w");
		WinCount = AboCount = ImpCount = P1ACount = 0 ;
		time (&oetime);
		lstrcpy(szPrSv, "-ST") ;
		}
#ifdef DIAGD
ChainCnt = MaxChainCnt = MaxHashCnt = 0 ;
#endif
		// NUPDATE - need to ask user if they mind overwriting
	// existing solution.txt.  only bother them if they are 
	// running on a range - only write output file if they are
	// running on a range

	// NUPDATE - could add standard solution to output file

#if DEBUG
	verbosity = 2;
#endif
	if (gnSolve == SOLVE_SOLUTION)
	{
		show = true;  // we need this for FCSolve
		gbHumanPlaying = FALSE ;  //Don't give human credit if solver does it.
	}
	else
	{
//		show = true ;
	show = false;
	}
	AppError = 0 ;
	SMode = 0 ;
	if ((PresortC[0] == 'X') || (PresortC[0] == 'U') || (PresortC[0] == 'T')
				|| (PresortC[1] == 'Q'))
		SMode = 1 ;
//#ifndef DHASH
	if (!SMode)
	{
		tree = (Position **) calloc(HASH_SIZE, sizeof(Position*));
//#ifdef MEMSTAT
//		MainMessage("calloc4") ;
//#endif
	}
//#else
	if (SMode || (PresortC[0] == 'V') || (PresortC[0] == 'W') || (PresortC[0] == 'X')
		|| (PresortC[1] == 'T') || (PresortC[1] == 'U') || (PresortC[1] == 'V')
		|| (PresortC[1] == 'W') || (PresortC[1] == 'X'))
	{
		for (is = 0 ; is < HASH_SIZE ; is++)
		{
			tree1[is] = (Position**)calloc(HASH_SUB, sizeof(Position*));
			tree2[is] = (Position**)calloc(HASH_SUB, sizeof(Position*));
#ifdef MEMSTAT
		MainMessage("calloc5") ;
#endif
		}
//	memset(treeLCnt, 0, HASH_SIZE) ; 
//	memset(treeL2Cnt, 0, HASH_SIZE) ; 
	memset(treeLCnt, 0, HASH_SIZE * sizeof(INT)) ; 
	memset(treeL2Cnt, 0, HASH_SIZE * sizeof(INT)) ; 
		for (i = 0 ; i < HASH_SIZE ; i++)
		{
			memset(tree1[i], 0, HASH_SUB) ; 
			memset(tree2[i], 0, HASH_SUB) ; 
		}
	if ((tree2 == NULL) || (tree1 == NULL))
		{
			Free1ErrorAbort ("Intractable.\n(Out of memory.)");
			return;
		}
	}
	//#endif
//#ifndef DHASH
	if (!SMode && (tree == NULL))
	{
		Free1ErrorAbort ("Intractable.\n(Out of memory.)");
		return;
	}
//#endif
	//		MainMessage (PresortC);

	gnMaxTimeS = gnMaxTime ;
	gnMaxHandsS = gnMaxHands ;
	gnExtendTry = gnRptEnbl = gnColSeq = gnMode = gnFlag = 0 ;
 
	if (gnSolve == SOLVE_LIST)
	{
		gnFirstGame = GetSolveGame(0) ;
		if (gnFirstGame < 0)
			return ;
		gnLastGame = 0x7ffffffff ; // set to allow to run all the way
	}
lstrcpy(szPCOrig, PresortC) ;
gnMaxTOrig = gnMaxTime ;
gnMaxHOrig = gnMaxHands ;
	//sprintf(szTemp, "FG fg- %ld ", gnFirstGame) ;
//MainMessage(szTemp) ; 
  // this is the loop for a range 
	// (firstgame = lastgame = 1 if not a range)

	for (nGame = gnFirstGame; nGame <= gnLastGame; nGame++)
	{
		SMode = OMode = OMode2 = 0 ;
		if (PresortC[0] == 'T')
		{
			PresortC[0] = 'X' ;
			OMode = 2 ;
		}
		if (PresortC[0] == 'U')
		{
			PresortC[0] = 'X' ;
			OMode = 1 ;
		}
		if (PresortC[0] == 'V')
		{
			PresortC[0] = 'Y' ;
			gnMode = 1 ;
		}
		if (PresortC[0] == 'W')
		{
			PresortC[0] = 'Z' ;
			gnMode = 1 ;
		}
		if (PresortC[0] == 'X')
			{
			SMode = 1 ;
			if (gnRptEnbl < 2)
				gnRptEnbl = 1 ;
			}
		gbDidSwap = FALSE ;
		if (gnSolve == SOLVE_RANGE)
			gbDidSwap = TRUE ;
		if (PresortC[1] == 'O')
			gbDidSwap = !gbDidSwap ;
		Swapit = TRUE ; // Default mode
		EitherM = 0x1f ;
		if (PresortC[1] == 'Q')	 // For old mode, double hash
		{						 // for use with column permutes in first char.
			Swapit = FALSE ;
			EitherM = 0x3f ;
			SMode = 1 ;
		}
		if (PresortC[1] == 'P')	// For old mode, to combine with "X" as "XP"
		{
			Swapit = FALSE ;
			EitherM = 0x3f ;
		}
		if (PresortC[1] == 'T')
		{
			OMode = 2 ;
			SMode = 1 ;
		}				
		if (PresortC[1] == 'U')
		{
			OMode = 1 ;
			SMode = 1 ;
		}				
		if (PresortC[1] == 'V')
		{
			OMode2 = 1 ;
			SMode = 1 ;
		}				
		if (PresortC[1] == 'S')
			OMode2 = 1 ;
		if (PresortC[1] == 'W')
		{
			OMode2 = 2 ;
			SMode = 1 ;
		}				
		if (PresortC[1] == 'X')
			SMode = 1 ;
		if ((PresortC[0] == 'Y') && (gnRptEnbl < 4))
			gnRptEnbl = 2 ;
		if (PresortC[0] == 'Z')
			gnRptEnbl = 3 ;
		// if range, deal next hand 
		if ((gnSolve == SOLVE_RANGE) || (gnSolve == SOLVE_LIST))
		{
			gnGameNumber = nGame;
			FreeCellInit (FALSE);
		}
		EnblDiag = 1 ;
		FCSolveReadOriginal ();
		pos0 = NewPosition();
		InitialPosition(pos0);
		pos0->mustTry = (-1);
		
		ReadablePosition(pos0);
		// debug start
	//	fclose (gfpSolFile);
	//	return;
		// debug end - use fclose below

		SortColumns(pos0);
//MainMessage("PrATT") ;
		(void) AddToTree(pos0);
		// get start time for solution
  		time (&stime);
//MainMessage("PsATT") ;
		if (DFS(pos0, NewPosition()) == NULL) 
		{
			if (gbSolver && !gbAbortA)
			{
//			if ((gnMaxHands && (generated > gnMaxHands)) || gbAbort)
			if (gbAbort)
			  {
			   if (gbAbortM == TRUE)
			     {
				 if (gnRptEnbl == 1)
				   {
				   gnExtendTry = 2 ;
				   PresortC[0] = 'B' ; 
				   }
		 	     if ((gnRptEnbl > 1) && (gnRptEnbl < 6))
				   {
					PresortC[0] = 'S' ;
					if (gnRptEnbl > 2)
					   gnRptEnbl = 4 ;
				   }  
				 if (gnRptEnbl == 6)
					 gnRptEnbl = 0 ;
				}
//MainMessage("Point 1") ;	
			gnFlag = gnPrtEnbl = 0 ;
			if (((gnExtendTry == 2) && (PresortC[0] == 'B') && (gnRptEnbl == 1))
				 || ((PresortC[0] == 'S') && ((gnRptEnbl == 2) || (gnRptEnbl >= 4)))
				 ||!gnRptEnbl)
				{
//MainMessage("Point 2") ;	
				gnFlag = 1 ;
				gbAbort = FALSE ;
//				if (gnRptEnbl == 6)
//					gnExtendTry = gnColSeq = 0 ;
				if (gbAbortM == FALSE)
					{
//MainMessage("Point 3") ;	
					if (!gnMode)
						{
						strcpy (szTemp, "Aborted");
						gnPrtEnbl = 1 ;
						AboCount++ ;
						}
					else
						{
						gnFlag = 0 ;
						gnMode = 2 ;
						}
					}
				else
			       {
				   gbAbortM = FALSE ;
//sprintf(szTemp, "AB Sw- %d  PC- %s", Swapit, PresortC) ;
//MainMessage(szTemp) ;	
//				   if ((gbMemOver == FALSE) && (PresortC[1] != '-'))
				   if (((gbMemOver == FALSE) && (gbStackOver == FALSE)) && 
							(PresortC[1] != '-') && (PresortC[1] != '/'))
//							(PresortC[1] != '-'))
//					   && (!Swapit || (PresortC[0] != 'X')))
				   {
//MainMessage("TimeOut 3") ;	
					   strcpy (szTemp, "User Interrupt");
				   }
					   else
					{
				     strcpy (szTemp, "Intractable.");
  // 					 gbAbort = TRUE ;
					 gnPrtEnbl = 1 ;
					 if (PresortC[1] == '-')
					 {
						strcpy (szTemp, "-X-") ;
						AboCount-- ;
						gnMode = 2 ;
						if (SolrSel == 1)
							gnPrtEnbl = 0 ;
						gbAbort = TRUE ;
					 }
					 if (PresortC[1] == '/')
						 PresortC[1] = ' ' ;
//					 if (Swapit && (PresortC[0] == 'X')) 
//					 {
//						PresortC[0] = 'W' ;	
//						gnRptEnbl = 0 ;
//						SMode = 0 ;
//					 }
					}
					AboCount++ ;
//					gnPrtEnbl = 1 ;
					}
			    }
			 if (!gnFlag)
			   {
				 gbAbort = TRUE ;
				if ((PresortC[0] == 'B') && ((gnRptEnbl == 1) || (gnRptEnbl == 3))
					 && (gnExtendTry != 2))
				   {
				   if ((gnSolve != SOLVE_RANGE) &&	(gnSolve != SOLVE_LIST))
				     strcpy (szTemp, "Extending");
				   else
						{
						strcpy (szTemp, "Ext");
						gnPrtEnbl = 0 ;
						}
					}
				 else
				   {
				    if ((gnSolve != SOLVE_RANGE) &&	(gnSolve != SOLVE_LIST))
//							&& (PresortC[0] != 'Y'))
				       strcpy (szTemp, "Presort ");
				    else
						{
						strcpy (szTemp, "P ");
						szTemp[3] = 0 ;
						gnPrtEnbl = 0 ;
						}
					if ((PresortC[0] != 'Y') || (gnRptEnbl != 5))
					   lstrcat(szTemp, PresortC) ;
					else		 
					   lstrcat(szTemp, "W") ;
//					szTemp[3] = 0 ;
				   }
				 }
			  }
			else
			  if ((gnSolve != SOLVE_RANGE) &&	(gnSolve != SOLVE_LIST))
					strcpy (szTemp, "Winnable.");
			  else
			    {
				strcpy (szTemp, "Win");
				gnPrtEnbl = 2 ;
				WinCount++ ;
			    }
			}
			else
			{
				nGame = gnLastGame ;
				gbAbortA = FALSE ;
				strcpy (szTemp, "Solver Aborted.");
				gnPrtEnbl = 1 ;
				gnRptEnbl = 0 ;
			}
		}					
		else 
		{
			if ((gnSolve != SOLVE_RANGE) && (gnSolve != SOLVE_LIST))
//			  strcpy (szTemp, distinct >= TRACTABLE ? "Intractable."
//				: "Impossible.");
			  strcpy (szTemp, "Impossible.");
			else
			{
				if (PresortC[1] != 'P')
				{
					strcpy(szTemp, "IMP") ;
					gnPrtEnbl = 3 ;
					ImpCount++ ;
				}
				else
				{
					strcpy(szTemp, "TIM") ;
					gnMode = 2 ;
					gbAbort = TRUE ;
					PresortC[1] = '-' ;
				}
			}
			if ((gnSolve != SOLVE_RANGE) &&	(gnSolve != SOLVE_LIST))
			{
				if (!gbSearchF)
					Free1ErrorAbort (szTemp);
				else
				{
					KillTimer(hwnd, 1) ;
					MessageBox(hwnd, "Impossible", "FIMP Test", MB_ICONEXCLAMATION | MB_OK) ;
					SetTimer(hwnd, 1, 20, NULL) ;	
				}
			}
		}							 
		if ((gnSolve != SOLVE_RANGE) &&	(gnSolve != SOLVE_LIST)) 
		  {
		  fprintf (gfpSolFile, "Game #%s", FmtGameNo(gnGameNumber));
		  fprintf (gfpSolFile, "  %s  Generated %8d Hands.", 
					szTemp, generated);
		  }
		else
		  {		   
		  if (PresortC[1] == 'P')
			  PresortC[1] = ' ' ;
		  if (SolrSel == 2)
		  {
			 if (((szTemp[0] != 'W') && (szTemp[0] != 'I') && (szTemp[0] != 'T')
				 && (szTemp[1] != 'X')))
			 {
				 lstrcpy(szPrSv, szTemp) ;
				szPrSv[3] = 0 ;
				if (szPrSv[0] == 'P')
				{
					 if (szPrSv[2] == 'Z')
						  szPrSv[2] = 'A' ;
					 else
					 {
					 if (szPrSv[2] == 'S')
						  szPrSv[2] = 'X' ;
					 else
						  szPrSv[2]++ ;
					 }
				 }
			    if (szPrSv[0] == 'E')
					lstrcpy(szPrSv, "---") ;
			 }
			 if ((szPrSv[2] == 'A') || (szPrSv[2] == 'B') || (szPrSv[2] == '-'))
				 szPrSv[1] = '1' + gnExtendTry ;
			  if ((szPrSv[0] != ' ') && ((gnPrtEnbl == 2) 
						&& ((NumFcs >= 2) && (NumFcs <= 4))) || 
						((gnPrtEnbl == 3) && ((NumFcs == 0) || (NumFcs == 1)))
						|| (szTemp[0] == 'T'))
				{
				if (!lstrcmp(szPrSv, "P1A"))
				{
					P1ACount++ ;
					lstrcpy(szPrSv, "   ") ;
				}
				else
				{
				 fprintf (gfpSolFile, "%s", FmtGameNo(gnGameNumber)) ;
				    fprintf (gfpSolFile, " %s %8d", szTemp, generated) ;
					fprintf (gfpSolFile, "  %s", szPrSv);
					if (szTemp[0] != 'T')
						lstrcpy(szPrSv, "     ") ;
					gnPrtEnbl = 4 ;
				}
			  }
		  }
		  if (((SolrSel == 1) || (SolrSel == 2)) && (gnPrtEnbl != 4) && (szPrSv[0] == ' ')
			  && (nGame == gnLastGame))
			  lstrcpy(szPrSv, "-EN") ;
		  if (!SolrSel || ((gnPrtEnbl == 1) ||
			  (((NumFcs == 0) || (NumFcs == 1)) && (gnPrtEnbl == 2)) ||
			  (((NumFcs >= 2) && (NumFcs <= 7)) && (gnPrtEnbl == 3))) ||
			  (((SolrSel == 1) || (SolrSel == 2)) && (szPrSv[1] == 'E')) ||
			  ((SolrSel == 1) && (szPrSv[1] == 'S'))
			  || ((SolrSel == 2) && (Swapit && SMode && (gnPrtEnbl != 4))))
			{
			  fprintf (gfpSolFile, "%s", FmtGameNo(gnGameNumber));
		      fprintf (gfpSolFile, " %s %8d", 
					szTemp, generated);
			  if (((SolrSel == 1) || (SolrSel == 2)) && (szPrSv[0] != ' '))
			  {
				  fprintf (gfpSolFile, "  %s",	szPrSv);
			      lstrcpy(szPrSv, "     ") ;
			  }
			  gnPrtEnbl = 4 ;
			}
		  }
		StatusOut (szTemp);
		// put end time in solution output file
		time (&etime);
		if ((gnSolve != SOLVE_RANGE) &&	(gnSolve != SOLVE_LIST))
		  fprintf (gfpSolFile, "  Elapsed Seconds: %d\n", etime - stime);
		else
		  {
		  if (!SolrSel || (SolrSel && (gnPrtEnbl == 4)))
	  	    fprintf (gfpSolFile, " %d\n", etime - stime);
		  }
		  // only send solution to fcpro task if its setup to play a gamenumber
		if (((gnGameNumber < 0xf00000000)|| gbCustomGame) && 
					(gnSolve == SOLVE_SOLUTION) && !gbAbort)
			PostMessage (hwnd, WM_USER+100, 0, 0);
		if (gbAbort)
			{
			gbAbort = FALSE ;
				 if (gnMode == 2)
					{
					PresortC[0] = 'X' ;
					if ((PresortC[1] != 'P') &&	(PresortC[1] != '-'))
						PresortC[1] = 'P' ;
					if (PresortC[1] == '-')
						PresortC[1] = ' ' ;
					//	memset(treeLCnt, 0, HASH_SIZE) ; 
					//	memset(treeL2Cnt, 0, HASH_SIZE) ; 
					memset(treeLCnt, 0, HASH_SIZE * sizeof(INT)) ; 
					memset(treeL2Cnt, 0, HASH_SIZE * sizeof(INT)) ; 
#ifdef DIAGD
ChainCnt = MaxChainCnt = MaxHashCnt = 0 ;
#endif
					nGame-- ;
					gnMode = 1 ;
					}
			else
			  {
			  if (PresortC[0] && (gnRptEnbl == 3)) 
			   {
			   if (PresortC[0] == 'Z')
			     {
				   PresortC[0] = 'A' ;
				   nGame-- ;
			     }
			   else
			     {
				 if (PresortC[0] == 'B')
				   {
					PresortC[0] = 'Z' ;
					if (gnExtendTry != 2)
					  {
					  gnMaxTime = 2 * gnMaxTime ;
					  gnMaxHands = 2 * gnMaxHands ;
					  gnExtendTry++ ;
					  nGame-- ;
					  }
					else
					  {
					  gnMaxTime = gnMaxTimeS ;
					  gnMaxHands = gnMaxHandsS ;
					  gnExtendTry = 0 ;
					  if (gnRptEnbl == 3)
					    {
						PresortC[0] = 'Y' ;
						gnRptEnbl = 4 ;
					    }
					 }
				   }
				 if (PresortC[0] == 'A')
			       {
				     PresortC[0] = 'B' ;
				     nGame-- ;
			       }
			     }
			   }
			 if (PresortC[0] && ((gnRptEnbl == 2) || (gnRptEnbl >= 4))) 
			   {
			   if (PresortC[0] == 'Y')
			     {
				 if (gnRptEnbl == 4)
				   PresortC[0] = 'C' ;
				 else
				   PresortC[0] = 'A' ;
				 nGame-- ;
			     }
			   else
				   {
				   PresortC[0]++ ;
				   nGame-- ;
				   }
				}
			  }
			}
	   else
		  {
		  if ((PresortC[0] == 'X') && (gnRptEnbl > 1))
			  SMode = 0 ;
			if (PresortC[0] && (gnRptEnbl == 2))
			{
				if (!gnMode)
					PresortC[0] = 'Y' ;
				else
					PresortC[0] = 'V' ;
			}
			if (PresortC[0] && ((gnRptEnbl == 3) || (gnRptEnbl == 4)))
				{
				if (!gnMode)
					PresortC[0] = 'Z' ;
				else
					PresortC[0] = 'W' ;
				}
			if (gnRptEnbl < 6)
				gnExtendTry = 0 ;
			else
				gnColSeq = 0 ;
			gnMaxTime = gnMaxTimeS ;
			gnMaxHands = gnMaxHandsS ;
			}
//		if (gnSolve != SOLVE_RANGE)
//		    gnRptEnbl = 0 ;

	  /* 
		clean up to prepare for next position */
		generated = distinct = rejected = swaps = windepth =
		  maxout = maxfree = brokeSeq = hashes = depth = 0;
//#ifdef DHASH
	if (!SMode)
		memset(tree, 0, HASH_SIZE * sizeof(Position*));
	else
	{
		for (i = 0 ; i < HASH_SIZE ; i++)
		{
			memset(tree1[i], 0, HASH_SUB) ; 
			memset(tree2[i], 0, HASH_SUB) ; 
		}
	}
		//#endif
		while (block->link != NULL) {
			Block *link = block->link;
			if (block)
			  {
			  free(block);
			  block = link;
			  }
//#ifdef DHASH
	if (SMode)
		{
		memset(treeLCnt, 0, HASH_SIZE * sizeof(INT)) ; 
		memset(treeL2Cnt, 0, HASH_SIZE * sizeof(INT)) ; 
		}
//#endif
	}
#ifdef MEMSTAT
GlobalMemoryStatus(&MemStat) ;
wsprintf(szTempM, "frAP p-%li v-%li", MemStat.dwAvailPhys, MemStat.dwAvailVirtual);
MainMessage(szTempM) ;
#endif
		pos_avail = POS_BLOCK;
		memset(block, 0, sizeof(*block));
		if ((gnSolve == SOLVE_LIST)	&& (nGame == gnGameNumber))
		{
			nGame = GetSolveGame(1) ;
			if (nGame < 0)
				nGame = 0x7ffffffff ; // force end
			nGame-- ; // because loop will increment number
		}
  }  // end of range solve loop
	// we are done with the solver
//MainMessage("F1S endloop 3") ;
if (!SMode)
//#ifndef DHASH
{
	if (tree)
	  free (tree);
}
//#else
if (SMode || gnMode)
{
	for (is = 0 ; is < HASH_SIZE ; is++)
		{
		if (tree1[is])
			free(tree1[is]) ;
		if (tree2[is])
			free(tree2[is]) ;
		}
}
//MainMessage("F1S endloop 4") ;
	//#endif
	gbSolver = FALSE;
	lstrcpy(PresortC, szPCOrig) ;
	gnMaxTime = gnMaxTOrig ;
	gnMaxHands = gnMaxHOrig ;
	if ((gnSolve == SOLVE_RANGE) ||	(gnSolve == SOLVE_LIST))
	{
	fprintf (gfpSolFile, "Number of Freecells: %d   Mode: ", NUM_FCS);
	fprintf (gfpSolFile, PresortC);
	fprintf (gfpSolFile, "\n");
	if (gnMaxTime)
		fprintf (gfpSolFile, "Max A Time: %d  ", gnMaxTime) ;
	if (gnMaxHands)
		fprintf (gfpSolFile, "Max A Hands: %d  ", gnMaxHands) ;
	if (gnMaxTimeB)
		fprintf (gfpSolFile, "Max B Time: %d  ", gnMaxTimeB) ;
	if (gnMaxSpace)
		fprintf (gfpSolFile, "Max B Space: %d  ", gnMaxSpace) ;
	fprintf (gfpSolFile, "\n");
	if (SolrSel == 2)
		fprintf(gfpSolFile, "P1A Count: %d\n", P1ACount) ;
	fprintf (gfpSolFile, "Winnables: %d\n", WinCount);
	fprintf (gfpSolFile, "Impossibles: %d\n", ImpCount);
	fprintf (gfpSolFile, "Intractables: %d\n", AboCount);
	if ((etime - oetime) < 3600)
      fprintf (gfpSolFile, "Total time: %d Minutes, %d Seconds\n", (etime - oetime)/60,	
					(etime - oetime)%60) ;
	else
      fprintf (gfpSolFile, "Total time: %d Hours, %d Minutes, %d Seconds\n",
			(etime - oetime)/3600, ((etime - oetime)%3600) / 60,	
					(etime - oetime)%60) ;
		// officially start last game
		MainStartGame (TRUE);
	}
	fclose (gfpSolFile);
#ifdef WILSON2
	free(tree) ;
	free(block) ;
	pos_avail = 0 ;
#endif
//	if (gbSearchF)
//		SearchFNxtMove(hwnd) ;
}

BOOL TestSolver()
{	
if (!gbSolver || ((gnSolve != SOLVE_RANGE) && (gnSolve != SOLVE_LIST)))
  return FALSE ;
else
  {
  gbAbort = gbAbortM = TRUE ;
  return TRUE ;
  }
}

BOOL TestSolverA(WORD wParam)
{
if (gbSearchF || gbSearchF2 || gbSearchF3)
{
	if (wParam == VK_ESCAPE)
	{
		KillTimer(ghwndMainApp, 1) ;
		gbAbortA = TRUE;
		gbSearchF = gbSearchF2 = gbSearchF3 = FALSE ;
		StatusOut("Aborted") ;
	}
	if (wParam == ' ')
		gbAbortA = TRUE;
}
else
{
if ((!gbSolver && !gbSolver2 && !gbSolver3) || (wParam != VK_ESCAPE)) 
  return FALSE ;
else
  {
  gbAbortA = TRUE ;
  return TRUE ;
  }
}
}

PRIVATE VOID Free1ErrorAbort (LPSTR pszFormat, ...)
{
    va_list marker;
    TCHAR szT[MAXSTRING];

    va_start(marker, pszFormat);
    wvsprintf(szT, pszFormat, marker);
    MessageBox (ghwndMainApp, szT, gszWindowName, 
  				MB_ICONEXCLAMATION | MB_TASKMODAL);
    va_end(marker);

	if ((gnSolve != SOLVE_RANGE) &&	(gnSolve != SOLVE_LIST))
	{
		// dont abort range
		gbSolver = FALSE;
		StatusOut ("Solver Error!  Aborting...");
		UpdateWindow (ghwndMainApp);
	}
}

