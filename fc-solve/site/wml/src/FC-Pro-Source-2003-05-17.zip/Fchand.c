// wilson callan, copyright 1997, 1998

#include "main.h"
#include "custom.h"
#include "settings.h"
#include "freecell.h"
#include "fcplay.h"
#include "cards.h"
#include "fchand.h"

INT	    ColLen[NUM_COLS];
HPEN    ghPenF;
HGDIOBJ hPenD;
#ifndef FC89
CARD card[MAXCOL + 4][MAXPOS];   // current layout of cards, CARDs are ints
#else
CARD card[MAXCOL + 5][MAXPOS];   // current layout of cards, CARDs are ints
#endif

HDC hdcC ;

PRIVATE BYTE gyBuriedPos, gyBuriedCol;
PRIVATE HPEN ghPenL, ghPenB, ghPenR, ghPenP ;
//PRIVATE INT  CvacO;

PRIVATE VOID ShowCard (LPPAINTSTRUCT pnt, INT col, INT pos);
PRIVATE VOID CardRect (INT col, INT pos, LPRECT crd);
PRIVATE VOID DrawExt (HDC, INT, INT, INT, INT, INT, INT);
PRIVATE VOID DArrow(INT, INT, LPPAINTSTRUCT);
PRIVATE VOID RHash3(INT, INT, LPPAINTSTRUCT);
PRIVATE VOID RHash2(INT, INT, LPPAINTSTRUCT);
PRIVATE VOID RHash1(INT, INT, LPPAINTSTRUCT);
PRIVATE VOID RLine(INT, INT, LPPAINTSTRUCT);
PRIVATE VOID RLineF(INT, INT, LPPAINTSTRUCT);

VOID FreeCellDealInit (VOID)
{
    int  col, pos;

	/* clear deck */

    for (col = 0; col < MAXCOL; col++)
        for (pos = 0; pos < MAXPOS; pos++)
            card[col][pos] = EMPTY;

	gyBuriedPos = gyBuriedCol = 0;

	// delete pens if they were already created

    DeleteObject ((HANDLE) ghPenL);
    DeleteObject ((HANDLE) ghPenR);
    DeleteObject ((HANDLE) ghPenB);
    DeleteObject ((HANDLE) ghPenF);
    DeleteObject ((HANDLE) ghPenP);

	// create pens here to save time in repainting

	ghPenL = CreatePen (PS_SOLID, XPOS_CARD_SEPERATOR, 
							RGB(0, 225, 0));
	ghPenR = CreatePen (PS_SOLID, 2, RGB(0, 225, 0));
	ghPenB = CreatePen (PS_SOLID, YPOS_FC_SEPERATOR, 
							RGB(0, 225, 0));
	ghPenF = CreatePen (PS_SOLID, YPOS_FC_SEPERATOR, 
							RGB(gnFCRed, gnFCGreen, gnFCBlue));
	ghPenP = CreatePen (PS_SOLID, gnWidth / 20, RGB(0, 0, 255));
}

LONG seedx ;

VOID srandp(UINT s)
{
	seedx = (LONG)s ;
}

UINT randp()
{
	seedx = seedx * 214013L + 2531011L ;
	return (seedx & 0xffff0000) >> 16 ;
}

//
// the randomness of this deal routine was graciously given to us by
// jim horne (at microsoft?), creater of freecell!
//
VOID FreeCellDeal (VOID)
{
    int  i, j;                  // generic counters
    int  wLeft = NUM_CARDS;		// cards left to be chosen in shuffle
    CARD deck[NUM_CARDS];       // deck of 52 unique cards

	/* clear deck */

	FreeCellDealInit ();

	if (gbCustomGame)
	{
	    /* read in cards */
		CustomDeal ();
	}
	else
	{
		/* shuffle cards */

		for (i = 0; i < NUM_CARDS; i++)	// put unique card in each deck loc.
			deck[i] = i;

		if (gnGameNumber < 0x100000000)
			srand ((UINT)gnGameNumber);           // game number is seed for rand()
		else
			srandp ((UINT)(gnGameNumber - 0x100000000)); // use separate seed for local randp()
		for (i = 0; i < NUM_CARDS; i++)
		{
			if (gnGameNumber < 0x100000000)
				if (gnGameNumber < 0x80000000)
					j = rand() % wLeft;
				else
					j = (rand() | 0x8000) % wLeft ; // needed for 2nd 2 gigabyte games
			else
				j = (randp() + 1) % wLeft;  // offset by one for greater diversity
			card[(i%8)+1][i/8] = deck[j];
			deck[j] = deck[--wLeft];
		}

		/* init Column Length */

		for (i = 0; i < (NUM_COLS / 2); i++)
		{
			ColLen[i] = 7;
		}
		for (i = (NUM_COLS / 2); i < NUM_COLS; i++)
		{
			ColLen[i] = 6;
		}
	}
}

VOID ShowHand (LPPAINTSTRUCT pnt)
{
    BYTE	col, pos, zCol;
	RECT	hc_rc;
	UINT	x;
	RECT crd_rc;
//	HANDLE hObjectD ;

//char szDiagTx[3] ;

	hc_rc.top    = YPOS_FC_START;
	hc_rc.bottom = YPOS_FC_END + YPOS_FC_SEPERATOR/2;
	hc_rc.left   = XPOS_FC_START;
	hc_rc.right  = XPOS_HC_END;
/*
	hBitmapC = LoadBitmap(ghInst,MAKEINTRESOURCE(1)) ;
	hdcC = CreateCompatibleDC(pnt->hdc) ;
	if (hdcC == NULL)
		MainMessage("No DC") ;
	if (hBitmapC == NULL)
		MainMessage("No Bitmap") ;
	hObjectD = SelectObject(hdcC, hBitmapC) ;
//		MainMessage("No Object") ;
*/
	if (ObjectInRect (&hc_rc, &pnt->rcPaint))
	{
		// save default pen

		hPenD = SelectObject (pnt->hdc, ghPenL);

		// draw homecell region
		hc_rc.left = XPOS_HC_START - XPOS_CARD_SEPERATOR/2;
	if (gbSpider)
			SelectObject (pnt->hdc, ghPenF);
		MoveToEx (pnt->hdc, hc_rc.left, hc_rc.top, NULL);
		LineTo (pnt->hdc, hc_rc.left, hc_rc.bottom);

if (!gbSpider)
{
		SelectObject (pnt->hdc, ghPenB);
		LineTo (pnt->hdc, hc_rc.right, hc_rc.bottom);

		SelectObject (pnt->hdc, ghPenR);
		MoveToEx (pnt->hdc, hc_rc.right+2, hc_rc.bottom, NULL);
		LineTo (pnt->hdc, hc_rc.right+2, hc_rc.top);
}
		SelectObject (pnt->hdc, ghPenF);
		MoveToEx (pnt->hdc, XPOS_FC_START, hc_rc.bottom, NULL);
		LineTo (pnt->hdc, XPOS_FC_END - XPOS_CARD_SEPERATOR - 2, 
					hc_rc.bottom);
		// restore

		SelectObject (pnt->hdc, hPenD);

		// draw lines

		hc_rc.bottom = YPOS_FC_END;

		for (x = XPOS_FC_START; x < XPOS_HC_END - gbSpider * 4 * XPOS_FC_SIZE ;
				x += XPOS_FC_SIZE)
		{
			MoveToEx (pnt->hdc, x, hc_rc.top, NULL);
			LineTo (pnt->hdc, x, hc_rc.bottom);
		}
	}

	// col 0 is top row - paint fcs and hcs

	col = 0;
    SelectObject (pnt->hdc, ghPenP) ;
    for (pos = 0 ; pos < (NUM_FCS + NUM_SUITS); pos++)
	{
		if (card[col][pos] != EMPTY)
		{
			ShowCard (pnt, col, pos);
			if (gbProAids && (pos > (NUM_FCS - 1)))
			{
				if (PossMoves[pos + NUM_COLS - NUM_SUITS])
				{
					CardRect(col, pos - (NUM_SUITS - NUM_FCS), &crd_rc) ; 
	  	    	    DArrow(crd_rc.left + gnWidth * 4 / 19, 
							crd_rc.top + gnHeight / 20, pnt) ;
				}
			}
		}
	}

	// paint table
	
    for (col = 1, zCol = 0; col < MAXCOL; col++, zCol++)
    {
		// show all cards in this column

        for (pos = 0; pos < MAXPOS; pos++)
		{
			if (card[col][pos] == EMPTY)
				break;

			// paint card

			ShowCard (pnt, col, pos);

			// paint proaids

			if (gbProAids)
			{
				if (pos >= posS[zCol][0])
				{
					CardRect(col, pos, &crd_rc) ; 

					// paint hashes

					if (pos == posS[zCol][3])
					{
						RHash3(crd_rc.left + gnWidth, 
								crd_rc.top, pnt) ;
					}
					else if (pos == posS[zCol][2])
					{
					 	RHash2(crd_rc.left + gnWidth, 
					 			crd_rc.top, pnt) ;
					}
					else if (pos == posS[zCol][1])
					{
					 	RHash1(crd_rc.left + gnWidth, 
					 			crd_rc.top, pnt) ;
					}

					// paint lines

					if (pos != (ColLen[zCol] - 1))
					{
						// underneath cards
						RLine(crd_rc.left + gnWidth, crd_rc.top, pnt) ;
					}
					else
					{
						// final card
						RLineF(crd_rc.left + gnWidth, crd_rc.top, pnt) ;
					}
				}
/*
				TextOut (pnt->hdc, 20+45*(col - 1), 300, szDiagTx, 
					wsprintf (szDiagTx, "%d " , posS0)) ;
				TextOut (pnt->hdc, 20+45*(col - 1), 320, szDiagTx, 
					wsprintf (szDiagTx, "%d ", posS1)) ;
				TextOut (pnt->hdc, 20+45*(col - 1), 340, szDiagTx, 
					wsprintf (szDiagTx, "%d ", posS2)) ;
				TextOut (pnt->hdc, 20+45*(col - 1), 360, szDiagTx, 
					wsprintf (szDiagTx, "%d ", posS3)) ;
*/
			}
		}

		// draw pro arrow for this column

		if (gbProAids && (PossMoves[zCol]))
	    {
 			CardRect (col, 0, &crd_rc);
 			DArrow(crd_rc.left + gnWidth * 4 / 19, 
					crd_rc.top + gnHeight / 20, pnt) ;
	    }
	} 
	SelectObject (pnt->hdc, hPenD);
/*
	SelectObject(hdcC, hObjectD) ;
	DeleteObject(hBitmapC) ;
	DeleteDC(hdcC) ;
*/
}

PRIVATE VOID ShowCard (LPPAINTSTRUCT pnt, INT col, INT pos)
{
	RECT crd_rc;

	CardRect (col, pos, &crd_rc);

#if 0
	//debug
	if ((col == 1) && (pos == 0))
	{
		MainOut (  0, 0, "top", pnt->rcPaint.top);
		MainOut (100, 0, "bot", pnt->rcPaint.bottom);
		MainOut (200, 0, "lef", pnt->rcPaint.left);
		MainOut (300, 0, "rig", pnt->rcPaint.right);
	}
#endif

	if (ObjectInRect (&crd_rc, &pnt->rcPaint) ||
		(pnt->rcPaint.bottom == (LONG) NULL))
	{
		// card is in region to paint, or we dont care - paint it 
		// anyways (for right mouse button)

		if ((gSel.position == pos) && (gSel.column == col))
		{
			// selected - draw inverted
			DrawExt (pnt->hdc, crd_rc.left, crd_rc.top, 
							gnWidth, gnHeight,
						card[col][pos], C_INVERT);
		}
		else
		{
			DrawExt (pnt->hdc, crd_rc.left, crd_rc.top, 
							gnWidth, gnHeight,
						card[col][pos], C_FACES);
		}
	}
}

VOID FindCards (HDC hdc, INT crd)
{
	RECT crd_rc; 
	INT col, pos;

	// free

	col = 0;

	for (pos = 0; pos < NUM_FCS; pos++)
	{
		if (VALUE(card[col][pos]) == crd)
		{
			CardRect (col, pos, &crd_rc);

			// draw inverted
			DrawExt (hdc, crd_rc.left, crd_rc.top, 
							gnWidth, gnHeight,
						card[col][pos], C_INVERT);
		}
	}

	// home

	for (; pos < (NUM_FCS + NUM_SUITS); pos++)
	{
		// look for cards in home

		if ((card[col][pos] != EMPTY) &&
			(VALUE(card[col][pos]) >= crd))
		{
			CardRect (col, pos, &crd_rc);

			// draw inverted
			DrawExt (hdc, crd_rc.left, crd_rc.top, 
							gnWidth, gnHeight,
						card[col][pos], C_INVERT);
		}
	}

	// col

	for (col = 1; col < MAXCOL; col++)
	{
		for (pos = 0; pos < MAXPOS; pos++)
		{
			if (card[col][pos] == EMPTY)
			{
				break;
			}
			else if (VALUE(card[col][pos]) == crd)
			{
				CardRect (col, pos, &crd_rc);

				// draw inverted
				DrawExt (hdc, crd_rc.left, crd_rc.top, 
								gnWidth, gnHeight,
							card[col][pos], C_INVERT);
			}
		}
	}
}

PRIVATE VOID DrawExt (HDC hdc, INT left, INT top, INT x, INT y,
						INT val, INT c)
{
//char cdText[2] ;
	(CdtDrawExt) (hdc, left, top, 
					x, y,
					val, c, 0xFFFF);
/*
if (VALUE(val) == ACE)
	cdText[0] = 'A' ;
if (VALUE(val) == 9)
	cdText[0] = 'T'	;
if (VALUE(val) == JACK)
	cdText[0] = 'J'	;
if (VALUE(val) == QUEEN)
	cdText[0] = 'Q'	;
if (VALUE(val) == KING)
	cdText[0] = 'K'	;
if ((VALUE(val) > ACE) && (VALUE(val) < 9))	
	cdText[0] = VALUE(val) + '1' ;
if (SUIT(val) == CLUB)
	cdText[1] = 'C'	;
if (SUIT(val) == DIAMOND)
	cdText[1] = 'D'	;
if (SUIT(val) == HEART)
	cdText[1] = 'H'	;
if (SUIT(val) == SPADE)
	cdText[1] = 'S'	;
if (c == C_INVERT)
{
	if (COLOUR(val) == RED)
	{
		SetBkColor(hdc,0x000000ff) ;
		SetTextColor(hdc, 0x0000ffff) ;
	}
	else
	{
		SetBkColor(hdc,0) ;
		SetTextColor(hdc, 0x00ffffff) ;
	}
	SetTextColor(hdc,0x00ffffff) ;
}
else
	{
	if (COLOUR(val) == RED)
	{
		SetTextColor(hdc,0x000000ff) ;
		SetBkColor(hdc, 0x0000ffff) ;
	}
	}
TextOut(hdc, left, top,cdText,2) ; 
	// bug in stack needs this here
SetTextColor(hdc,0) ;
SetBkColor(hdc,0x00ffffff) ;

if (c != C_INVERT)
	StretchBlt(hdc, left, top, x, y, hdcC, 71 * VALUE(val), 96 * SUIT(val), 71, 96,
			SRCCOPY) ;
else
	StretchBlt(hdc, left, top, x, y, hdcC, 71 * VALUE(val), 96 * SUIT(val), 71, 96,
			NOTSRCCOPY) ;
*/
}
//return ;

PRIVATE VOID CardRect (INT col, INT pos, LPRECT rc)
{
	if (col == 0)
	{
		// handle row 0 differently

		rc->top = YPOS_FC_START;
		rc->bottom = YPOS_FC_END;
		rc->left = (pos)*(gnWidth+XPOS_CARD_SEPERATOR);
		rc->right = rc->left+gnWidth;
	}
	else
	{
		rc->top = (pos)*(YPOS_CARD_VISIBLE) + YPOS_CL_START;
// this doesnt work because MakeMove() changes (or doesnt change) ColLen[]
//		rc->bottom = rc->top+((pos == (ColLen[col-1]-1)) ? gnHeight : YPOS_CARD_VISIBLE);
		rc->bottom = rc->top+gnHeight;
		rc->left = (col-1)*(gnWidth+XPOS_CARD_SEPERATOR);
		rc->right = rc->left+gnWidth;
	}
}

VOID InvalidateCard (INT col, INT pos)
{
	RECT rc;

	CardRect (col, pos, &rc);

#if 0
	//debug
	MainOut (  0, 20, "top", rc.top);
	MainOut (100, 20, "bot", rc.bottom);
	MainOut (200, 20, "lef", rc.left);
	MainOut (300, 20, "rig", rc.right);
#endif

	InvalidateMain (&rc);
}

VOID InvalidateArrow (CHAR i)
{
	RECT rc;

	if (i < NUM_COLS)
	{
		// invalidate stem
		rc.top = YPOS_CL_START + gnHeight/48;
		rc.bottom = rc.top + gnHeight/3 - gnHeight/48;
		rc.left = XPOS_CARD_SEPERATOR + (XPOS_CL_SIZE*i) + 
					gnWidth/8;
		rc.right = rc.left + gnWidth/17;
		InvalidateMain (&rc);

		// invalidate head
		rc.top = YPOS_CL_START + gnHeight/6;
		rc.left -= gnWidth/10;
		rc.right = rc.left + gnWidth/4 + gnWidth/17;
		InvalidateMain (&rc);
	}
	else
	{
		i -= NUM_COLS;

		// invalidate stemp
		rc.top = YPOS_HC_START + gnHeight/48;
		rc.bottom = rc.top + gnHeight/3 - gnHeight/48;
		rc.left = XPOS_HC_START + XPOS_CARD_SEPERATOR + i*gnWidth + 
					gnWidth/8;
		rc.right = rc.left + gnWidth/17;
		InvalidateMain (&rc);

		// invalidate stemp
		rc.top = YPOS_HC_START + gnHeight/6;
		rc.left -= gnWidth/10;
		rc.right = rc.left + gnWidth/4 + gnWidth/17;
		InvalidateMain (&rc);
	}
	return ;
}

VOID InvalidateProLine (INT zCol, INT pos)
{
	RECT rc;

	rc.top = YPOS_CL_START + ((pos-1) * YPOS_CARD_VISIBLE);
	rc.bottom = rc.top + (ColLen[zCol] - 1) * YPOS_CARD_VISIBLE
				+ gnHeight ;
	rc.right = (zCol+1) * (gnWidth + XPOS_CARD_SEPERATOR) ;
	rc.left = rc.right - XPOS_CARD_SEPERATOR - gnWidth / 16 ;
	InvalidateMain (&rc);
}
VOID InvalidateProHash1 (INT zCol, BYTE pos)
{
	RECT rc;

	rc.top = YPOS_CL_START + (pos * YPOS_CARD_VISIBLE);
	rc.bottom = rc.top + gnHeight/10;
	rc.right = (zCol+1) * (gnWidth + XPOS_CARD_SEPERATOR) ;
	rc.left = rc.right - XPOS_CARD_SEPERATOR - gnWidth / 4 ;
	InvalidateMain (&rc);
}
VOID InvalidateProHash2 (INT zCol, BYTE pos)
{
	RECT rc;

	rc.top = YPOS_CL_START + (pos * YPOS_CARD_VISIBLE);
	rc.bottom = rc.top + gnHeight/8;
  	rc.right = (zCol+1) * (gnWidth + XPOS_CARD_SEPERATOR) ;
  	rc.left = rc.right - XPOS_CARD_SEPERATOR - gnWidth / 4 ;

	InvalidateMain (&rc);
}
VOID InvalidateProHash3 (INT zCol, BYTE pos)
{
	RECT rc;

	rc.top = YPOS_CL_START + (pos * YPOS_CARD_VISIBLE);
	rc.bottom = rc.top + gnHeight/6;
	rc.right = (zCol+1) * (gnWidth + XPOS_CARD_SEPERATOR) ;
	rc.left = rc.right - XPOS_CARD_SEPERATOR - gnWidth / 4 ;
	InvalidateMain (&rc);
}
VOID ShowBuriedCard (LPPAINTSTRUCT pnt, UINT xPos, UINT yPos)
{
	if (RcvdRightButtonDown (xPos, yPos, &gyBuriedCol, &gyBuriedPos))
	{
		if (card[gyBuriedCol][gyBuriedPos] != EMPTY)
		{
			ShowCard (pnt, gyBuriedCol, gyBuriedPos);
		}
	}
}

VOID HideBuriedCard (VOID)
{
	BYTE pos;

	if (gyBuriedCol)
	{
		// invalidate all cards below buried card

		for (pos = gyBuriedPos+1; pos < MAXPOS; pos++)
		{
			if (card[gyBuriedCol][pos] == EMPTY)
			{
				break;
			}
			
			InvalidateCard (gyBuriedCol,  pos);
		}
			
		gyBuriedCol = gyBuriedPos = 0;
	}
}

VOID DArrow(int DAx, int DAy, LPPAINTSTRUCT pnt)
{
  MoveToEx(pnt->hdc, DAx, DAy, NULL);
  LineTo (pnt->hdc, DAx, DAy + gnHeight / 4) ;
  LineTo (pnt->hdc, DAx - gnWidth / 10, DAy + gnHeight / 4 - gnHeight / 10) ;
  MoveToEx(pnt->hdc, DAx, DAy + gnHeight / 4, NULL);
  LineTo (pnt->hdc, DAx + gnWidth / 10, DAy + gnHeight / 4 - gnHeight / 10) ;
}

VOID RHash3(int DAx, int DAy, LPPAINTSTRUCT pnt)
{
  DAy = DAy + gnHeight / 20 ;
  MoveToEx(pnt->hdc, DAx - gnWidth / 20, DAy, NULL);
  LineTo (pnt->hdc, DAx - gnWidth / 5, DAy) ;
  MoveToEx(pnt->hdc, DAx - gnWidth / 20, DAy + gnHeight / 20, NULL);
  LineTo (pnt->hdc, DAx - gnWidth / 5, DAy + gnHeight / 20) ;
  MoveToEx(pnt->hdc, DAx - gnWidth / 20, DAy + gnHeight / 20
			 + gnHeight / 20, NULL);
  LineTo (pnt->hdc, DAx - gnWidth / 5, DAy + gnHeight / 20 + gnHeight / 20) ;
}

VOID RHash2(int DAx, int DAy, LPPAINTSTRUCT pnt)
{
  DAy = DAy + gnHeight / 20 ;
  MoveToEx(pnt->hdc, DAx - gnWidth / 20, DAy, NULL);
  LineTo (pnt->hdc, DAx - gnWidth / 5, DAy) ;
  MoveToEx(pnt->hdc, DAx - gnWidth / 20, DAy + gnHeight / 20, NULL);
  LineTo (pnt->hdc, DAx - gnWidth / 5, DAy + gnHeight / 20) ;
}

VOID RHash1(int DAx, int DAy, LPPAINTSTRUCT pnt)
{
  DAy = DAy + gnHeight / 20 ;
  MoveToEx(pnt->hdc, DAx - gnWidth / 20, DAy, NULL);
  LineTo (pnt->hdc, DAx - gnWidth / 5, DAy) ;
}

VOID RLine(int DAx, int DAy, LPPAINTSTRUCT pnt)
{
  MoveToEx(pnt->hdc, DAx - gnWidth / 30, DAy, NULL);
  LineTo (pnt->hdc, DAx - gnWidth / 30, DAy + YPOS_CARD_VISIBLE + 10) ;
}

VOID RLineF(int DAx, int DAy, LPPAINTSTRUCT pnt)
{
	// paint line on final card

  MoveToEx(pnt->hdc, DAx - gnWidth / 30, DAy, NULL);
  LineTo (pnt->hdc, DAx - gnWidth / 30, DAy + gnHeight - gnHeight / 20) ;
}
