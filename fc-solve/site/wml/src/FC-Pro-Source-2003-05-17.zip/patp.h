/* Solve Freecell and Seahaven type patience (solitaire) games. */

#include "util.h"
#include <sys/types.h>
#include "config.h"

/* A card is represented as (suit << 4) + rank. */

typedef u_char card_t;

#define DIAMONDP 0x00            /* red */
#define CLUBP    0x10            /* black */
#define HEARTP   0x20            /* red */
#define SPADEP   0x30            /* black */
#define COLOR   0x10            /* black if set */
#define SUITP    0x30            /* mask both suit bits */

#define NONE    0
#define ACEP     1
#define KINGP    13

#define rank(card) ((card) & 0xF)
#define suit(card) ((card) >> 4)
#define color(card) ((card) & COLOR)

extern int Same_suit;           /* game parameters */
extern int King_only;
extern int Nwpiles;
extern int Ntpiles;

/* Some macros used in get_possible_moves(). */

/* The following macro implements
	(Same_suit ? (suit(a) == suit(b)) : (color(a) != color(b)))
*/
#define suitable(a, b) ((((a) ^ (b)) & Suit_mask) == Suit_val)
extern card_t Suit_mask;
extern card_t Suit_val;

#define king_only(card) (!King_only || rank(card) == KINGP)

extern char Rank[];
extern char Suit[];

/* Represent a move. */

typedef struct {
	card_t card;            /* the card we're moving */
	u_char from;            /* from pile number */
	u_char to;              /* to pile number */
	u_char fromtype;        /* O, T, or W */
	u_char totype;
	card_t srccard;         /* card we're uncovering */
	card_t destcard;        /* card we're moving to */
	signed char pri;        /* move priority (low priority == low value) */
} MOVE;

#define O_TYPE 1                /* pile types */
#define T_TYPE 2
#define W_TYPE 3

#define MAXTPILES       8       /* max number of piles */
#define MAXWPILES      13

/* Position information.  We store a compact representation of the position;
Temp cells are stored separately since they don't have to be compared.
We also store the move that led to this position from the parent, as well
as a pointers back to the parent, and the btree of all positions examined so
far. */

typedef struct pos {
	u_char *cards;          /* compact position rep. */
	card_t t[MAXTPILES];    /* temp cells stored separately */
	MOVE *move;             /* move that got us here from the parent */
	struct pos *parent;     /* point back up the move stack */
	u_char nout;            /* number of cards in O */
	u_char ntemp;           /* number of cards in T */
	u_char nchild;          /* number of child nodes */
} POSITION;

/* Work queue.  We want to keep the queue sorted, and we also want to
be able to quickly remove entries. */

typedef struct queue {
	POSITION *pos;
	struct queue *queue;
} QUEUE;

/* Work arrays. */

extern card_t T[MAXTPILES];     /* one card in each temp cell */
extern card_t W[MAXWPILES][52]; /* the workspace */
extern card_t *Wp[MAXWPILES];   /* point to the top card of each work pile */

extern int Nwpiles;             /* the number we're actually using */
extern int Ntpiles;

extern card_t O[4];             /* output piles store only the rank or NONE */
extern card_t Osuit[4];         /* suits of the output piles */

/* Temp storage for possible moves. */

#define MAXMOVES 100            /* > max # moves from any position */
extern MOVE Possible[MAXMOVES];

extern int Cutoff;              /* switch between depth- and breadth-first */
extern int Interactive;         /* exit when we win, else reset */

#define WIN 0
#define NOSOL 1
#define FAIL -1
extern int Status;

/* Statistics. */

extern int Total_positions;
extern int Total_generated;
extern long Mem_remain;

extern int Quiet;

/* Prototypes. */

extern void doit();
extern void read_layout(FILE *);
extern void printcard(card_t card, FILE *);
extern void print_layout();
extern void make_move(MOVE *);
extern void undo_move(MOVE *);
extern MOVE **get_moves(POSITION *, int *);
extern POSITION *new_position(POSITION *parent, MOVE *m);
extern void unpack_position(u_char *);

#define STD_MAX_LINES		(50)
#define STD_MOVES_PER_LINE	(10)
#define AUTO_PER_MOVE		(10)
