// copyight 2001 Adrian Ettlinger

 /* Program for testing winnability of positions in Free Cell.
 */


/*****************************************************************************
Brief summary of the game:


Deal four columns of six cards each, and four of seven cards each, spreading
each column so the cards are all visible.  These columns form the "tableau".
There is a "holding area" that can hold a maximum of four cards.  The only
cards that can be moved are the bottommost card in each column and the cards
in the holding area.  As Aces become available (i.e., can be moved) they are
moved to start four "foundation" piles, which are then built up in suit to
Kings.  The object is to move all the cards to the foundations.


A move consists of moving one card.  A card can move onto a tableau column
if the card being moved is the opposite color and one rank lower than the
card it is being played onto (i.e., the tableau builds down, alternating
color).  Any card can be moved to an empty holding area spot, or to an empty
column in the tableau.


Input format is 52 cards represented either as rank then suit or suit then
rank, where suit is one of CDHS and rank is one of A23456789TJQK.  Lower-case
is okay too.  Other characters such as spaces and line breaks are ignored and
can be used for readability.  E.g.:


7h 9s Kc 5d 8h 3h 6d 9d
7d As 3c Js 8c Kd 2d Ac
2s Qc Jh 8d Th Ts 9h 5h
Qs 6c 4s 6h Ad 8s 2h 4d
Ah 7s 3d Jd 9c 3s Qd Kh
7c 4c Jc Qh 2c Tc 5s 4h
5c Td Ks 6s


*****************************************************************************/

#define FCS 1

#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "main.h"
#include "FCSolve.h"
#include "custom.h"
#include "settings.h"
#include "freecell.h"
#include "cmd_line_chop.h"

extern HANDLE ghSolverThread2 ;
//extern int Free2Solver(Position*, int, int, int, int, char* FCSolveMoves);
#ifdef FCS
//extern int Free2Solver(Position*, int, int, int, int, void*) ;
extern int Free2Solver(Position*, int, int, int, char**, void*) ;
extern LPSTR moves_string ;
#endif
//extern int Free2Solver(Position*, int, int, int, int) ;
//(orig, NoFcs, limit, mode, option, ret_moves)
void FCSolveReadOriginal (void);
extern int gnFCSolveIndex, SolrSel ;
extern char PresortC[] ;
extern BOOL gbSolver, gbAbortA, gbAbortM ;
BOOL gbAbortG ;
int result, FCSmode, FCSlimit ;
static char szTemp[50] ;
FILE *gfpSolFile;
#include "time.h"
#define GET_TIME(var) {time(&var);}
time_t	 stime, etime, oetime, getime ;
int ItCount, ItCounts ;
BOOL gbIntrInd ;
extern BOOL gbSearchF2, gbS2Hot ;
extern BOOL PlayMode2 ; 
//char szFCSPFname[] = "fcspres.txt" ;
char szFCSPFname[] = "fcsprxxx.txt" ;
char szFCSPFnameP[] = "fcspr" ;
char szTxt[] = ".txt" ;
HFILE hpfile ;
//LPSTR FCSPresBuf ;
int pflen ;
args_man_t * args_man ;

char pres[][80] = {"--method soft-dfs -to 0123456789 -step 500 --st-name 1 -nst ",  //begin presets 1 and 3
"--method soft-dfs -to 0123467 -step 500 --st-name 2 -nst ",    //B
"--method random-dfs -seed 2 -to 0[01][23456789] -step 500 --st-name 3 -nst ",
"--method random-dfs -seed 1 -to 0[0123456789] -step 500 --st-name 4 -nst ",
"--method random-dfs -seed 3 -to 0[01][23467] -step 500 --st-name 5 -nst ",
"--method random-dfs -seed 4 -to 0[0123467] -step 500 --st-name 9 -nst ",
"--method random-dfs -to [01][23456789] -seed 8 -step 500 --st-name 10 -nst ",
"--method random-dfs -to [01][23456789] -seed 268 -step 500 --st-name 12 ",
"--method random-dfs -seed 1 -to 0[0123456789] -step 500 -nst ",  //begin preset 2
"--method random-dfs -seed 2 -to 0[01][23456789] -step 500 -nst ",  //J
"--method random-dfs -seed 3 -to 0[01][23467] -step 500 -nst ",
"--method a-star -step 500 -nst ",
"--method a-star -to 0123467 -step 500 -nst ",
"--method random-dfs -seed 4 -to 0[0123467] -step 500 -nst ",
"--method soft-dfs -step 500", 
"--method soft-dfs -to 01ABCDE -step 500 --st-name 0 -nst ",  //begin preset 4
"--method random-dfs -to [01][ABCDE] -seed 1 -step 500 --st-name 1 -nst ",  //Q
"--method random-dfs -to [01][ABCDE] -seed 2 -step 500 --st-name 2 -nst ",
"--method random-dfs -to [01][ABCDE] -seed 3 -step 500 --st-name 3 -nst ",
"--method random-dfs -to 01[ABCDE] -seed 268 -step 500 --st-name 4 -nst ",
"--method a-star -to 01ABCDE -step 500 --st-name 5 -nst ",
"--method a-star -to 01ABCDE -asw 0.2,0.3,0.5,0,0 -step 500 --st-name 6 -nst ",
"--method random-dfs -to [01][ABCDE] -seed 192 -step 500 --st-name 9 -nst ",
"--method random-dfs -to [01ABCDE] -seed 1977 -step 500 --st-name 10 -nst ",
"--method random-dfs -to [01ABCDE] -seed 24 -step 500 --st-name 11 ",
"--method soft-dfs -to 01ABCDE -step 500 --st-name 0 -nst ",  //begin preset 5  (Z)
"--method random-dfs -to [01][ABCDE] -seed 1 -step 500 --st-name 1 -nst ",
"--method random-dfs -to [01][ABCDE] -seed 2 -step 500 --st-name 2 -nst ",
"--method random-dfs -to [01][ABCDE] -seed 3 -step 500 --st-name 3 -nst ",
"--method random-dfs -to 01[ABCDE] -seed 268 -step 500 --st-name 4 -nst ",
"--method a-star -to 01ABCDE -step 500 --st-name 5 -nst ",
"--method a-star -to 01ABCDE -asw 0.2,0.3,0.5,0,0 -step 500 --st-name 6 -nst ",
"--method a-star -to 01ABCDE -asw 0.5,0,0.5,0,0 -step 500 --st-name 7 -nst ",
"--method random-dfs -to [01][ABD][CE] -seed 1900 -step 500 --st-name 8 -nst ",
"--method random-dfs -to [01][ABCDE] -seed 192 -step 500 --st-name 9 -nst ",
"--method random-dfs -to [01ABCDE] -seed 1977 -step 500 --st-name 10 -nst ",
"--method random-dfs -to [01ABCDE] -seed 24 -step 500 --st-name 11 -nst ",
"--method soft-dfs -to 01ABDCE -step 500 --st-name 12 -nst ",
"--method soft-dfs -to ABC01DE -step 500 --st-name 13 -nst ",
"--method soft-dfs -to 01EABCD -step 500 --st-name 14 -nst ",
"--method soft-dfs -to 01BDAEC -step 500 --st-name 15 "
} ;

char FCSPresBuf[3500] ;

char presp[][2500] = {"--prelude 350@2,350@5,350@9,350@12,350@2,350@10,350@3,350@9,350@5,350@4,350@2,350@5,350@10,350@3,350@2,350@4,350@5,350@2,700@5,350@12,1050@9,350@10,350@2,350@10,1050@5,350@10,350@12,700@2,700@1,700@4,700@12,1400@2,700@9,350@10,700@3,700@4,700@2,5250@5,1050@10,1750@3,1400@1,1400@10,5600@1,4900@12,23450@2 ",
"--prelude 3000@0,3000@11,3000@2,3000@9,3000@10,3000@3,3000@4,3000@0,3000@1,3000@10,3000@11,3000@2,3000@0,3000@1,3000@6,3000@1,3000@3,3000@9,3000@2,3000@4,3000@0,3000@4,3000@3,3000@6,3000@9,3000@3,3000@4,6000@9,12000@10,6000@1,3000@6,6000@3,3000@6,3000@9,6000@3,3000@6,9000@11,6000@1,12000@0,12000@3,3000@4,6000@9,6000@1,33000@2,12000@9,9000@11,6000@0,6000@4,6000@2,24000@4,9000@6,45000@0,9000@1,21000@3,9000@4,21000@5,33000@6,18000@3,21000@9,42000@10,42000@0,42000@3,66000@2,123000@3,129000@6,81000@4,132000@5,165000@11 ",
"--prelude 1000@0,1000@3,1000@0,1000@9,1000@4,1000@9,1000@3,1000@4,2000@2,1000@0,2000@1,1000@14,2000@11,1000@14,1000@3,1000@11,1000@2,1000@0,2000@4,2000@10,1000@0,1000@2,2000@10,1000@0,2000@11,2000@1,1000@10,1000@2,1000@10,2000@0,1000@9,1000@1,1000@2,1000@14,3000@8,1000@2,1000@14,1000@1,1000@10,3000@6,2000@4,1000@2,2000@0,1000@2,1000@11,2000@6,1000@0,5000@1,1000@0,2000@1,1000@2,3000@3,1000@10,1000@14,2000@6,1000@0,1000@2,2000@11,6000@8,8000@9,3000@1,2000@10,2000@14,3000@15,4000@0,1000@8,1000@10,1000@14,7000@0,14000@2,6000@3,7000@4,1000@8,4000@9,2000@15,2000@6,4000@3,2000@4,3000@15,2000@0,6000@1,2000@4,4000@6,4000@9,4000@14,7000@8,3000@0,3000@1,5000@2,3000@3,4000@9,8000@10,9000@3,5000@8,7000@11,11000@12,12000@0,8000@3,11000@9,9000@15,7000@2,12000@8,16000@5,8000@13,18000@0,9000@15,12000@10,16000@0,14000@3,16000@9,26000@4,23000@3,42000@6,22000@8,27000@10,38000@7,41000@0,42000@3,84000@13,61000@15,159000@5,90000@9 "
} ;
int signal_step(int ItCount)
{sprintf (szTemp, "At %d Iterations...", ItCount);
	StatusOut(szTemp) ;
//	if ((gnMaxTime != 0) && (((gnSolve == SOLVE_RANGE) || (gnSolve == SOLVE_LIST)))) 
	if (gnMaxTime != 0)
	{
	time (&getime) ;
    if ((getime - stime) >= gnMaxTime)
		{
		ItCounts = ItCount ;
		gbAbortG = TRUE ;
		return 1 ;
		}
	}
	if ((!gbAbortA) && (!gbAbortM)) 
		return 0 ;
return 1 ;
}

DWORD Free2Main (HWND hwnd)
{
	// set below normal priority so we can use menu

//extern int SupMove ;
//extern int FcMode ;
/*
sprintf(szTemp, "sm- %d fc- %d ", SupMove, FcMode) ;
MessageBox(GetFocus(), szTemp, "FCP", MB_OK) ;
*/
//FcMode = 0 ;   // TEMP TEST
//SupMove = 1 ;
DWORDLONG nGame;
int WinCount, AboCount, ImpCount, i ;
	
	SetThreadPriority (GetCurrentThread (), 
						THREAD_PRIORITY_BELOW_NORMAL);

//	result = Free2Solver (&orig, NUM_FCS, 2000000, 0, 0, (LPSTR)FCSolveMoves);
	if (gnMaxHands == 0)
		FCSlimit = 100000000 ;
	else
		FCSlimit = gnMaxHands ;
	FCSmode = 0 ;

//NEW CODE FOR PRESET SYSTEM 5/25/02 & 7/3/02
  FCSPresBuf[0] = 0 ;
//  if (((PresortC[0] >= '1') && (PresortC[0] <= '5')) || ((PresortC[0] >= 'A') && (PresortC[0] <= 'Z')))
  if (!isalnum(PresortC[1]) && (((PresortC[0] >= '1') && (PresortC[0] <= '5')) || ((PresortC[0] >= 'A')
				&& (PresortC[0] <= 'Z'))))
		{
		if (PresortC[0] == '1')
			{
			for (i = 0 ; i < 8 ; i++)
				lstrcat(FCSPresBuf, pres[i]) ;
			}
		if (PresortC[0] == '2')
			{
			for (i = 8 ; i < 15 ; i++)
				lstrcat(FCSPresBuf, pres[i]) ;
			}
		if (PresortC[0] == '3')
			{
			for (i = 0 ; i < 8 ; i++)
				lstrcat(FCSPresBuf, pres[i]) ;
			lstrcat(FCSPresBuf, presp[PresortC[0] - '3']) ;
			}
		if (PresortC[0] == '4')
			{
			for (i = 15 ; i < 25 ; i++)
				lstrcat(FCSPresBuf, pres[i]) ;
			lstrcat(FCSPresBuf, presp[PresortC[0] - '3']) ;
			}
		if (PresortC[0] == '5')
			{
			for (i = 25 ; i < 41 ; i++)
				lstrcat(FCSPresBuf, pres[i]) ;
			lstrcat(FCSPresBuf, presp[PresortC[0] - '3']) ;
			}
		if (isalpha(PresortC[0]))
			lstrcat(FCSPresBuf, pres[PresortC[0] - 'A']) ;
		}
	else
		{
		lstrcpy(szFCSPFname, szFCSPFnameP) ;
		lstrcat(szFCSPFname, PresortC) ;
		lstrcat(szFCSPFname, szTxt) ;
//MainMessage(szFCSPFname) ;
		hpfile = -1 ;
		hpfile = _lopen(szFCSPFname, OF_READ) ;
		if (hpfile != -1)
		{
		pflen = _llseek(hpfile, 0L, 2) ;	
		_llseek(hpfile, 0L, 0) ;
		_lread(hpfile, (LPSTR)FCSPresBuf, pflen) ;
		FCSPresBuf[pflen] = 0 ;
		_lclose(hpfile) ;
		}
	else
		FCSPresBuf[0] = 0 ;
	}
//MessageBox(GetFocus(),FCSPresBuf, "PresBuf", MB_OK) ;
//	args_man_t * args_man = args_man_alloc()  ;
if (FCSPresBuf[0] != 0)
{
	args_man = args_man_alloc()  ;
	args_man_chop(args_man, FCSPresBuf);
}
//sprintf(szTemp, "ac- %d st0- %s st1- %s", args_man->argc, args_man->argv[0], args_man->argv[1]) ;
//MessageBox(GetFocus(), szTemp, "FC", MB_OK) ;
	
	if ((gnSolve != SOLVE_RANGE) && (gnSolve != SOLVE_LIST))
   { 
	time (&stime);
	FCSolveReadOriginal ();
	gfpSolFile = fopen ("solution.txt", "w");
#ifdef FCS
//	result = Free2Solver (&orig, NUM_FCS, FCSlimit, FCSmode, 0, &signal_step);
if (FCSPresBuf[0] != 0)
{
//MainMessage("pre-Solv") ;
	result = Free2Solver (&orig, NUM_FCS, FCSlimit, args_man->argc, args_man->argv, &signal_step);
//MainMessage("post-Solv") ;
	args_man_free(args_man) ;
}
else
	result = Free2Solver (&orig, NUM_FCS, FCSlimit, 0, 0, &signal_step);
#endif
	if (result < 0)
	{
		if (gbSearchF2)
		{
			gbSearchF2 = FALSE ;
			KillTimer(hwnd, 1) ;
			MessageBox(hwnd, "Impossible.", "Solver2", MB_ICONEXCLAMATION | MB_OK) ;
			gbSearchF2  = TRUE ;
			SetTimer(hwnd, 1, 20,NULL) ;
		}
		sprintf(szTemp, "Impossible. %d Iterations", -result) ;
	}
	if (result > 0)
	{
		sprintf(szTemp, "Winnable. %d Iterations", result) ;
	}
	if (result == 0)
		lstrcpy (szTemp, "Intractable");
	if (gbAbortA)
	{
		strcpy (szTemp, "Aborted");
		gbAbortA = gbAbortM = FALSE ;
	}
	StatusOut (szTemp);
	if (result > 0)
	{
#ifdef FCS
		lstrcpy(FCSolveMoves,moves_string) ;
#endif
		gnFCSolveIndex = lstrlen(FCSolveMoves) ;
		if (((gnGameNumber < 0xf00000000)|| gbCustomGame) && 
//					(gnSolve == SOLVE_SOLUTION) && !gbAbort)
					(gnSolve == SOLVE_SOLUTION))
		{
		if (gnFCSolveIndex > (STD_MOVES_PER_LINE * STD_MAX_LINES * AUTO_PER_MOVE - 2))
			MainMessage("Winnable, but....\nSolution is too long\nto be replayed.") ;
		else
		{
			gbSolver2 = TRUE ;
			PostMessage (hwnd, WM_USER+100, 0, 0);
		}
		}
	}
		time (&etime);
	fprintf (gfpSolFile, "Game #%s  %s", FmtGameNo(gnGameNumber), szTemp);
    if (result == 0)
		result = gnMaxHands ;
	fprintf (gfpSolFile, "  Elapsed Seconds: %d\n", etime - stime);		
	fclose (gfpSolFile);
   }
   else
   {   //  Range or List solve
		gfpSolFile = fopen ("solrange.txt", "w");
		WinCount = AboCount = ImpCount = 0 ;
		time (&oetime);
		if (gnSolve == SOLVE_LIST)
	{
		gnFirstGame = GetSolveGame(0) ;
		if (gnFirstGame < 0)
			return 0 ;
		gnLastGame = 0x7ffffffff ; // set to allow to run all the way
	}
  // this is the loop for a range 
	// (firstgame = lastgame = 1 if not a range)

	for (nGame = gnFirstGame; (nGame <= gnLastGame) && !gbAbortA && !gbAbortM ; nGame++)
	{
		gbIntrInd = FALSE ;
		time (&stime);
		gnGameNumber = nGame;
		FreeCellInit (FALSE);
		FCSolveReadOriginal ();
#ifdef FCS
//		result = Free2Solver (&orig, NUM_FCS, FCSlimit, FCSmode, 0, &signal_step);
if (FCSPresBuf[0] != 0)
		result = Free2Solver (&orig, NUM_FCS, FCSlimit, args_man->argc, args_man->argv, &signal_step);
else
		result = Free2Solver (&orig, NUM_FCS, FCSlimit, 0, 0, &signal_step);
#endif
//		result = Free2Solver (&orig, NUM_FCS, FCSlimit, FCSmode, 0);
		time (&etime);
		if (nGame == gnFirstGame)
			lstrcpy(szTemp, "-ST") ;
		else
			lstrcpy(szTemp, " ") ;
		if (nGame == gnLastGame)
			lstrcpy(szTemp, "-EN") ;
		if (result > 0 )
		{	
			WinCount++ ;
			if (!SolrSel || ((SolrSel == 1) && (NUM_FCS < 2)))
				lstrcpy(szTemp,"Winnable") ;
		}
		if (result < 0 )
		{
			ImpCount++ ;
			if (!SolrSel || ((SolrSel == 1) && (NUM_FCS > 1)))
				lstrcpy(szTemp,"Impossible") ;
		}
		if (result == 0)
		{
			gbIntrInd = TRUE ;
			AboCount++ ;
			if (!gbAbortG)
				result = gnMaxHands ;
			else
			{
				result = ItCounts ;
				gbAbortG = FALSE ;
			}
			lstrcpy(szTemp, "Intractable") ;
		}
		if (gbAbortM)
		{
			lstrcpy (szTemp, "Aborted");
		}
		if (!SolrSel || gbIntrInd ||
			(((NUM_FCS < 2) && (result >= 0)) || ((NUM_FCS > 1) && (result <= 0)))
			|| ((SolrSel == 1) && (szTemp[0] == '-')))
		{
			fprintf (gfpSolFile, "%s", FmtGameNo(gnGameNumber)) ;
			fprintf (gfpSolFile, " %s %8d", szTemp, abs(result)) ;
			fprintf (gfpSolFile, " iterations") ;
			time (&etime);
			fprintf (gfpSolFile, " %d seconds\n", etime - stime);
		}
		if ((gnSolve == SOLVE_LIST)	&& (nGame == gnGameNumber))
		{
			nGame = GetSolveGame(1) ;
			if (nGame < 0)
				nGame = 0x7ffffffff ; // force end
			nGame-- ; // because loop will increment number
		}
		if (gbAbortM || gbAbortA)
		{
//MessageBox(GetFocus(), "2", "FC", MB_OK) ;
			nGame = gnLastGame ;
			gbAbortM = gbAbortA = FALSE ;
			break ;
		}
	}	   
	fprintf (gfpSolFile, "\nNumber of Freecells: %d   Mode: ", NUM_FCS);
	fprintf (gfpSolFile, PresortC);
	fprintf (gfpSolFile, "\n");
	if (gnMaxTime)
		fprintf (gfpSolFile, "Max Time: %d  ", gnMaxTime) ;
	if (gnMaxHands)
		fprintf (gfpSolFile, "Max Iterations: %d  ", gnMaxHands) ;
	fprintf (gfpSolFile, "\n");
	fprintf (gfpSolFile, "Winnables: %d\n", WinCount);
	fprintf (gfpSolFile, "Impossibles: %d\n", ImpCount);
	fprintf (gfpSolFile, "Intractables: %d\n", AboCount);
	if ((etime - oetime) < 3600)
      fprintf (gfpSolFile, "Total time: %d Minutes, %d Seconds\n", (etime - oetime)/60,	
					(etime - oetime)%60) ;
	else
      fprintf (gfpSolFile, "Total time: %d Hours, %d Minutes, %d Seconds\n",
			(etime - oetime)/3600, ((etime - oetime)%3600) / 60,	
					(etime - oetime)%60) ;
	fclose(gfpSolFile) ;
	if (FCSPresBuf[0] != 0)
		args_man_free(args_man) ;
	MainStartGame (TRUE);
   }	   
	ghSolverThread2 = NULL;
	if (gnSolve == SOLVE_SOLUTION)
		PlayMode2 = TRUE ;
	else
		PlayMode2 = FALSE ;
	gbSolver2 = FALSE ;
	if (gbS2Hot && (result <= 0) && (NumFcs > 0))
	{
		SetTimer(hwnd, 1, 2, NULL) ;
	}
    ExitThread (0);
	return 0; // not reached
}
