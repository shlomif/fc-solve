// copyight 2001 Adrian Ettlinger

 /* Program for testing winnability of positions in Free Cell.
 */


/*****************************************************************************
Brief summary of the game:


Deal four columns of six cards each, and four of seven cards each, spreading
each column so the cards are all visible.  These columns form the "tableau".
There is a "holding area" that can hold a maximum of four cards.  The only
cards that can be moved are the bottommost card in each column and the cards
in the holding area.  As Aces become available (i.e., can be moved) they are
moved to start four "foundation" piles, which are then built up in suit to
Kings.  The object is to move all the cards to the foundations.


A move consists of moving one card.  A card can move onto a tableau column
if the card being moved is the opposite color and one rank lower than the
card it is being played onto (i.e., the tableau builds down, alternating
color).  Any card can be moved to an empty holding area spot, or to an empty
column in the tableau.


Input format is 52 cards represented either as rank then suit or suit then
rank, where suit is one of CDHS and rank is one of A23456789TJQK.  Lower-case
is okay too.  Other characters such as spaces and line breaks are ignored and
can be used for readability.  E.g.:


7h 9s Kc 5d 8h 3h 6d 9d
7d As 3c Js 8c Kd 2d Ac
2s Qc Jh 8d Th Ts 9h 5h
Qs 6c 4s 6h Ad 8s 2h 4d
Ah 7s 3d Jd 9c 3s Qd Kh
7c 4c Jc Qh 2c Tc 5s 4h
5c Td Ks 6s


*****************************************************************************/

#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "main.h"
#include "FCSolve.h"
#include "custom.h"
#include "settings.h"
#include "freecell.h"

extern HANDLE ghSolverThread3 ;
extern int patsub(Position*, int, int, int, char) ;
void FCSolveReadOriginal (void);
extern LPSTR moves_string ;
extern int gnFCSolveIndex, SolrSel ;
extern BOOL gbSolver, gbAbortA, gbAbortM ;
BOOL gbAbortG ;
int result, PSmode, PSlimit ;
static char szTemp[50] ;
FILE *gfpSolFile;
#include "time.h"
#define GET_TIME(var) {time(&var);}
time_t	 stime, etime, atime, oetime, getime ;
int ItCount, ItCounts ;
extern BOOL gbSearchF3, gbFastSolve, gbS3Hot ;
int gnCutoff = 2;
extern char szTempA[] ;
extern int Total_generated, Total_positions, Mem_remain ;
extern int Status ;
BOOL Cmode, DPend ;
int Cph, gnMaxHandsS, gnMaxTimeS, gnCutoffS, pMaxTime ;
char szPatMode[3] ;
char cPatMode, cPatModeS, pPatMode ;

char szTemp[50] ;

BOOL S3AbtTest()
{
if ((!gbAbortA) && (!gbAbortM)) 
		return FALSE ;
if ((gnSolve == SOLVE_RANGE) || (gnSolve == SOLVE_LIST))
{
	gbAbortM = gbAbortA = FALSE ;
	gbAbortG = TRUE ;
	StatusOut("Aborted") ;
}
return TRUE ;
}

DWORD Free3Main (HWND hwnd)
{
	// set below normal priority so we can use menu

DWORDLONG nGame, nlGame;
int WinCount, AboCount, ImpCount ;
	
	SetThreadPriority (GetCurrentThread (), 
						THREAD_PRIORITY_BELOW_NORMAL);

	if (gnMaxHands == 0)
		PSlimit = 60 ;
	else
		PSlimit = gnMaxHands ;
	PSmode = 0 ;
	cPatMode = szPatMode[0] ;
	cPatModeS = cPatMode ;
//	if ((gnSolve != SOLVE_RANGE) && (gnSolve != SOLVE_LIST) && ((cPatMode != 'X') ||
	if ((gnSolve != SOLVE_RANGE) && (gnSolve != SOLVE_LIST) || 
		(((cPatMode == 'X') && gbSearchF3)) || gbS3Hot)
   {
	if ((cPatMode != 'X') && (cPatMode != 'E') && (cPatMode != 'A')	&& (cPatMode != 'B')
			&& (cPatMode != 'F') && (cPatMode != 'T'))
		cPatMode = 'S' ;  // For initialization, must be legit setting of cPatMode
	if (cPatMode == 'X')
	{
//MainMessage("Free3");
		cPatModeS = 'X' ;
		cPatMode = 'S' ;
	}
	time (&stime);
	FCSolveReadOriginal ();
	gfpSolFile = fopen ("solution.txt", "w");
	result = patsub(&orig, NUM_FCS, PSlimit, gnCutoff, cPatMode) ;
	if (result > 0)
	{
//sprintf(szTemp, "TG-%d ", Total_generated) ;
//MessageBox(GetFocus(), szTemp, "Free3", MB_OK) ; 
		if ((NUM_FCS != 0) && (Total_generated < 3))
		{
MessageBox(GetFocus(), "Phony Impossible Trap", "Free3", MB_OK) ;  // This was a patch by ABE as a kludgy workaround
			result = patsub(&orig, NUM_FCS, PSlimit, gnCutoff, cPatMode) ;// for the phony impossible problem. and shouldn't 
		}													// really be needed any longer.  The trap is left in
		if ((NUM_FCS != 0) && (Total_generated < 3))		// to identify if the problem returns.  A more legitimate
			result = patsub(&orig, NUM_FCS, PSlimit, gnCutoff, cPatMode) ; // fix is now in the get_moves routine in pat.c
		if (gbSearchF3 && (result > 0))
		{
			gbSearchF3 = FALSE ;
			sprintf(szTemp, "Gen,= %d  TPos.= %d  ", Total_generated, Total_positions);
			StatusOut(szTemp) ;
			KillTimer(hwnd, 1) ;
			MessageBox(hwnd, "Impossible.", "Solver3", MB_ICONEXCLAMATION | MB_OK) ;
			gbSearchF3  = TRUE ;
			SetTimer(hwnd, 1, 20,NULL) ;
		}
		if (result > 0)  // only after three tries
			lstrcpy(szTemp, "Impossible. ") ;
	}
	if (result == 0)
	{
		lstrcpy(szTemp, "Winnable.") ;
	}
	if (result == -1)
	{
		lstrcpy (szTemp, "Intractable");
	}
	if (result == -3)
		lstrcpy (szTemp, "NO RESULT");
	if (gbAbortA)
	{
		strcpy (szTemp, "Aborted");
		gbAbortA = FALSE ;
	}
	lstrcat(szTemp, szTempA) ;
	StatusOut (szTemp);
	if (result == 0)
	{
		gnFCSolveIndex = lstrlen(FCSolveMoves) ;
//sprintf(szTemp, "RP idx-%d", gnFCSolveIndex, MB_OK) ;
//MainMessage(szTemp) ;
		if (((gnGameNumber < 0xf00000000)|| gbCustomGame) && 
					(gnSolve == SOLVE_SOLUTION))
		{
		if (gnFCSolveIndex > (STD_MOVES_PER_LINE * STD_MAX_LINES * AUTO_PER_MOVE - 2))
			MainMessage("Winnable, but....\nSolution is too long\nto be replayed.") ;
		else
		{
			gbSolver3 = TRUE ;
			PostMessage (hwnd, WM_USER+100, 0, 0);
		}
		}
	}
		time (&etime);
	fprintf (gfpSolFile, "Game #%s  %s", FmtGameNo(gnGameNumber), szTemp);
    if (result == 0)
		result = gnMaxHands ;
	fprintf (gfpSolFile, "  Elapsed Seconds: %d\n", etime - stime);		
	fclose (gfpSolFile);
	}
   else
   {   //  Range or List solve
//MessageBox(GetFocus(), "Range", "Ent", MB_OK);
		Cmode = FALSE ;
		gnCutoffS = gnCutoff ;
		if ((gnCutoff == 9) || (cPatMode = 'X'))
		{
			gnCutoff = 2 ;
			Cmode = TRUE ;
			Cph = 0 ;
			gnMaxTimeS = gnMaxTime ;
			gnMaxHandsS = gnMaxHands ;
			cPatModeS = 'S' ;
			if (cPatMode == 'X')
			{
//MainMessage("Free3A");
				cPatModeS = 'X' ;
				cPatMode = 'S' ;
			}
		}
		if (gnSolve == SOLVE_RANGE)
			gfpSolFile = fopen ("solrange.txt", "w");
		WinCount = AboCount = ImpCount = 0 ;
		time (&oetime);
		if (gnSolve == SOLVE_LIST)
	{
		gnFirstGame = GetSolveGame(0) ;
		if (gnFirstGame < 0)
			return 0 ;
		gnLastGame = 0x7ffffffff ; // set to allow to run all the way
	}
  // this is the loop for a range 
	// (firstgame = lastgame = 1 if not a range)
	if ((SolrSel == 1) || (SolrSel == 2))
	{
		fprintf (gfpSolFile, "%s", FmtGameNo(gnFirstGame)) ;
		fprintf (gfpSolFile, "     -ST\n") ;
	}
	nlGame = gnFirstGame + 1 ;
	Cph = 0 ;
	for (nGame = gnFirstGame; (nGame <= gnLastGame) && !gbAbortA && !gbAbortM ; nGame++)
	{
//sprintf(szTemp, "Cph-%d CO-%d", Cph, gnCutoff) ;
//MessageBox(GetFocus(), szTemp, "LoopEnt", MB_OK);
		time (&stime);
//		if ((Cph == 0) && (cPatMode == 'S'))
		if (nGame != nlGame)
		{
			atime = stime ;
			DPend = FALSE ;
			nlGame = nGame ;
		}
		gnGameNumber = nGame;
		FreeCellInit (FALSE);
		FCSolveReadOriginal ();
		result = patsub(&orig, NUM_FCS, PSlimit, gnCutoff, cPatMode) ;
		pPatMode = cPatMode ;
		pMaxTime = gnMaxTime ;
		if (result == 0)
		{	
			if (Cmode)
				Cph = 0 ;
			WinCount++ ;
			if (gnSolve == SOLVE_RANGE)
				lstrcpy(szTemp,"Win") ;
			else
				lstrcpy(szTemp,"Winnable") ;
		}
		if (result > 0 )
		{
			if (Cmode)
				Cph = 0 ;
			ImpCount++ ;
			if (gnSolve == SOLVE_RANGE)
				lstrcpy(szTemp,"IMP") ;
			else
				lstrcpy(szTemp,"Impossible") ;
		}
		if (result < 0)
		{
			if (!Cmode)
			{
			AboCount++ ;
			lstrcpy(szTemp, "Intractable") ;
			}
			else
			{
			if (cPatModeS != 'X')
			{
				gnCutoff-- ;
				if (gnCutoff == 0)
					gnCutoff = 3 ;
				if ((Cph < 3) && (gnCutoff == 2))
				{
					Cph++ ;
					gnMaxTime += gnMaxTime ;
					gnMaxHands += gnMaxHands ;
				}
			}
			else
			{
			if (Cph < 5)
				{
//				pPatMode = cPatMode ;
//				pMaxTime = gnMaxTime ;
				if (cPatMode == 'S')
					cPatMode = 'E' ;
				else
					{
					cPatMode = 'S' ;
					Cph++ ;
					gnMaxTime += gnMaxTime ;
					gnMaxHands += gnMaxHands ;
					}
				}
			}
				if (((Cph == 3) && (gnCutoff == 2)) || ((Cph == 5) &&  (cPatMode == 'E')))
				{
				AboCount++ ;
				lstrcpy(szTemp, "Intractable") ;
				}
				else
					lstrcpy(szTemp, "Rpt") ;
			}
		}
	    if (gbAbortM)
		{
			lstrcpy (szTemp, "Aborted");
		}   
/*
			if (Cmode && (SolrSel == 2) && (result < 0))
				DPend = TRUE ;
			if ((gnSolve == SOLVE_RANGE) && (((!SolrSel || (((NUM_FCS < 2) && (result <= 0)) || ((NUM_FCS > 1)
			&& (result != 0)))) && (!Cmode || (Cmode && ((Cph == 0) && (result != -1)))) || ((SolrSel == 2)
			&& (result >= 0))) ||
//			(Cmode && (SolrSel == 2) && (result < 0)) ||
			(Cmode && (SolrSel == 2) && (result >= 0) && DPend && 
			((cPatModeS != 'X') && ((gnCutoff != 2) || (gnMaxTime != gnMaxTimeS))))
			|| (Cmode && (((cPatMode != 'X') && (Cph == 3)) || ((cPatMode == 'X') && (Cph == 5)))
			&& (result < 0))))
*/
		if (Cmode && (result < 0) && (cPatMode == 'X') && (Cph < 5))
			DPend = TRUE ;
		if (((SolrSel == 0) && ((result >= 0) || ((result < 0) && (Cph > 2)))) ||
			((SolrSel >= 1) && (((result < 0) && (Cph > 2)) || ((result == 0) && (NUM_FCS < 2)) ||
				((result > 0) && (NUM_FCS > 1)) || ((result >= 0) && (SolrSel == 2) && ((Cph != 0)
				|| (cPatMode != 'S'))))))
			
		{
//sprintf(szTemp, "res-%d CO-%d g-%d", result, gnCutoff, nGame) ;
//MessageBox(GetFocus(), szTemp, "Print", MB_OK);
			fprintf (gfpSolFile, "%s", FmtGameNo(gnGameNumber)) ;
			fprintf (gfpSolFile, " %s %8d", szTemp, Total_generated) ;
			if (!Cmode)
				fprintf (gfpSolFile, " pos. generated") ;
			else
			{
				if (SolrSel != 2)
//					fprintf (gfpSolFile, " pos. c=%d",gnCutoff) ;
					fprintf (gfpSolFile, " pos.") ;
				else
//					fprintf (gfpSolFile, " pos. c=%d MT=%d",gnCutoff, gnMaxTime) ;
					fprintf (gfpSolFile, " pos. m=%c MT=%d",pPatMode, pMaxTime) ;
			}
			time (&etime);
			fprintf (gfpSolFile, " %d seconds\n", etime - atime);
		}
		if (((SolrSel == 1) || (SolrSel == 2)) && (nGame == gnLastGame))
		{
			fprintf (gfpSolFile, "%s", FmtGameNo(gnGameNumber)) ;
			fprintf (gfpSolFile, "     -EN\n") ;
		}
		if ((gnSolve == SOLVE_LIST)	&& (nGame == gnGameNumber))
		{
			nGame = GetSolveGame(1) ;
			if (nGame < 0)
				nGame = 0x7ffffffff ; // force end
			nGame-- ; // because loop will increment number
		}
		if (gbAbortM || gbAbortG || gbAbortA)
		{
//MessageBox(GetFocus(),"3Halt", "Slv3", MB_OK) ;
			nGame = gnLastGame ;
			gbAbortM = gbAbortA = gbAbortG = FALSE ;
			break ;
		}
		if (Cmode && (((cPatModeS != 'X') && (Cph < 3)) || ((cPatModeS == 'X') && (Cph < 5)))
			&& (((Cph > 0) || (result < 0)) && (Cph != 3)))
		{
			nGame-- ;  // loop-around for Cmode, same Game
		}
		DPend = FALSE ;
		if (Cmode && (result >=0))
			gnCutoff = 2 ;
		if (Cmode && ((result >=0) || ((result < 0) && (Cph == 3))))
			{
			Cph = 0 ;
			cPatMode = 'S' ;
			gnMaxTime = gnMaxTimeS ;
			gnMaxHands = gnMaxHandsS ;
			}
	}	   
time (&etime);
if (gnSolve == SOLVE_RANGE)
{
	fprintf (gfpSolFile, "\nNumber of Freecells: %d ", NUM_FCS);
	fprintf (gfpSolFile, "\n");
	if (gnMaxTime)
		fprintf (gfpSolFile, "Max Time: %d  ", gnMaxTime) ;
	if (gnMaxHands)
		fprintf (gfpSolFile, "Max Space: %d mBytes ", gnMaxHands) ;
	fprintf (gfpSolFile, "\n");
	fprintf (gfpSolFile, "Mode %c \n", cPatModeS) ;
	fprintf (gfpSolFile, "Winnables: %d\n", WinCount);
	fprintf (gfpSolFile, "Impossibles: %d\n", ImpCount);
	fprintf (gfpSolFile, "Intractables: %d\n", AboCount);
	if ((etime - oetime) < 3600)
      fprintf (gfpSolFile, "Total time: %d Minutes, %d Seconds\n", (etime - oetime)/60,	
					(etime - oetime)%60) ;
	else
      fprintf (gfpSolFile, "Total time: %d Hours, %d Minutes, %d Seconds\n",
			(etime - oetime)/3600, ((etime - oetime)%3600) / 60,	
					(etime - oetime)%60) ;
	fclose(gfpSolFile) ;
	gnCutoff = gnCutoffS ;
	MainStartGame (TRUE);
	}
else
	StatusOut(szTemp) ;
   }
    ghSolverThread3 = NULL;
	if ((gnSolve != SOLVE_SOLUTION) || (result != 0))
	{
		gbSolver3 = FALSE ;
//MessageBox(GetFocus(), "Solver3", "End", MB_OK) ; 
	}
	if (gbSearchF3 || (gbS3Hot && (result < 0)))
	{
		SetTimer(hwnd, 1, 2, NULL) ;
	}
	if ((gnSolve == SOLVE_RANGE) || (gbS3Hot && (result >= 0)))
		cPatMode = cPatModeS ;
	if (result >= 0)
		gbS3Hot = FALSE ;
	ExitThread (0);
	return 0; // not reached
}
