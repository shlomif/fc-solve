#include <string.h>
#include <sys/types.h>
#include "config.h"

static PATSOLVE_INLINE int CMP(u_char *a, u_char *b)
{
	int l;

	l = a[0];
	if (b[0] < l) {
		l = b[0];
	}
	return memcmp(a, b, l);
}

/* A splay tree. */

typedef struct tree_node TREE;

struct tree_node {
	TREE *left;
	TREE *right;
	TREE *parent;
	u_char *key;
};

extern int insert(u_char *key); /* insert a key; returns 1 if new, 0 if old */
extern void destroy();          /* delete the whole tree */
