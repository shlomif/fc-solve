/******************************************************************************\
* wilson callan, copyright 1997
\******************************************************************************/

#include "fchand.h"

//
// dialogs.c
//

BOOL MyDialogBox (HWND hwnd, INT idDlg, DLGPROC pfnDlgProc);
BOOL CALLBACK HelpDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK SelectGameDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK CardSizeDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK WindowColorsDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK LoadSolutionDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK CustomGameDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK SolveDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK Solve2DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK Solve3DlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK SettingsDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK StatisticsDlgProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

//
// misc.c
//

VOID ReadRegistry(VOID);
VOID WriteRegistry (HWND hwnd);
VOID ReadSRegistry(VOID);
VOID WriteSRegistry (HWND hwnd);
INT Message(HWND hwnd, UINT fuStyle, LPSTR pszFormat, ...);
VOID SetMainCaption (HWND hwnd, CHAR *str);
LPTSTR LoadResourceString(UINT wId);
VOID ShowLastError (HWND hwnd, CHAR *id_str);
VOID StringOut (HDC hdc, INT x, INT y, CHAR *str, INT num);
BOOL ObjectInRect (LPRECT object, LPRECT rc);
BOOL FileScan (HFILE fhFile, CHAR ch, INT dir);
LPSTR FmtGameNo (DWORDLONG gnum) ;
DWORDLONG CvGameNo (LPSTR szGNo) ;
//
// fcstatus.c
//

BOOL MakeMoveStatus (CHAR src, CHAR dst);
VOID ShowCardG (CARD c, BOOL moveFrom);
VOID ShowCell (CHAR *str);

//
// file.c
//

VOID FileInit (VOID);
BOOL SaveSolution (HWND hwnd);
BOOL SaveAuto (HWND hwnd);
BOOL SaveSolutionFast (HWND hwnd);
VOID OpenSolution (HWND hwnd);
VOID LoadSolution (HWND hwnd, BOOL fLogging);
BOOL CopySolution (HWND hwnd);
LONGLONG GetSolveGame (int mode) ;
//
// toolbar.c
//

HWND InitTB (HWND hwndParent);
LRESULT CALLBACK ToolBarWndProc(HWND, UINT, WPARAM, LPARAM);

//
// fc_ctrl.c
//

VOID GameLost (VOID);
VOID FlourishCheck (VOID);
VOID StatsUpdate (BOOL result) ;
//
// free1.c
//

DWORD Free1Main (HWND hwnd);
DWORD Free2Main (HWND hwnd);
DWORD Free3Main (HWND hwnd);
BOOL TestSolver() ;
BOOL TestSolverA(WORD wParam) ;
