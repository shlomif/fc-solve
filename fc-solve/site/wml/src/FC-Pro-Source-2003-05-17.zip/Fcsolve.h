// 1997 wilson callan
// 1994 don woods

#define CLUBS	 (0 << 4)
#define DIAMONDS (1 << 4)
#define SPADES	 (2 << 4)
#define HEARTS   (3 << 4)

#define SOLVE_RESULT	(0)
#define SOLVE_RANGE		(1)
#define SOLVE_SOLUTION	(2)
#define SOLVE_LIST		(3)

typedef unsigned char	uchar;
typedef uchar		Pair;	/* 000crrrr: c=color(0=black), 
								r=rank(1-13) */
typedef uchar		Card;
typedef uchar		Loc;	/* cccnnnnn: c=column 0-7, 
							n=index in column 0-18; or
				   000111xx: in holding area xx=0-3;
	(for >4 freecells, 00011xxx, xxx=0-5) 			   
					 or
				   11111111: on foundation */
typedef uchar		Swap;	/* 0 = cannot be swapped 
							(includes cases where
				   it could've been but the other card has
				   since been removed), 1 = can be swapped,
				   2 =has been swapped (matters only when
				   reconstructing path to a position) */

typedef struct column_struct {
	uchar	count;		/* number rdof cards in column */
Pair	cards[19];
} Column;
//#define SPEEDTRY4 1
//#define SPEEDTRY5 1
#define FC5UH 1
typedef struct pos_struct {
	uchar	foundations[4];
#ifndef FC5UH
	Pair	hold[4];
#else
	Pair	hold[10];
#endif
	uchar	colSeq[8];	/* sorted order for tableau columns */
	Column	tableau[8];
#ifndef SPEEDTRY4
	Loc	location[52];
#ifndef SPEEDTRY5
	Swap	swappable[26];
#endif
#endif
	Card	moved;		/* most recently moved card */
	int	mustTry;	/* must move to/from this col if possible */
	struct pos_struct *via;	  /* position from which this was reached */
#ifndef SPEEDTRY4
#ifndef SPEEDTRY5
    struct pos_struct *swapvia; /* ditto but with most recently moved
				       card swapped with its mate */
#endif
#endif
	struct pos_struct *chain; /* for chaining in hash table */
	long	hash;
#define DHASH (1)
#ifdef DHASH
	long hash2 ;
#endif
} Position;

VOID FCSolvePlay (HWND hwnd);
INT AdvColSeq(BOOL Mode) ;

extern Position orig;	/* special in that only tableau[] is set, 
						and it stores Cards instead of Pairs */

extern FILE *SolFile;
extern BOOL gbLoadingSolver, gbSolverLoaded, gbSolver2, gbSolver3 ;
extern char PresortC[] ;
extern INT gnFCSolveIndexC ;
extern char FCSolveMoves[] ;
extern char ColSeqC[] ;
extern int gnMaxHands, gnMaxTime, gnMaxSpace, gnMaxTimeB, gnCutoff ;
