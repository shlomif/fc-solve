/******************************************************************************\
*       This was a part of the Microsoft Source Code Samples. 
*       Copyright (C) 1992-1995 Microsoft Corporation.
*       All rights reserved. 
*       This source code is only intended as a supplement to 
*       Microsoft Development Tools and/or WinHelp documentation.
*       See these sources for detailed information regarding the 
*       Microsoft samples programs.
* wilson callan, 1997
\******************************************************************************/

/**************************************************************************\
*  toolbar.c -- module for the "toolbar" on top of the main window.
*   Includes the window procedure and an initialization routine.
\**************************************************************************/

#include "main.h"

/* for the initial positioning of the buttons within the toolbar. */

#define SPACEBUTTON 1
//#define SPACEBUTTON 8
#define CXBUTTON ((GetSystemMetrics (SM_CXFULLSCREEN)) /22 -2*SPACEBUTTON)
//#define CXBUTTON ((GetSystemMetrics (SM_CXFULLSCREEN)) /5 -2*SPACEBUTTON)
#define BUTTONTOP    TOOLBARHEIGHT/8
#define BUTTONHEIGHT TOOLBARHEIGHT*3/4
#define BUTTONLEFT(x) ((2*x+1)*SPACEBUTTON + x*CXBUTTON)

#define BORDER     2

extern HWND ghwndMainApp;

HWND InitTB (HWND hwndParent)
{
	HWND	hwndTB;

	hwndTB = CreateWindow(
	    TEXT("ToolBar"),
	    NULL,
	    WS_CHILD | WS_CLIPSIBLINGS | WS_VISIBLE,
	    0,0,
	    GetSystemMetrics (SM_CXFULLSCREEN),
	    TOOLBARHEIGHT,
	    hwndParent, NULL, ghInst, NULL);
	
	return hwndTB;
}

/**************************************************************************\
*
*  function:  ToolBarWndProc
*
*  input parameters:  normal window procedure parameters.
*
*  global variables:
*   ghwndMainApp - parent of the toolbar.
*
* When the window is created, create the various buttons.  When those
*  buttons send WM_COMMAND messages later, send the messages back to 
*  ghwndMainApp.
*
\**************************************************************************/
LRESULT CALLBACK ToolBarWndProc(
HWND hwnd, 
UINT message, 
WPARAM wParam, 
LPARAM lParam)
{
static HWND  hwndButton;
	BYTE i;
	CHAR szTemp[3];

  switch (message) 
  {
    /**********************************************************************\
    *  WM_CREATE
    *
    * Create the various buttons which are on the toolbar.  Once the 
	*  buttons
    *  are created, set the window ID so that the WM_COMMANDS may be
    *  distinguished.
    \**********************************************************************/

    case WM_CREATE: {
      hwndButton = CreateWindow(
        TEXT("BUTTON"),TEXT("A"),
        WS_CHILD | WS_VISIBLE,
        BUTTONLEFT(0),BUTTONTOP, CXBUTTON, BUTTONHEIGHT,
        hwnd, NULL, ghInst, NULL);
      SetWindowLong (hwndButton, GWL_ID, TBID_ACE);

	  for (i = DEUCE; i < JACK; i++)
	  {
		  sprintf (szTemp, "%d", i+1);

		  hwndButton = CreateWindow(
			TEXT("BUTTON"), szTemp,
			WS_CHILD | WS_VISIBLE,
			BUTTONLEFT(i), BUTTONTOP, CXBUTTON, BUTTONHEIGHT,
			hwnd, NULL, ghInst, NULL);
		  SetWindowLong (hwndButton, GWL_ID, TBID_ACE+i);
	  }

      hwndButton = CreateWindow(
        TEXT("BUTTON"),TEXT("J"),
        WS_CHILD | WS_VISIBLE ,
        BUTTONLEFT(10),BUTTONTOP, CXBUTTON, BUTTONHEIGHT,
        hwnd, NULL, ghInst, NULL);
      SetWindowLong (hwndButton, GWL_ID, TBID_JACK);

      hwndButton = CreateWindow(
        TEXT("BUTTON"),TEXT("Q"),
        WS_CHILD | WS_VISIBLE ,
        BUTTONLEFT(11),BUTTONTOP, CXBUTTON, BUTTONHEIGHT,
        hwnd, NULL, ghInst, NULL);
      SetWindowLong (hwndButton, GWL_ID, TBID_QUEEN);

      hwndButton = CreateWindow(
        TEXT("BUTTON"),TEXT("K"),
        WS_CHILD | WS_VISIBLE ,
        BUTTONLEFT(12),BUTTONTOP, CXBUTTON, BUTTONHEIGHT,
        hwnd, NULL, ghInst, NULL);
      SetWindowLong (hwndButton, GWL_ID, TBID_KING);
    } 
	break;

    /**********************************************************************\
    *  WM_COMMAND
    *
    * Send the command messages back to ghwndMainApp.
    \**********************************************************************/
    case WM_COMMAND:
        PostMessage (ghwndMainApp, message, wParam, lParam);
		SetFocus (ghwndMainApp);
    break;

    /**********************************************************************\
    *  WM_PAINT
    *
    * Paint two rectangular strips, one on top, one on bottom.
    \**********************************************************************/
    case WM_PAINT : {
      PAINTSTRUCT ps;
      RECT rect;
      HDC hdc;

      hdc = BeginPaint(hwnd, &ps);
      GetClientRect (hwnd, &rect);
      rect.right --;
      rect.bottom --;

      SelectObject (hdc, GetStockObject (BLACK_PEN));
      MoveToEx (hdc, rect.right, rect.top, NULL);
      LineTo (hdc, rect.right, rect.bottom);
      LineTo (hdc, rect.left, rect.bottom);
      SelectObject (hdc, GetStockObject (WHITE_PEN));
      LineTo (hdc, rect.left, rect.top);
      LineTo (hdc, rect.right, rect.top);

      EndPaint (hwnd, &ps);
    } break;

	case WM_ACTIVATE:
		break;

  } /* end switch */

  return (DefWindowProc(hwnd, message, wParam, lParam));
}
