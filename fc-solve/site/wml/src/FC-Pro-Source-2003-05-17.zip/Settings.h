// wilson callan, 1998

extern BOOL gbMessages;
extern BOOL gbLogging;
extern BOOL gbFastUndo;
extern BOOL gbProAids ;
extern BOOL gbSupermove;
extern INT gnAnimation;
extern INT NumFcs;
extern INT gnUserUndoType;
extern INT gnMaxRandGame;
extern BOOL gbStatus;
extern BOOL gbTool;
extern INT SolrSel ;

#define ANIMATE_ALL			(0)
#define ANIMATE_NOTSOLUTION	(1)			
#define ANIMATE_FLOURISH	(2)
#define ANIMATE_NONE		(3)

#define UNDO_UNLIMITED	(0)
#define UNDO_LIMITED	(1)
#define UNDO_NONE		(2)

#define RAND_32THOU		(0)
#define RAND_1MILL		(1)	// highest a person can recognize
#define RAND_4BILL		(2)



