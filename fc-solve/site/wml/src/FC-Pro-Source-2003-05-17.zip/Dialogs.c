/******************************************************************************\
* wilson callan, copyright 1997
\******************************************************************************/

#include "main.h"
#include "custom.h"
#include "fcsolve.h"
#include "settings.h"
#include "freecell.h"

INT nSUserIndex[NUMSTATUSERS] ;
//extern BOOL gb8fcps ;
extern BOOL gbCustClip ;
#ifdef SOLVEVAL
extern char szPatMode[] ;
extern char cPatMode ;
#endif
/*****************************************************************************\
* MyDialogBox
*
* Puts up the specified dialog.
*
* Arguments:
*   INT idDlg          - The resource id of the dialog to display.
*   DLGPROC pfnDlgProc - The dialog proc to use.
*
* Returns:
*   The return value from DialogBox (whatever the dialog proc passes
*   to EndDialog).
\*****************************************************************************/
BOOL MyDialogBox (HWND hwnd, INT idDlg, DLGPROC pfnDlgProc)
{
    return DialogBox (ghInst, MAKEINTRESOURCE(idDlg), hwnd, pfnDlgProc);
}

/*****************************************************************************\
*
*   Dialog proc for the Help boxes.
*
\*****************************************************************************/
BOOL CALLBACK HelpDlgProc (
	HWND hwnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam)
{
    switch (msg) 
	{
        case WM_INITDIALOG:
            return TRUE;

        case WM_COMMAND:
            EndDialog(hwnd, IDOK);
            break;
    }

    return FALSE;
}

BOOL CALLBACK LoadSolutionDlgProc (
	HWND hwnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam)
{
	OPENFILENAME ofn;
	DWORD rtn;
	CHAR  szTemp[32];

    switch (msg) 
	{
        case WM_INITDIALOG:
            SetDlgItemText (hwnd, IDC_LOADSOLUTION_FILENAME, gszLoadFile);
            SetDlgItemInt (hwnd, IDC_LOADSOLUTION_MOVES, (UINT) -1, TRUE);
            return TRUE;

        case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK:
					gnLoadMoves = GetDlgItemInt (hwnd, 
						IDC_LOADSOLUTION_MOVES, &gnLoadMoves, TRUE);
					GetDlgItemText (hwnd,
						IDC_LOADSOLUTION_FILENAME, gszLoadFile, 
						MAXSTRING);
					EndDialog(hwnd, TRUE);
					return TRUE;

				case IDCANCEL:
					EndDialog(hwnd, FALSE);
					return TRUE;

				case IDC_LOADSOLUTION_BROWSE:
					ofn.lStructSize			= sizeof(OPENFILENAME); 
					ofn.hwndOwner			= hwnd; 
					ofn.hInstance			= ghInst; 
					ofn.lpstrFilter			= (LPSTR) &gFilters;  
					ofn.lpstrCustomFilter	= NULL; 
					ofn.nFilterIndex		= 0; 
					ofn.lpstrFile			= gszLoadFile; 
					ofn.nMaxFile			= MAXSTRING;
					ofn.lpstrFileTitle		= NULL; 
					ofn.lpstrInitialDir		= NULL; 
					ofn.lpstrTitle			= "Load"; 
					ofn.Flags				= OFN_HIDEREADONLY | OFN_EXPLORER;
					ofn.lpstrDefExt			= NULL; 

					if (!GetOpenFileName (&ofn))
					{
						// examine results

						if (rtn = CommDlgExtendedError())
						{
							// error wasnt just because user hit cancel!

							// 9 == CDERR_MEMALLOCFAILURE

							sprintf (szTemp, "ERROR_GETOPENFILENAME (0x%04x).", rtn);
							Message (hwnd, 0, szTemp);
						}

						return TRUE;
					}
		            SetDlgItemText (hwnd, IDC_LOADSOLUTION_FILENAME, 
										gszLoadFile);
					return TRUE;
			}
			break;
    }

    return FALSE;
}

BOOL CALLBACK CustomGameDlgProc (
	HWND hwnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam)
{
	OPENFILENAME ofn;
	DWORD rtn;
	CHAR  szTemp[32];

    switch (msg) 
	{
        case WM_INITDIALOG:
            SetDlgItemText (hwnd, IDC_CUSTOMGAME_FILENAME, gszCustomGameFile);
            return TRUE;

        case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK:
					GetDlgItemText (hwnd,
						IDC_CUSTOMGAME_FILENAME, gszCustomGameFile, 
						MAXSTRING);
					EndDialog(hwnd, TRUE);
					return TRUE;

				case IDCANCEL:
					EndDialog(hwnd, FALSE);
					return TRUE;

				case IDC_CUSTOMGAME_BROWSE:
					ofn.lStructSize			= sizeof(OPENFILENAME); 
					ofn.hwndOwner			= hwnd; 
					ofn.hInstance			= ghInst; 
					ofn.lpstrFilter			= (LPSTR) &gFilters;  
					ofn.lpstrCustomFilter	= NULL; 
					ofn.nFilterIndex		= 0; 
					ofn.lpstrFile			= gszCustomGameFile; 
					ofn.nMaxFile			= MAXSTRING;
					ofn.lpstrFileTitle		= NULL; 
					ofn.lpstrInitialDir		= NULL; 
					ofn.lpstrTitle			= "Custom Game"; 
					ofn.Flags				= OFN_HIDEREADONLY | OFN_EXPLORER;
					ofn.lpstrDefExt			= NULL; 

					if (!GetOpenFileName (&ofn))
					{
						// examine results

						if (rtn = CommDlgExtendedError())
						{
							// error wasnt just because user hit cancel!

							// 9 == CDERR_MEMALLOCFAILURE

							sprintf (szTemp, "ERROR_GETOPENFILENAME (0x%04x).", rtn);
							Message (hwnd, 0, szTemp);
						}

						return TRUE;
					}
		            SetDlgItemText (hwnd, IDC_CUSTOMGAME_FILENAME, 
										gszCustomGameFile);
					return TRUE;

				case IDC_CUSTCLIP:
/*
					if (!(0penClipboard())
			            SetDlgItemText (hwnd, IDC_CUSTOMGAME_FILENAME, "No text data in clipboard") ;
					else
,*/
					if (!gbCustClip)
					{
						if (IsClipboardFormatAvailable(CF_TEXT))
						{
							SetDlgItemText (hwnd, IDC_CUSTOMGAME_FILENAME, "Click 'OK' to load from clipboard") ;
							gbCustClip = TRUE ;
						}
						else
							SetDlgItemText (hwnd, IDC_CUSTOMGAME_FILENAME, "No text data in clipboard") ;
					}
					else
					{
						SetDlgItemText (hwnd, IDC_CUSTOMGAME_FILENAME, " ") ;
						gbCustClip = FALSE ;
					}
					return TRUE;
			}
			break;
    }

    return FALSE;
}

BOOL CALLBACK CardSizeDlgProc (
	HWND hwnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam)
{
    switch (msg) 
	{
        case WM_INITDIALOG:
            SetDlgItemInt (hwnd, IDC_CARDSIZE_NWIDTH, gnNorWidth, FALSE);
            SetDlgItemInt (hwnd, IDC_CARDSIZE_NHEIGHT, gnNorHeight, FALSE);
            SetDlgItemInt (hwnd, IDC_CARDSIZE_RWIDTH, gnRedWidth, FALSE);
            SetDlgItemInt (hwnd, IDC_CARDSIZE_RHEIGHT, gnRedHeight, FALSE);
            return TRUE;

        case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK:
					gnNorWidth = GetDlgItemInt (hwnd, 
						IDC_CARDSIZE_NWIDTH, &gnNorWidth, FALSE);
					gnNorHeight = GetDlgItemInt (hwnd, 
						IDC_CARDSIZE_NHEIGHT, &gnNorHeight, FALSE);
					gnRedWidth = GetDlgItemInt (hwnd, 
						IDC_CARDSIZE_RWIDTH, &gnRedWidth, FALSE);
					gnRedHeight = GetDlgItemInt (hwnd, 
						IDC_CARDSIZE_RHEIGHT, &gnRedHeight, FALSE);
					EndDialog(hwnd, TRUE);
					return TRUE;

				case IDC_CARDSIZE_NRESET:
		            SetDlgItemInt (hwnd, IDC_CARDSIZE_NWIDTH, gnDefWidth, FALSE);
				    SetDlgItemInt (hwnd, IDC_CARDSIZE_NHEIGHT, gnDefHeight, FALSE);
					return TRUE;

				case IDC_CARDSIZE_RRESET:
					SetDlgItemInt (hwnd, IDC_CARDSIZE_RWIDTH, gnDefWidth, FALSE);
					SetDlgItemInt (hwnd, IDC_CARDSIZE_RHEIGHT, gnDefHeight, FALSE);
					return TRUE;

				case IDCANCEL:
					EndDialog(hwnd, TRUE);
					return TRUE;
			}
			break;
    }

    return FALSE;
}

BOOL CALLBACK WindowColorsDlgProc (
	HWND hwnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam)
{
    switch (msg) 
	{
        case WM_INITDIALOG:
            SetDlgItemInt (hwnd, IDC_WINDOWCOLOR_FCRED, gnFCRed, 
							FALSE);
            SetDlgItemInt (hwnd, IDC_WINDOWCOLOR_FCGREEN, gnFCGreen, 
							FALSE);
            SetDlgItemInt (hwnd, IDC_WINDOWCOLOR_FCBLUE, gnFCBlue, 
							FALSE);
            SetDlgItemInt (hwnd, IDC_WINDOWCOLOR_BGRED, gnBGRed, 
							FALSE);
            SetDlgItemInt (hwnd, IDC_WINDOWCOLOR_BGGREEN, gnBGGreen, 
							FALSE);
            SetDlgItemInt (hwnd, IDC_WINDOWCOLOR_BGBLUE, gnBGBlue, 
							FALSE);
            return TRUE;

        case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK:
					gnFCRed = GetDlgItemInt (hwnd, 
  						IDC_WINDOWCOLOR_FCRED, &gnFCRed, FALSE);
					gnFCGreen = GetDlgItemInt (hwnd, 
  						IDC_WINDOWCOLOR_FCGREEN, &gnFCGreen, FALSE);
					gnFCBlue = GetDlgItemInt (hwnd, 
  						IDC_WINDOWCOLOR_FCBLUE, &gnFCBlue, FALSE);
					gnBGRed = GetDlgItemInt (hwnd, 
  						IDC_WINDOWCOLOR_BGRED, &gnBGRed, FALSE);
					gnBGGreen = GetDlgItemInt (hwnd, 
  						IDC_WINDOWCOLOR_BGGREEN, &gnBGGreen, FALSE);
					gnBGBlue = GetDlgItemInt (hwnd, 
  						IDC_WINDOWCOLOR_BGBLUE, &gnBGBlue, FALSE);
					EndDialog(hwnd, TRUE);
					return TRUE;

				case IDC_FC_RESET:
		            SetDlgItemInt (hwnd, IDC_WINDOWCOLOR_FCRED, 
									FCRED, FALSE);
		            SetDlgItemInt (hwnd, IDC_WINDOWCOLOR_FCGREEN, 
									FCGREEN, FALSE);
		            SetDlgItemInt (hwnd, IDC_WINDOWCOLOR_FCBLUE, 
									FCBLUE, FALSE);
					return TRUE;

				case IDC_BG_RESET:
		            SetDlgItemInt (hwnd, IDC_WINDOWCOLOR_BGRED, 
									BGRED, FALSE);
		            SetDlgItemInt (hwnd, IDC_WINDOWCOLOR_BGGREEN, 
									BGGREEN, FALSE);
		            SetDlgItemInt (hwnd, IDC_WINDOWCOLOR_BGBLUE, 
									BGBLUE, FALSE);
					return TRUE;

				case IDCANCEL:
					EndDialog(hwnd, TRUE);
					return TRUE;
			}
			break;
    }

    return FALSE;
}

BOOL CALLBACK SelectGameDlgProc (
	HWND hwnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam)
{
char szGameNo[12] ;
    switch (msg) 
	{
        case WM_INITDIALOG:
			SendMessage (GetDlgItem (hwnd, IDC_SELECTGAME_GAMENUMBER), 
							EM_LIMITTEXT, (WORD)10, 0L) ;
			SetDlgItemText(hwnd, IDC_SELECTGAME_GAMENUMBER, FmtGameNo(gnGameNumber));
            return TRUE;

        case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK:
					GetDlgItemText (hwnd, IDC_SELECTGAME_GAMENUMBER, szGameNo, 11) ;
					gnGameNumber = CvGameNo((LPSTR)szGameNo) ;
					EndDialog(hwnd, TRUE);
					return TRUE;

				case IDCANCEL:
					EndDialog(hwnd, FALSE);
					return TRUE;
			}
			break;
    }

    return FALSE;
}

BOOL CALLBACK SolveDlgProc (
	HWND hwnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam)
{
char szGameNo[12] ;
    switch (msg) 
	{
        case WM_INITDIALOG:
	     CheckRadioButton (hwnd, IDC_SOLVE1, IDC_SOLVE4, 
			IDC_SOLVE1 + gnSolve);
		 if (gnSolve == SOLVE_LIST)
			 gnFirstGame = gnLastGame = 1 ;  //Clear out last values if previously list mode
		 CheckRadioButton (hwnd, IDC_SOLVE_ALLGAMES, IDC_SOLVE_DIAG, 
			IDC_SOLVE_ALLGAMES + SolrSel) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_START), 
	 		EM_LIMITTEXT, (WORD) 10, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_END), 
	 		EM_LIMITTEXT, (WORD) 10, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_MAX), 
	 		EM_LIMITTEXT, (WORD) 6, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_MAXT), 
	 		EM_LIMITTEXT, (WORD) 3, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_MAXB), 
	 		EM_LIMITTEXT, (WORD) 4, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_MAXTB), 
	 		EM_LIMITTEXT, (WORD) 3, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_PRESORT), 
	 		EM_LIMITTEXT, (WORD) 2, 0L) ;
            SetDlgItemText (hwnd, IDC_SOLVE_START, FmtGameNo(gnFirstGame));
            SetDlgItemText (hwnd, IDC_SOLVE_END, FmtGameNo(gnLastGame));
            SetDlgItemInt (hwnd, IDC_SOLVE_MAX, gnMaxHands, FALSE);
            SetDlgItemInt (hwnd, IDC_SOLVE_MAXT, gnMaxTime, FALSE);
            SetDlgItemInt (hwnd, IDC_SOLVE_MAXB, gnMaxSpace, FALSE);
            SetDlgItemInt (hwnd, IDC_SOLVE_MAXTB, gnMaxTimeB, FALSE);
            SetDlgItemText (hwnd, IDC_SOLVE_PRESORT, PresortC);
            return TRUE;

        case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK:
				{
					INT i;
					for (i = 0; i < 4; i++)
					{
						if (IsDlgButtonChecked (hwnd, IDC_SOLVE1 + i)
							== BST_CHECKED)
						{
							gnSolve = i;
							break;
						}
					}
					if (gnSolve == SOLVE_RANGE)
					{
						// range
//						gnFirstGame = GetDlgItemInt (hwnd, 
//							IDC_SOLVE_START, &gnFirstGame, FALSE);
//						gnLastGame = GetDlgItemInt (hwnd, 
//							IDC_SOLVE_END, &gnLastGame, FALSE);
						GetDlgItemText(hwnd, IDC_SOLVE_START, szGameNo, 11) ;
						gnFirstGame = CvGameNo(szGameNo) ;
						GetDlgItemText(hwnd, IDC_SOLVE_END, szGameNo, 11) ;
						gnLastGame = CvGameNo(szGameNo) ;
						if (gnFirstGame > gnLastGame)
							gnLastGame = gnFirstGame;
					}
					else
					{
						gnFirstGame = gnLastGame = 1;
					}
					gnMaxHands = GetDlgItemInt (hwnd, 
										IDC_SOLVE_MAX, &gnMaxHands, FALSE);
					gnMaxTime = GetDlgItemInt (hwnd, 
										IDC_SOLVE_MAXT, &gnMaxTime, FALSE);
					gnMaxSpace = GetDlgItemInt (hwnd, 
										IDC_SOLVE_MAXB, &gnMaxSpace, FALSE);
					gnMaxTimeB = GetDlgItemInt (hwnd, 
										IDC_SOLVE_MAXTB, &gnMaxTimeB, FALSE);
//					if (gnMaxTime)
//						gnMaxHands = 0 ;
					lstrcpy(PresortC, "  ") ;
					GetDlgItemText(hwnd, IDC_SOLVE_PRESORT, PresortC, 3) ;
					strupr(PresortC) ;
					SolrSel = 0 ;
					if (IsDlgButtonChecked (hwnd, IDC_SOLVE_SELECTIVE))
						SolrSel = 1 ;
					if (IsDlgButtonChecked (hwnd, IDC_SOLVE_DIAG))
						SolrSel = 2 ;
					EndDialog(hwnd, TRUE);
					return TRUE;
				}

				case IDCANCEL:
					EndDialog(hwnd, FALSE);
					return TRUE;
			}
			break;
    }

    return FALSE;
}

BOOL CALLBACK Solve2DlgProc (
	HWND hwnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam)
{
char szGameNo[12] ;
//char szTemp[60] ;
    switch (msg) 
	{
        case WM_INITDIALOG:
	     CheckRadioButton (hwnd, IDC_SOLVE1, IDC_SOLVE4, 
			IDC_SOLVE1 + gnSolve);
		 if (gnSolve == SOLVE_LIST)
			 gnFirstGame = gnLastGame = 1 ;  //Clear out last values if previously list mode
		 CheckRadioButton (hwnd, IDC_SOLVE_ALLGAMES, IDC_SOLVE_DIAG, 
			IDC_SOLVE_ALLGAMES + SolrSel) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_START), 
	 		EM_LIMITTEXT, (WORD) 10, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_END), 
	 		EM_LIMITTEXT, (WORD) 10, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_MAX2), 
	 		EM_LIMITTEXT, (WORD) 6, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_MAXT2), 
	 		EM_LIMITTEXT, (WORD) 3, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_PRESORT2), 
//	 		EM_LIMITTEXT, (WORD) 2, 0L) ;
	 		EM_LIMITTEXT, (WORD) 3, 0L) ;
            SetDlgItemText (hwnd, IDC_SOLVE_START, FmtGameNo(gnFirstGame));
            SetDlgItemText (hwnd, IDC_SOLVE_END, FmtGameNo(gnLastGame));
            SetDlgItemInt (hwnd, IDC_SOLVE_MAX2, gnMaxHands, FALSE);
            SetDlgItemInt (hwnd, IDC_SOLVE_MAXT2, gnMaxTime, FALSE);
            SetDlgItemText (hwnd, IDC_SOLVE_PRESORT2, PresortC);
            return TRUE;

        case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK:
				{
					INT i;
					for (i = 0; i < 4; i++)
					{
						if (IsDlgButtonChecked (hwnd, IDC_SOLVE1 + i)
							== BST_CHECKED)
						{
							gnSolve = i;
							break;
						}
					}
					if (gnSolve == SOLVE_RANGE)
					{
						GetDlgItemText(hwnd, IDC_SOLVE_START, szGameNo, 11) ;
						gnFirstGame = CvGameNo(szGameNo) ;
						GetDlgItemText(hwnd, IDC_SOLVE_END, szGameNo, 11) ;
						gnLastGame = CvGameNo(szGameNo) ;
						if (gnFirstGame > gnLastGame)
							gnLastGame = gnFirstGame;
					}
					else
					{
						gnFirstGame = gnLastGame = 1;
					}
					gnMaxHands = GetDlgItemInt (hwnd, 
										IDC_SOLVE_MAX2, &gnMaxHands, FALSE);
					gnMaxTime = GetDlgItemInt (hwnd, 
										IDC_SOLVE_MAXT2, &gnMaxTime, FALSE);
//					lstrcpy(PresortC, "  ") ;
					lstrcpy(PresortC, "   ") ;
//					GetDlgItemText(hwnd, IDC_SOLVE_PRESORT2, PresortC, 3) ;
					GetDlgItemText(hwnd, IDC_SOLVE_PRESORT2, PresortC, 4) ;
					strupr(PresortC) ;
					SolrSel = 0 ;
					if (IsDlgButtonChecked (hwnd, IDC_SOLVE_SELECTIVE))
						SolrSel = 1 ;
					if (IsDlgButtonChecked (hwnd, IDC_SOLVE_DIAG))
						SolrSel = 2 ;
//				    SolrSel = 0 ;
					EndDialog(hwnd, TRUE);
					return TRUE;
				}

				case IDCANCEL:
					EndDialog(hwnd, FALSE);
					return TRUE;
			}
			break;
    }

    return FALSE;
}

#ifdef SOLVEVAL
BOOL CALLBACK Solve3DlgProc (
	HWND hwnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam)
{
char szGameNo[12] ;
//char szTemp[60] ;
    switch (msg) 
	{
        case WM_INITDIALOG:
	     CheckRadioButton (hwnd, IDC_SOLVE1, IDC_SOLVE4, 
			IDC_SOLVE1 + gnSolve);
		 if (gnSolve == SOLVE_LIST)
			 gnFirstGame = gnLastGame = 1 ;  //Clear out last values if previously list mode
		 CheckRadioButton (hwnd, IDC_SOLVE_ALLGAMES, IDC_SOLVE_DIAG, 
			IDC_SOLVE_ALLGAMES + SolrSel) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_START), 
	 		EM_LIMITTEXT, (WORD) 10, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_END), 
	 		EM_LIMITTEXT, (WORD) 10, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_MAX3), 
	 		EM_LIMITTEXT, (WORD) 3, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_MAXT3), 
	 		EM_LIMITTEXT, (WORD) 3, 0L) ;
	    SendMessage (GetDlgItem (hwnd, IDC_SOLVE_PSCUTOFF), 
	 		EM_LIMITTEXT, (WORD) 2, 0L) ;
	        SetDlgItemText (hwnd, IDC_SOLVE_START, FmtGameNo(gnFirstGame));
            SetDlgItemText (hwnd, IDC_SOLVE_END, FmtGameNo(gnLastGame));
            SetDlgItemInt (hwnd, IDC_SOLVE_MAX3, gnMaxHands, FALSE);
            SetDlgItemInt (hwnd, IDC_SOLVE_MAXT3, gnMaxTime, FALSE);
//			gnCutoff = 2 ;
//			SetDlgItemInt (hwnd, IDC_SOLVE_PSCUTOFF, gnCutoff, FALSE) ;
			szPatMode[0] = cPatMode ;
            SetDlgItemText (hwnd, IDC_SOLVE_PSCUTOFF, szPatMode);
            return TRUE;

        case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK3:
				{
					INT i;
					for (i = 0; i < 4; i++)
					{
						if (IsDlgButtonChecked (hwnd, IDC_SOLVE1 + i)
							== BST_CHECKED)
						{
							gnSolve = i;
							break;
						}
					}
					if (gnSolve == SOLVE_RANGE)
					{
						GetDlgItemText(hwnd, IDC_SOLVE_START, szGameNo, 11) ;
						gnFirstGame = CvGameNo(szGameNo) ;
						GetDlgItemText(hwnd, IDC_SOLVE_END, szGameNo, 11) ;
						gnLastGame = CvGameNo(szGameNo) ;
						if (gnFirstGame > gnLastGame)
							gnLastGame = gnFirstGame;
					}
					else
					{
						gnFirstGame = gnLastGame = 1;
					}
					gnMaxHands = GetDlgItemInt (hwnd, 
										IDC_SOLVE_MAX3, &gnMaxHands, FALSE);
					gnMaxTime = GetDlgItemInt (hwnd, 
										IDC_SOLVE_MAXT3, &gnMaxTime, FALSE);
//					gb8fcps = FALSE ;
//					if (GetDlgItemInt (hwnd,IDC_SOLVE_PSCUTOFF, &gnCutoff, FALSE) != 8)
//					gnCutoff = GetDlgItemInt (hwnd, 
//										IDC_SOLVE_PSCUTOFF, &gnCutoff, FALSE);
					GetDlgItemText(hwnd, IDC_SOLVE_PSCUTOFF, szPatMode, 3) ;
					gnCutoff = atoi(szPatMode + 1) ;
//					else
//						gb8fcps = TRUE ;
					SolrSel = 0 ;
					if (IsDlgButtonChecked (hwnd, IDC_SOLVE_SELECTIVE))
						SolrSel = 1 ;
					if (IsDlgButtonChecked (hwnd, IDC_SOLVE_DIAG))
						SolrSel = 2 ;
					EndDialog(hwnd, TRUE);
					return TRUE;
				}

				case IDCANCEL:
					EndDialog(hwnd, FALSE);
					return TRUE;
			}
			break;
    }

    return FALSE;
}
#endif
VOID SetUserIndexes(HWND hwnd)
{
INT i ;
	for (i = 0 ; i < NUMSTATUSERS ; i++)
		nSUserIndex[SendMessage(GetDlgItem (hwnd, IDC_STATS_USER), CB_FINDSTRING, (WORD)-1,
			(LONG)(LPSTR)StatsMU.Stats[i].UserName)] = i ;
	return ;
}															  

VOID PostStatData(HWND hwnd)
{
	CHAR  szTemp[8];
	CHAR  szWins[] = "wins" ;
	CHAR  szWin[] = "win" ;
	CHAR  szLosses[] = "losses" ;
	CHAR  szLoss[] = "loss" ;
		if (StatsMU.Stats[SCUser].CurrW || StatsMU.Stats[SCUser].CurrL)
			sprintf(szTemp, "%.2f%%", 100 * (float)StatsMU.Stats[SCUser].CurrW/
				((float)StatsMU.Stats[SCUser].CurrW + (float)StatsMU.Stats[SCUser].CurrL)) ;
		else
			lstrcpy(szTemp, "----") ;
		SendMessage (GetDlgItem (hwnd, IDC_STATS_CURRPC), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)szTemp) ;
	    SendMessage (GetDlgItem (hwnd, IDC_STATS_CURRW), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)itoa(StatsMU.Stats[SCUser].CurrW, szTemp, 10)) ;
	    SendMessage (GetDlgItem (hwnd, IDC_STATS_CURRL), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)itoa(StatsMU.Stats[SCUser].CurrL, szTemp, 10)) ;
		if (StatsMU.Stats[SCUser].TotalW || StatsMU.Stats[SCUser].TotalL)
			sprintf(szTemp, "%.2f%%", 100 * (float)StatsMU.Stats[SCUser].TotalW/
				((float)StatsMU.Stats[SCUser].TotalW + (float)StatsMU.Stats[SCUser].TotalL)) ;
		else
			lstrcpy(szTemp, "----") ;
		SendMessage (GetDlgItem (hwnd, IDC_STATS_TOTALPC), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)szTemp) ;
	    SendMessage (GetDlgItem (hwnd, IDC_STATS_TOTALW), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)itoa(StatsMU.Stats[SCUser].TotalW, szTemp, 10)) ;
	    SendMessage (GetDlgItem (hwnd, IDC_STATS_TOTALL), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)itoa(StatsMU.Stats[SCUser].TotalL, szTemp, 10)) ;
	    SendMessage (GetDlgItem (hwnd, IDC_STATS_STREAKSW), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)itoa(StatsMU.Stats[SCUser].StreaksW, szTemp, 10)) ;
	    SendMessage (GetDlgItem (hwnd, IDC_STATS_STREAKSL), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)itoa(StatsMU.Stats[SCUser].StreaksL, szTemp, 10)) ;
	    SendMessage (GetDlgItem (hwnd, IDC_STATS_STREAKSC), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)itoa(abs(StatsMU.Stats[SCUser].StreaksC), szTemp, 10)) ;
		if (StatsMU.Stats[SCUser].StreaksC > 1)
		  SendMessage (GetDlgItem (hwnd, IDC_STATS_STREAKSWL), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)szWins) ;
		if (StatsMU.Stats[SCUser].StreaksC < -1)
		  SendMessage (GetDlgItem (hwnd, IDC_STATS_STREAKSWL), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)szLosses) ;
		if (StatsMU.Stats[SCUser].StreaksC == 1)
		  SendMessage (GetDlgItem (hwnd, IDC_STATS_STREAKSWL), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)szWin) ;
		if (StatsMU.Stats[SCUser].StreaksC == -1)
		  SendMessage (GetDlgItem (hwnd, IDC_STATS_STREAKSWL), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)szLoss) ;
	    SendMessage (GetDlgItem (hwnd, IDC_STATS_USER), 
	 		WM_SETTEXT, (WORD) 0, (LONG)(LPSTR)StatsMU.Stats[SCUser].UserName) ;
		return;
}

BOOL CALLBACK StatisticsDlgProc (
	HWND hwnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam)
{
	CHAR  szTemp[8];
	CHAR  szWins[] = "wins" ;
	CHAR  szWin[] = "win" ;
	CHAR  szLosses[] = "losses" ;
	CHAR  szLoss[] = "loss" ;
	CHAR  szSetNU[] = "Select New User" ;
	RECT lrect ;
	UINT nIndexS ;
	INT i ;
	switch (msg) 
	{
        case WM_INITDIALOG:
	    CheckRadioButton (hwnd, IDC_STATS_ENABLE, IDC_STATS_DISABLE, 
								IDC_STATS_DISABLE - (INT)StatsMU.StatEnbl);
		CheckDlgButton (hwnd, IDC_STAT_ALERT, !StatsMU.StatAlert);
		CheckDlgButton (hwnd, IDC_STAT_QUIT_CONFIRM, !StatsMU.StatQuitConfirm);
	    SendMessage (GetDlgItem (hwnd, IDC_STATS_USER), 
		 					EM_LIMITTEXT, (WORD) MAX_STATUSERNAME + 1, 0L);
	    SendMessage (GetDlgItem (hwnd, IDC_STATS_USER), CB_RESETCONTENT, 0, 0L);
		PostStatData(hwnd) ;
		for (i = 0; i < NUMSTATUSERS ; i++)
		{
			if (StatsMU.Stats[i].UserName[0] != ' ')
				SendMessage (GetDlgItem (hwnd, IDC_STATS_USER), 
		 			CB_ADDSTRING, 0, (LONG)(LPSTR)StatsMU.Stats[i].UserName);
		}
		SetUserIndexes(hwnd) ;
		SendMessage (GetDlgItem (hwnd, IDC_STATS_USER), CB_SELECTSTRING, 0,
			(LONG)(LPSTR)StatsMU.Stats[StatsMU.CurStatUser].UserName);
		GetWindowRect(GetDlgItem (hwnd, IDC_STATS_USER), &lrect) ;
		SetWindowPos (GetDlgItem (hwnd, IDC_STATS_USER), 
		 	0, 0, 0, lrect.right - lrect.left, 180, SWP_NOMOVE | SWP_NOZORDER);
		return TRUE ;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{

				case IDC_STATS_CLEAR:
					if (Message (hwnd, MB_ICONQUESTION | MB_YESNO |	MB_DEFBUTTON2,
						"Are you sure you want\nto delete all statistics\nfor this user?")
							!= IDYES)
						return FALSE ;
					StatsMU.Stats[SCUser].CurrW = StatsMU.Stats[SCUser].CurrL = StatsMU.Stats[SCUser].TotalW = StatsMU.Stats[SCUser].TotalL =
					StatsMU.Stats[SCUser].StreaksW = StatsMU.Stats[SCUser].StreaksL = StatsMU.Stats[SCUser].StreaksC = 0 ;
					PostStatData(hwnd) ;
					return TRUE;
			
				case IDC_STATS_USER:
					switch (HIWORD(wParam))
					{
					case CBN_SELCHANGE:
						nIndexS = (WORD) SendMessage(GetDlgItem (hwnd, IDC_STATS_USER),
							CB_GETCURSEL, 0, 0L) ;
//						if ((nIndexS > (NUMSTATUSERS - 1) || nIndexS > -1))
						if (nIndexS > (NUMSTATUSERS - 1))
							return FALSE ;
						SCUser = StatsMU.CurStatUser = nSUserIndex[nIndexS] ;
						PostStatData(hwnd) ;
						return FALSE ;

					}
					break ;

					case IDC_STATS_USER_DELETE:
					if (StatsMU.Stats[SCUser].TotalW || StatsMU.Stats[SCUser].TotalL || 
						StatsMU.Stats[SCUser].StreaksW || StatsMU.Stats[SCUser].StreaksL)
					{
						Message(hwnd, MB_ICONSTOP,
		"To delete a user, you must\nfirst use 'CLEAR' to delete\nthat user's statistics.") ;
						return FALSE ;
					}
					nIndexS = (WORD) SendMessage(GetDlgItem (hwnd, IDC_STATS_USER),
						CB_GETCURSEL, 0, 0L) ;
//					if ((nIndexS > (NUMSTATUSERS - 1) || nIndexS > -1))
					if (nIndexS > (NUMSTATUSERS - 1))
							return FALSE ;
					SendMessage (GetDlgItem (hwnd, IDC_STATS_USER), 
		 						CB_DELETESTRING, nIndexS, 0L);
					StatsMU.Stats[nSUserIndex[nIndexS]].UserName[0] = ' ' ;
					SetUserIndexes(hwnd) ;
	//				DSCUser = 0 ;
					SendMessage (GetDlgItem (hwnd, IDC_STATS_USER), 
		 						CB_SHOWDROPDOWN, (WORD)TRUE, 0L);
					SendMessage (GetDlgItem (hwnd, IDC_STATS_USER), 
		 						WM_SETTEXT, (WORD)0, (LONG)(LPSTR)szSetNU);
					return FALSE ;

				case IDC_STATS_USER_ADD:
					GetDlgItemText (hwnd,IDC_STATS_USER, szTemp, MAX_STATUSERNAME);
					if (SendMessage(GetDlgItem (hwnd, IDC_STATS_USER), CB_FINDSTRINGEXACT,
						(WORD)-1, (LONG)(LPSTR)szTemp) != CB_ERR)
					{
						MainMessage("That name is already in the list.") ;
						return FALSE ;
					}
							for (i = 0; i < NUMSTATUSERS ; i++)
					{
						if (StatsMU.Stats[i].UserName[0] <= ' ')
							break ;
					}
					if (i >= NUMSTATUSERS)
					{
						MainMessage("List is full.\nMaximum number of users is ten.") ;
						return FALSE ;
					}
					if (StatsMU.Stats[SCUser].TotalW || StatsMU.Stats[SCUser].TotalL || 
						StatsMU.Stats[SCUser].StreaksW || StatsMU.Stats[SCUser].StreaksL)
					{
						if (Message(hwnd, MB_ICONINFORMATION | MB_OKCANCEL,
"Note: A user name, once established,\ncannot be changed without\nerasing all of that user's statistics.")
						== IDCANCEL)
						return FALSE ;
					}
					GetDlgItemText (hwnd,IDC_STATS_USER, szTemp, MAX_STATUSERNAME);
				    nIndexS = SendMessage (GetDlgItem (hwnd, IDC_STATS_USER), 
		 						CB_ADDSTRING, 0, (LONG)(LPSTR)szTemp);
					lstrcpy(StatsMU.Stats[i].UserName, szTemp) ;
					SetUserIndexes(hwnd) ;
					SCUser = nSUserIndex[nIndexS] ;
					PostStatData(hwnd) ;
					SendMessage (GetDlgItem (hwnd, IDC_STATS_USER), 
		 						CB_SHOWDROPDOWN, (WORD)TRUE, 0L);
					return FALSE ;
				
				case IDOK:
				{
					StatsMU.StatEnbl = IsDlgButtonChecked (hwnd, IDC_STATS_ENABLE) ;
					StatsMU.StatAlert = !IsDlgButtonChecked (hwnd, IDC_STAT_ALERT) ;
					StatsMU.StatQuitConfirm =
							!IsDlgButtonChecked (hwnd, IDC_STAT_QUIT_CONFIRM) ;
					EndDialog(hwnd, TRUE);
				}
					return TRUE;

				case IDCANCEL:
					EndDialog(hwnd, FALSE);
					return TRUE;
			}
			break;
    }
return FALSE ;
}


BOOL CALLBACK SettingsDlgProc (
	HWND hwnd,
    UINT msg,
    WPARAM wParam,
    LPARAM lParam)
{								   
    switch (msg) 
	{
        case WM_INITDIALOG:
			// control
			CheckDlgButton (hwnd, IDC_SETTINGS_MESSAGES, gbMessages);
			CheckDlgButton (hwnd, IDC_SETTINGS_LOGGING, gbLogging);
			CheckDlgButton (hwnd, IDC_SETTINGS_FASTUNDO, gbFastUndo);
			CheckDlgButton (hwnd, IDC_SETTINGS_PROAIDS, gbProAids);
			CheckDlgButton (hwnd, IDC_SETTINGS_SUPERMOVE, gbSupermove);
			// animation
			CheckRadioButton (hwnd, IDC_SETTINGS_ANIMALL, 
								IDC_SETTINGS_ANIMNONE, 
								IDC_SETTINGS_ANIMALL + gnAnimation);
			// freecells
//		    SendMessage (GetDlgItem (hwnd, IDC_SETTINGS_NUMFCS), 
//		 					EM_LIMITTEXT, (WORD) 1, 0L);
//		    SetDlgItemInt (hwnd, IDC_SETTINGS_NUMFCS, NumFcs, FALSE);
			// undo
#ifndef FC89
			CheckRadioButton (hwnd, IDC_FC0, IDC_FC7, IDC_FC0 + NumFcs) ;
#else
			CheckRadioButton (hwnd, IDC_FC0, IDC_FC9, IDC_FC0 + NumFcs) ;
#endif
			CheckRadioButton (hwnd, IDC_SETTINGS_UNDOALL, 
								IDC_SETTINGS_UNDONONE, 
								IDC_SETTINGS_UNDOALL + gnUserUndoType);
			// random range
			CheckRadioButton (hwnd, IDC_SETTINGS_RAND32, 
								IDC_SETTINGS_RAND4, 
								IDC_SETTINGS_RAND32 + gnMaxRandGame);
			// window
		    CheckRadioButton (hwnd, IDC_SETTINGS_DBLCLK_NOACT,
				IDC_SETTINGS_DBLCLK_FREECELL,IDC_SETTINGS_DBLCLK_NOACT + gnDblclkMode) ;
			CheckDlgButton (hwnd, IDC_SETTINGS_TB, gbTool);
			CheckDlgButton (hwnd, IDC_SETTINGS_STATUS, gbStatus);
			CheckDlgButton (hwnd, IDC_SETTINGS_AUTOMOVE, gbSpider);
            return TRUE;

        case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDOK:
				{
					INT i;

					// control
					gbMessages = IsDlgButtonChecked (hwnd, 
									IDC_SETTINGS_MESSAGES) == BST_CHECKED;
					gbLogging  = IsDlgButtonChecked (hwnd, 
									IDC_SETTINGS_LOGGING) == BST_CHECKED;
					gbFastUndo = IsDlgButtonChecked (hwnd, 
									IDC_SETTINGS_FASTUNDO) == BST_CHECKED;
					gbProAids  = IsDlgButtonChecked (hwnd, 
									IDC_SETTINGS_PROAIDS) == BST_CHECKED;
					gbSupermove = IsDlgButtonChecked (hwnd, 
									IDC_SETTINGS_SUPERMOVE) == BST_CHECKED;
					// animation
					for (i = 0; i < 4; i++)
					{
						if (IsDlgButtonChecked (hwnd, IDC_SETTINGS_ANIMALL + i)
							== BST_CHECKED)
						{
							gnAnimation = i;
							break;
						}
					}
					// freecells
//				NumFcs = GetDlgItemInt (hwnd, 
//						   IDC_SETTINGS_NUMFCS, &NumFcs, FALSE);
//				if (NumFcs > 4) NumFcs = 4;
//				for (i = 0 ; i < 8 ; i++)
				for (i = 0 ; i < 10 ; i++)
				{
					if (IsDlgButtonChecked (hwnd, IDC_FC0 + i))
					{
						NumFcs = i ;
						break ;
					}
				}
					//Double-click
					for (i = 0; i < 3; i++)
					{
					if (IsDlgButtonChecked (hwnd, IDC_SETTINGS_DBLCLK_NOACT + i))
						{
						gnDblclkMode = i ;
						break ;
						}
					}
					// undo
					for (i = 0; i < 3; i++)
					{
						if (IsDlgButtonChecked (hwnd, IDC_SETTINGS_UNDOALL + i)
							== BST_CHECKED)
						{
							gnUserUndoType = i;
							break;
						}
					}
					// random range
					for (i = 0; i < 3; i++)
					{
						if (IsDlgButtonChecked (hwnd, IDC_SETTINGS_RAND32 + i)
							== BST_CHECKED)
						{
							gnMaxRandGame = i;
							break;
						}
					}
					// window
					gbTool = IsDlgButtonChecked (hwnd, 
									IDC_SETTINGS_TB) == BST_CHECKED;
					gbStatus = IsDlgButtonChecked (hwnd, 
									IDC_SETTINGS_STATUS) == BST_CHECKED;
					gbSpider = IsDlgButtonChecked (hwnd, 
									IDC_SETTINGS_AUTOMOVE) == BST_CHECKED;
					EndDialog(hwnd, TRUE);
				}
				return TRUE;

				case IDCANCEL:
					EndDialog(hwnd, FALSE);
					return TRUE;
			}
			break;
    }

    return FALSE;
}







