/*
 * card.h - header file for card functions for Freecell Solver
 *
 * Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000
 *
 * This file is in the public domain (it's uncopyrighted).
 */


#ifndef __CARD_H
#define __CARD_H

#ifdef _cplusplus
extern "C" {
#endif

#ifndef __STATE_H
#include "state.h"
#endif

extern fcs_card_t fcs_card_user2perl(char * str);
extern char * fcs_card_perl2user(fcs_card_t card, char * str);
extern char * fcs_p2u_card_number(short num, char * str, int * card_num_is_null);
extern short fcs_u2p_card_number(char * string);
extern short fcs_u2p_deck(char * deck);

#ifdef _cplusplus
}
#endif

#endif /* __CARD_H */
