/*
 * fcs.h - header file of freecell_solver_instance and of user-level
 * functions for Freecell Solver
 *
 * Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000
 *
 * This file is in the public domain (it's uncopyrighted).
 */

#ifndef __FCS_H
#define __FCS_H

#include "config.h"
#include "state.h"

#define FCS_TESTS_NUM 10

typedef struct freecell_solver_instance
{
#ifdef DIRECT_STATE_STORAGE
    fcs_state_with_locations_t * prev_states;

    int num_prev_states;
    int max_num_prev_states;
#endif    

    int unsorted_prev_states_start_at;

#ifdef DIRECT_STATE_STORAGE
    fcs_state_with_locations_t prev_states_margin[PREV_STATES_SORT_MARGIN];
#elif defined(INDIRECT_STATE_STORAGE)
    fcs_state_with_locations_t * indirect_prev_states_margin[PREV_STATES_SORT_MARGIN];
#endif
    
    int num_prev_states_margin;    

#ifdef INDIRECT_STATE_STORAGE    
    fcs_state_with_locations_t * * indirect_prev_states;
    int num_indirect_prev_states;
    int max_num_indirect_prev_states;
#endif    

#ifdef INDIRECT_STATE_STORAGE
    fcs_state_with_locations_t * * state_packs;
    int max_num_state_packs;
    int num_state_packs;
    int num_states_in_last_pack;
    int state_pack_len;
#endif
    int num_times;
    fcs_state_with_locations_t * * solution_states;
    int num_solution_states;

    int max_depth;
    int max_num_times;

    int debug_iter_output;
    void (*debug_iter_output_func)(
        void * context, 
        int iter_num, 
        int depth, 
        void * instance,
        fcs_state_with_locations_t * state
        );
    void * debug_iter_output_context;
    
    int tests_order_num;
    int tests_order[FCS_TESTS_NUM];
    
} freecell_solver_instance_t;

freecell_solver_instance_t * freecell_solver_alloc_instance(void);
void freecell_solver_init_instance(freecell_solver_instance_t * instance);
void freecell_solver_free_instance(freecell_solver_instance_t * instance);
void freecell_solver_finish_instance(freecell_solver_instance_t * instance);
int freecell_solver_solve_instance(
    freecell_solver_instance_t * instance,
    fcs_state_with_locations_t * init_state
    );



#endif /* __FCS_H */
