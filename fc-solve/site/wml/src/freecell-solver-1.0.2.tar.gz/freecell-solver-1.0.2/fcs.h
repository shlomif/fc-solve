/*
 * fcs.h - header file of freecell_solver_instance and of user-level
 * functions for Freecell Solver
 *
 * Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000
 *
 * This file is in the public domain (it's uncopyrighted).
 */

#ifndef __FCS_H
#define __FCS_H

#ifdef _cplusplus
extern "C" {
#endif

#include "config.h"
#include "state.h"
#include "move.h"
#include "fcs_enums.h"

#ifdef TREE_STATE_STORAGE

#ifdef LIBREDBLACK_TREE_IMPLEMENTATION

#include <redblack.h>

#elif defined(AVL_AVL_TREE_IMPLEMENTATION) || defined(AVL_REDBLACK_TREE_IMPLEMENTATION)

#if defined(AVL_AVL_TREE_IMPLEMENTATION)

#include <avl.h>

#define TREE_IMP_PREFIX(func_name) avl_##func_name

#elif defined(AVL_REDBLACK_TREE_IMPLEMENTATION)

#include <rb.h>

#define TREE_IMP_PREFIX(func_name) rb_##func_name

#endif

#define fcs_tree TREE_IMP_PREFIX(tree)
#define fcs_tree_create TREE_IMP_PREFIX(create)
#define fcs_tree_destroy TREE_IMP_PREFIX(destroy)
#define fcs_tree_insert TREE_IMP_PREFIX(insert)
#define fcs_tree_delete TREE_IMP_PREFIX(delete)

#elif defined(GLIB_TREE_IMPLEMENTATION)

#include <glib.h>

#endif

#endif

#ifdef GLIB_HASH_IMPLEMENTATION
#include <glib.h>
#endif

#ifdef INTERNAL_HASH_IMPLEMENTATION
#include "fcs_hash.h"
#include "md5.h"
#endif

#ifdef INDIRECT_STACK_STATES
#include "fcs_hash.h"
#include "md5.h"
#endif

#ifdef DB_FILE_STATE_STORAGE
#include <sys/types.h>
#include <limits.h>
#include <db.h>
#endif

#define FCS_TESTS_NUM 10

typedef struct freecell_solver_instance
{
#ifdef DIRECT_STATE_STORAGE
    fcs_state_with_locations_t * prev_states;

    int num_prev_states;
    int max_num_prev_states;
#endif    

    int unsorted_prev_states_start_at;

#ifdef DIRECT_STATE_STORAGE
    fcs_state_with_locations_t prev_states_margin[PREV_STATES_SORT_MARGIN];
#elif defined(INDIRECT_STATE_STORAGE)
    fcs_state_with_locations_t * indirect_prev_states_margin[PREV_STATES_SORT_MARGIN];
#endif
    
    int num_prev_states_margin;    

#ifdef INDIRECT_STATE_STORAGE    
    fcs_state_with_locations_t * * indirect_prev_states;
    int num_indirect_prev_states;
    int max_num_indirect_prev_states;
#endif    

#if defined(INDIRECT_STATE_STORAGE) || defined(TREE_STATE_STORAGE) || defined(HASH_STATE_STORAGE) || defined(DB_FILE_STATE_STORAGE)
    fcs_state_with_locations_t * * state_packs;
    int max_num_state_packs;
    int num_state_packs;
    int num_states_in_last_pack;
    int state_pack_len;
#endif
    int num_times;
    fcs_state_with_locations_t * * solution_states;
    int num_solution_states;
    
    fcs_move_stack_t * solution_moves;
    fcs_move_stack_t * * proto_solution_moves;

    int max_depth;
    int max_num_times;

    int debug_iter_output;
    void (*debug_iter_output_func)(
        void * context, 
        int iter_num, 
        int depth, 
        void * instance,
        fcs_state_with_locations_t * state
        );
    void * debug_iter_output_context;
    
    int tests_order_num;
    int tests_order[FCS_TESTS_NUM];

#ifdef TREE_STATE_STORAGE
#ifdef LIBREDBLACK_TREE_IMPLEMENTATION
    struct rbtree * tree;
#elif defined(AVL_AVL_TREE_IMPLEMENTATION) || defined(AVL_REDBLACK_TREE_IMPLEMENTATION)
    fcs_tree * tree;
#elif defined(GLIB_TREE_IMPLEMENTATION)
    GTree * tree;
#endif
#endif

#if defined(HASH_STATE_STORAGE)
#ifdef GLIB_HASH_IMPLEMENTATION
    GHashTable * hash;
#elif defined(INTERNAL_HASH_IMPLEMENTATION)
    SFO_hash_t * hash;
#endif
#endif

#if defined(INDIRECT_STACK_STATES) || defined(INTERNAL_HASH_IMPLEMENTATION)
    MD5_CTX md5_context;
    unsigned char hash_value[MD5_HASHBYTES];    
#endif

#if defined(INDIRECT_STACK_STATES)
    SFO_hash_t * stacks_hash;
#endif

#ifdef DB_FILE_STATE_STORAGE
    DB * db;
#endif  

    int freecells_num;
    int stacks_num;
    int decks_num;

    int sequences_are_built_by;
    int unlimited_sequence_move;
    int empty_stacks_fill;
    
} freecell_solver_instance_t;

freecell_solver_instance_t * freecell_solver_alloc_instance(void);
void freecell_solver_init_instance(freecell_solver_instance_t * instance);
void freecell_solver_free_instance(freecell_solver_instance_t * instance);
void freecell_solver_finish_instance(freecell_solver_instance_t * instance);
int freecell_solver_solve_instance(
    freecell_solver_instance_t * instance,
    fcs_state_with_locations_t * init_state
    );

int freecell_solver_resume_instance(
    freecell_solver_instance_t * instance
    );

void freecell_solver_unresume_instance(
    freecell_solver_instance_t * instance
    );


#ifdef _cplusplus
}
#endif

#endif /* __FCS_H */
