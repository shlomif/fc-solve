/*
 * fcs.h - header file of freecell_solver_instance and of user-level
 * functions for Freecell Solver
 *
 * Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000
 *
 * This file is in the public domain (it's uncopyrighted).
 */

#ifndef __FCS_H
#define __FCS_H

#include "config.h"
#include "state.h"

#ifdef TREE_STATE_STORAGE

#ifdef LIBREDBLACK_TREE_IMPLEMENTATION

#include <redblack.h>

#elif defined(AVL_AVL_TREE_IMPLEMENTATION) || defined(AVL_REDBLACK_TREE_IMPLEMENTATION)

#if defined(AVL_AVL_TREE_IMPLEMENTATION)

#include <avl.h>

#define TREE_IMP_PREFIX(func_name) avl_##func_name

#elif defined(AVL_REDBLACK_TREE_IMPLEMENTATION)

#include <rb.h>

#define TREE_IMP_PREFIX(func_name) rb_##func_name

#endif

#define fcs_tree TREE_IMP_PREFIX(tree)
#define fcs_tree_create TREE_IMP_PREFIX(create)
#define fcs_tree_destroy TREE_IMP_PREFIX(destroy)
#define fcs_tree_insert TREE_IMP_PREFIX(insert)

#elif defined(GLIB_TREE_IMPLEMENTATION)

#include <glib.h>

#endif

#endif

#ifdef HASH_STATE_STORAGE
#include <glib.h>
#endif

#define FCS_TESTS_NUM 10

typedef struct freecell_solver_instance
{
#ifdef DIRECT_STATE_STORAGE
    fcs_state_with_locations_t * prev_states;

    int num_prev_states;
    int max_num_prev_states;
#endif    

    int unsorted_prev_states_start_at;

#ifdef DIRECT_STATE_STORAGE
    fcs_state_with_locations_t prev_states_margin[PREV_STATES_SORT_MARGIN];
#elif defined(INDIRECT_STATE_STORAGE)
    fcs_state_with_locations_t * indirect_prev_states_margin[PREV_STATES_SORT_MARGIN];
#endif
    
    int num_prev_states_margin;    

#ifdef INDIRECT_STATE_STORAGE    
    fcs_state_with_locations_t * * indirect_prev_states;
    int num_indirect_prev_states;
    int max_num_indirect_prev_states;
#endif    

#if defined(INDIRECT_STATE_STORAGE) || defined(TREE_STATE_STORAGE) || defined(HASH_STATE_STORAGE)
    fcs_state_with_locations_t * * state_packs;
    int max_num_state_packs;
    int num_state_packs;
    int num_states_in_last_pack;
    int state_pack_len;
#endif
    int num_times;
    fcs_state_with_locations_t * * solution_states;
    int num_solution_states;

    int max_depth;
    int max_num_times;

    int debug_iter_output;
    void (*debug_iter_output_func)(
        void * context, 
        int iter_num, 
        int depth, 
        void * instance,
        fcs_state_with_locations_t * state
        );
    void * debug_iter_output_context;
    
    int tests_order_num;
    int tests_order[FCS_TESTS_NUM];

#ifdef TREE_STATE_STORAGE
#ifdef LIBREDBLACK_TREE_IMPLEMENTATION
    struct rbtree * tree;
#elif defined(AVL_AVL_TREE_IMPLEMENTATION) || defined(AVL_REDBLACK_TREE_IMPLEMENTATION)
    fcs_tree * tree;
#elif defined(GLIB_TREE_IMPLEMENTATION)
    GTree * tree;
#endif
#endif

#ifdef HASH_STATE_STORAGE
    GHashTable * hash;
#endif

    int freecells_num;
    int stacks_num;
    
} freecell_solver_instance_t;

freecell_solver_instance_t * freecell_solver_alloc_instance(void);
void freecell_solver_init_instance(freecell_solver_instance_t * instance);
void freecell_solver_free_instance(freecell_solver_instance_t * instance);
void freecell_solver_finish_instance(freecell_solver_instance_t * instance);
int freecell_solver_solve_instance(
    freecell_solver_instance_t * instance,
    fcs_state_with_locations_t * init_state
    );



#endif /* __FCS_H */
