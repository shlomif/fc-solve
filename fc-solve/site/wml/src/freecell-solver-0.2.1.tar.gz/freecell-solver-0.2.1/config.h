#define FAST_STATES
/* #define DEBUG */
