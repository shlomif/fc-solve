This package contains the Windows 95/98/NT/2000/ME binaries of 
Freecell Solver 1.10.4. Read the file "README" for usage and other
information.

This version of Freecell Solver supports up to 8 freecells, 12 
stacks and 11 initial cards per stack. If you'd like to increase 
those settings, you'll need to recompile it. It was compiled with a
recursion stack size of 32 megabytes. (don't worry if you don't have
so much memory in your computer - it will still run fine)

Freecell Solver's homepage is at the following URL:

http://vipe.technion.ac.il/~shlomif/freecell-solver/


Enjoy!

	Shlomi Fish