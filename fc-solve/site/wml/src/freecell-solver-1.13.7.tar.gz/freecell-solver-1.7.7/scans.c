/*
 * scans.c - The code that relates to the various scans.
 * Currently Hard DFS, Soft-DFS, A* and BFS are implemented.
 *
 * Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000-2001
 *
 * This file is in the public domain (it's uncopyrighted).
 */

#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <stdio.h>
#include <math.h>
#if FCS_STATE_STORAGE==FCS_STATE_STORAGE_LIBREDBLACK_TREE
#include <search.h>
#endif

#include "config.h"
#include "state.h"
#include "card.h"
#include "fcs_dm.h"
#include "fcs.h"

#include "fcs_isa.h"

#include "tests.h"

#define state (ptr_state_with_locations->s)

    
int freecell_solver_solve_for_state(
    freecell_solver_soft_thread_t * soft_thread,
    fcs_state_with_locations_t * ptr_state_with_locations,
    int depth,
    int ignore_osins
    )

{
    freecell_solver_instance_t * instance;
    freecell_solver_hard_thread_t * hard_thread;
    
    int a;
    int check;

    int num_freestacks, num_freecells;
    int iter_num;
    
    instance = soft_thread->instance;
    hard_thread = soft_thread->hard_thread;
    

    iter_num = instance->num_times;
    instance->num_times++;
    hard_thread->num_times++;


    if (instance->debug_iter_output)
    {
        instance->debug_iter_output_func(
                (void*)instance->debug_iter_output_context,
                iter_num,
                depth,
                (void*)instance,
                ptr_state_with_locations
                );
    }
    

    /* Count the free-cells */
    num_freecells = 0;
    for(a=0;a<instance->freecells_num;a++)
    {
        if (fcs_freecell_card_num(state, a) == 0)
        {
            num_freecells++;
        }
    }

    /* Count the number of unoccupied stacks */
    
    num_freestacks = 0;    
    for(a=0;a<instance->stacks_num;a++)
    {
        if (fcs_stack_len(state, a) == 0)
        {
            num_freestacks++;
        }
    }

   
    /* Let's check if this state is finished, and if so return 0; */
    if ((num_freestacks == instance->stacks_num) && (num_freecells == instance->freecells_num))
    {
        instance->final_state = ptr_state_with_locations;

        soft_thread->num_solution_states = depth+1;

        soft_thread->solution_states = malloc(sizeof(fcs_state_with_locations_t*) * soft_thread->num_solution_states);

        /* Mark this state as part of the non-optimized solution path */
        ptr_state_with_locations->visited |= FCS_VISITED_IN_SOLUTION_PATH;
        soft_thread->solution_states[depth] = malloc(sizeof(fcs_state_with_locations_t)); 
        fcs_duplicate_state(*(soft_thread->solution_states[depth]), *ptr_state_with_locations); 

        return FCS_STATE_WAS_SOLVED;
    }

    
    for(a=0 ;
        a < soft_thread->tests_order_num;
        a++)
    {
        check = freecell_solver_sfs_tests[soft_thread->tests_order[a]] (
                soft_thread,
                ptr_state_with_locations,
                depth,
                num_freestacks,
                num_freecells,
                ignore_osins
                );

        if (check == FCS_STATE_WAS_SOLVED)
        {
            /* Mark this state as part of the non-optimized solution path */
            ptr_state_with_locations->visited |= FCS_VISITED_IN_SOLUTION_PATH;

            soft_thread->solution_states[depth] =
                malloc(sizeof(fcs_state_with_locations_t));
            fcs_duplicate_state(
                *(soft_thread->solution_states[depth]), 
                *ptr_state_with_locations
                ); 
        
            return FCS_STATE_WAS_SOLVED;
        }
        else if ((check == FCS_STATE_ORIGINAL_STATE_IS_NOT_SOLVEABLE))
        {
            return FCS_STATE_IS_NOT_SOLVEABLE;
        }
        else if ((check == FCS_STATE_BEGIN_SUSPEND_PROCESS) ||
                 (check == FCS_STATE_SUSPEND_PROCESS))
        {
            if (check == FCS_STATE_BEGIN_SUSPEND_PROCESS)
            {
                soft_thread->num_solution_states = depth+1;
                
                soft_thread->solution_states = malloc(sizeof(fcs_state_with_locations_t*) * soft_thread->num_solution_states);
            }

#if 0
            soft_thread->solution_states[depth] = malloc(sizeof(fcs_state_with_locations_t));
            fcs_duplicate_state(*(soft_thread->solution_states[depth]), *ptr_state_with_locations);
#endif
            soft_thread->solution_states[depth] = ptr_state_with_locations;

            return FCS_STATE_SUSPEND_PROCESS;
        }
    }

    return FCS_STATE_IS_NOT_SOLVEABLE;
}


int freecell_solver_solve_for_state_resume_solution(
    freecell_solver_soft_thread_t * soft_thread,
    int depth
    )
{
    fcs_state_with_locations_t * ptr_state_with_locations;
    int check;
    int use_own_moves = 1;

    ptr_state_with_locations = soft_thread->solution_states[depth];

    if (depth < soft_thread->num_solution_states-1)
    {
        check = freecell_solver_solve_for_state_resume_solution(
            soft_thread,
            depth+1
            );        
    }
    else
    {
        free(soft_thread->solution_states);
        soft_thread->solution_states = NULL;
        check = FCS_STATE_IS_NOT_SOLVEABLE;
    }

    if (check == FCS_STATE_IS_NOT_SOLVEABLE)
    {
        check = freecell_solver_solve_for_state(
            soft_thread,
            ptr_state_with_locations,
            depth,
            1);
        use_own_moves = 0;
#if 0        
        if (moves != NULL)
        {
            fcs_move_stack_destroy(moves);
        }
#endif
    }
    else if ((check == FCS_STATE_SUSPEND_PROCESS) || (check == FCS_STATE_WAS_SOLVED))
    {
#if 0
        soft_thread->solution_states[depth] = malloc(sizeof(fcs_state_with_locations_t));
        fcs_duplicate_state(*(soft_thread->solution_states[depth]), *ptr_state_with_locations);
#endif
        soft_thread->solution_states[depth] = ptr_state_with_locations;
    }

#if 0
    free(ptr_state_with_locations);
#endif

    return check;
}

#undef state





static void freecell_solver_increase_dfs_max_depth(
    freecell_solver_soft_thread_t * soft_thread
    )
{
    int new_dfs_max_depth = soft_thread->dfs_max_depth + 16;
    int d;

#define MYREALLOC(what) \
    soft_thread->what = realloc( \
        soft_thread->what,       \
        sizeof(soft_thread->what[0])*new_dfs_max_depth \
        ); \

    MYREALLOC(solution_states);
    MYREALLOC(soft_dfs_states_to_check);
    MYREALLOC(soft_dfs_num_states_to_check);
    MYREALLOC(soft_dfs_current_state_indexes);
    MYREALLOC(soft_dfs_test_indexes);
    MYREALLOC(soft_dfs_max_num_states_to_check);
    MYREALLOC(soft_dfs_num_freestacks);
    MYREALLOC(soft_dfs_num_freecells);
#undef MYREALLOC
    
    for(d=soft_thread->dfs_max_depth ; d<new_dfs_max_depth; d++)
    {
        soft_thread->solution_states[d] = NULL;
        soft_thread->soft_dfs_max_num_states_to_check[d] = 0;
        soft_thread->soft_dfs_test_indexes[d] = 0;
        soft_thread->soft_dfs_current_state_indexes[d] = 0;
        soft_thread->soft_dfs_num_states_to_check[d] = 0;
    }

    soft_thread->dfs_max_depth = new_dfs_max_depth;
}

/*
    freecell_solver_soft_dfs_do_solve_or_resume is the event loop of the Soft-DFS
    scan. DFS which is recursive in nature is handled here without procedural recursion
    by using some dedicated stacks for the traversal.

  */
#define state (ptr_state_with_locations->s)

static int freecell_solver_soft_dfs_do_solve_or_resume(
    freecell_solver_soft_thread_t * soft_thread,
    fcs_state_with_locations_t * ptr_state_with_locations_orig,
    int resume
    )
{
    int depth;
    fcs_state_with_locations_t * ptr_state_with_locations, 
        * ptr_recurse_into_state_with_locations;
    int a;
    int check;
    freecell_solver_instance_t * instance;
    freecell_solver_hard_thread_t * hard_thread;
    
    instance = soft_thread->instance;
    hard_thread = soft_thread->hard_thread;

    if (!resume)
    {
        /*
            Allocate some space for the states at depth 0. 
        */
        depth=0;
    
        freecell_solver_increase_dfs_max_depth(soft_thread);

        soft_thread->soft_dfs_max_num_states_to_check[depth] = FCS_SOFT_DFS_STATES_TO_CHECK_GROW_BY;
        soft_thread->soft_dfs_states_to_check[depth] = malloc(
            sizeof(soft_thread->soft_dfs_states_to_check[depth][0]) *
            soft_thread->soft_dfs_max_num_states_to_check[depth]
            );
        soft_thread->solution_states[0] = ptr_state_with_locations_orig;
    }
    else
    {
        /*
            Set the initial depth to that of the last state encountered.
        */
        depth = soft_thread->num_solution_states - 1;
    }

    /*
        The main loop.
    */
    while (depth >= 0)
    {
        /*
            Increase the "maximal" depth if it about to be exceeded.
        */
        if (depth+1 >= soft_thread->dfs_max_depth)
        {
            freecell_solver_increase_dfs_max_depth(soft_thread);
        }
        
        /* All the resultant states in the last test conducted were covered */
        if (soft_thread->soft_dfs_current_state_indexes[depth] == soft_thread->soft_dfs_num_states_to_check[depth])
        {
        
            if (soft_thread->soft_dfs_test_indexes[depth] >= soft_thread->tests_order_num)
            {
                /* Backtrack to the previous depth. */
                depth--;
                continue; /* Just to make sure depth is not -1 now */    
            }        

            soft_thread->soft_dfs_num_states_to_check[depth] = 0;
        
            ptr_state_with_locations = soft_thread->solution_states[depth];
        

            /* If this is the first test, then count the number of unoccupied
               freeceelsc and stacks and check if we are done. */
            if (soft_thread->soft_dfs_test_indexes[depth] == 0)
            {
                int num_freestacks, num_freecells;

                if (soft_thread->instance->debug_iter_output)
                {
                    soft_thread->instance->debug_iter_output_func(
                        (void*)soft_thread->instance->debug_iter_output_context,
                        instance->num_times,
                        depth,
                        (void*)instance,
                        ptr_state_with_locations
                        );
                }

                /* Count the free-cells */
                num_freecells = 0;
                for(a=0;a<instance->freecells_num;a++)
                {
                    if (fcs_freecell_card_num(state, a) == 0)
                    {
                        num_freecells++;
                    }
                }

                /* Count the number of unoccupied stacks */

                num_freestacks = 0;    
                for(a=0;a<instance->stacks_num;a++)
                {
                    if (fcs_stack_len(state, a) == 0)
                    {
                        num_freestacks++;
                    }
                }

                /* Check if we have reached the empty state */
                if ((num_freestacks == instance->stacks_num) && (num_freecells == instance->freecells_num))
                {
                    int d;
                    fcs_state_with_locations_t * ptr_state;
        
                    /*
                        Copy all the states to a separetely malloced memory, so they won't 
                        be lost when the state packs are de-allocated.
                    */
                    instance->num_solution_states = depth+1;
                    instance->solution_states = malloc(sizeof(instance->solution_states[0]) * instance->num_solution_states );
                    for(d=0;d<=depth;d++)
                    {
                        /* Mark the states in the solution path as part of the non-optimized
                           solution
                        */
                        instance->solution_states[d] = malloc(sizeof(fcs_state_with_locations_t));
                        soft_thread->solution_states[d]->visited |= FCS_VISITED_IN_SOLUTION_PATH;
                        ptr_state = (fcs_state_with_locations_t *)malloc(sizeof(fcs_state_with_locations_t));
                        fcs_duplicate_state(*ptr_state, *(instance->solution_states[d]));
                        instance->solution_states[d] = ptr_state;
                    }

                    instance->final_state = ptr_state_with_locations;
                    
                    return FCS_STATE_WAS_SOLVED;
                }
                /*
                    Cache num_freecells and num_freestacks in their 
                    appropriate stacks, so they won't be calculated over and over
                    again.
                  */
                soft_thread->soft_dfs_num_freecells[depth] = num_freecells;
                soft_thread->soft_dfs_num_freestacks[depth] = num_freestacks;
            }
            

        
        
            check = freecell_solver_sfs_tests[soft_thread->tests_order[
                    soft_thread->soft_dfs_test_indexes[depth]
                ]] (
                    soft_thread,
                    ptr_state_with_locations,
                    depth,
                    soft_thread->soft_dfs_num_freestacks[depth],
                    soft_thread->soft_dfs_num_freecells[depth],
                    1   /* Pass TRUE as ignore_osins */
                );
        
            if ((check == FCS_STATE_BEGIN_SUSPEND_PROCESS) ||
                (check == FCS_STATE_EXCEEDS_MAX_NUM_TIMES) ||
                (check == FCS_STATE_SUSPEND_PROCESS))
            {
                /* Have this test be re-performed */
                soft_thread->soft_dfs_num_states_to_check[depth] = 0;
                soft_thread->soft_dfs_current_state_indexes[depth] = 0;
                soft_thread->num_solution_states = depth+1;
                return FCS_STATE_SUSPEND_PROCESS;
            }
        
            /* Move the counter to the next test */
            soft_thread->soft_dfs_test_indexes[depth]++;
        
            /* We just performed a test, so the index of the first state that
               ought to be checked in this depth is 0.
               */
            soft_thread->soft_dfs_current_state_indexes[depth] = 0;
        }
        
        while (soft_thread->soft_dfs_current_state_indexes[depth] < 
               soft_thread->soft_dfs_num_states_to_check[depth])
        {
            ptr_recurse_into_state_with_locations = (soft_thread->soft_dfs_states_to_check[depth][ 
                    soft_thread->soft_dfs_current_state_indexes[depth]
                ]);
            
            soft_thread->soft_dfs_current_state_indexes[depth]++;
            if (!ptr_recurse_into_state_with_locations->visited)
            {
                ptr_recurse_into_state_with_locations->visited = FCS_VISITED_VISITED;
                instance->num_times++;
                hard_thread->num_times++;
                soft_thread->solution_states[depth+1] = ptr_recurse_into_state_with_locations;
                /*
                    I'm using current_state_indexes[depth]-1 because we already
                    increaded it by one, so now it refers to the next state.
                */
                depth++;
                soft_thread->soft_dfs_test_indexes[depth] = 0;
                soft_thread->soft_dfs_current_state_indexes[depth] = 0;
                soft_thread->soft_dfs_num_states_to_check[depth] = 0;
                
                if (soft_thread->soft_dfs_max_num_states_to_check[depth] == 0)
                {
                    soft_thread->soft_dfs_max_num_states_to_check[depth] = FCS_SOFT_DFS_STATES_TO_CHECK_GROW_BY;
                    soft_thread->soft_dfs_states_to_check[depth] = malloc(
                        sizeof(soft_thread->soft_dfs_states_to_check[depth][0]) *
                        soft_thread->soft_dfs_max_num_states_to_check[depth]
                        );
                }
                break;
            }
        }    
    }

    soft_thread->num_solution_states = 0;
    
    return FCS_STATE_IS_NOT_SOLVEABLE;
}

#undef state

int freecell_solver_soft_dfs_solve_for_state(
    freecell_solver_soft_thread_t * soft_thread,
    fcs_state_with_locations_t * ptr_state_with_locations_orig
    )
{
    return freecell_solver_soft_dfs_do_solve_or_resume(
        soft_thread,
        ptr_state_with_locations_orig,
        0
        );
}

int freecell_solver_soft_dfs_solve_for_state_resume_solution(
    freecell_solver_soft_thread_t * soft_thread
    )
{
    return freecell_solver_soft_dfs_do_solve_or_resume(
        soft_thread,
        NULL,
        1
        );
}


void freecell_solver_bfs_enqueue_state(
    freecell_solver_soft_thread_t * soft_thread,
    fcs_state_with_locations_t * state
    )
{
    soft_thread->bfs_queue_last_item->next = (fcs_states_linked_list_item_t*)malloc(sizeof(fcs_states_linked_list_item_t));
    soft_thread->bfs_queue_last_item->s = state;
    soft_thread->bfs_queue_last_item->next->next = NULL;
    soft_thread->bfs_queue_last_item = soft_thread->bfs_queue_last_item->next;
}


#define FCS_A_STAR_CARDS_UNDER_SEQUENCES_EXPONENT 1.3
#define FCS_A_STAR_SEQS_OVER_RENEGADE_CARDS_EXPONENT 1.3

#define state (ptr_state_with_locations->s)

void freecell_solver_a_star_initialize_rater(
    freecell_solver_soft_thread_t * soft_thread, 
    fcs_state_with_locations_t * ptr_state_with_locations
    )
{
    int a, c, cards_num;
    fcs_card_t this_card, prev_card;
    double cards_under_sequences;
    freecell_solver_instance_t * instance;
    
    instance = soft_thread->instance;

    cards_under_sequences = 0;

    
    for(a=0;a<instance->stacks_num;a++)
    {
        cards_num = fcs_stack_len(state, a);
        if (cards_num <= 1)
        {
            continue;
        }

        c = cards_num-2;
        this_card = fcs_stack_card(state, a, c+1);
        prev_card = fcs_stack_card(state, a, c);
        while (fcs_is_parent_card(this_card,prev_card) && (c >= 0))
        {
            c--;
            this_card = prev_card;
            if (c>=0)
            {
                prev_card = fcs_stack_card(state, a, c);
            }
        }
        cards_under_sequences += pow(c+1, FCS_A_STAR_CARDS_UNDER_SEQUENCES_EXPONENT);
    }
    soft_thread->a_star_initial_cards_under_sequences = cards_under_sequences;
}


pq_rating_t freecell_solver_a_star_rate_state(
    freecell_solver_soft_thread_t * soft_thread, 
    fcs_state_with_locations_t * ptr_state_with_locations)
{
    double ret=0;
    int a, c, cards_num, num_cards_in_founds;
    int num_freestacks, num_freecells;
    fcs_card_t this_card, prev_card;
    double cards_under_sequences, temp;
    double seqs_over_renegade_cards;
    freecell_solver_instance_t * instance;

    instance = soft_thread->instance;

    cards_under_sequences = 0;
    num_freestacks = 0;
    seqs_over_renegade_cards = 0;
    for(a=0;a<instance->stacks_num;a++)
    {
        cards_num = fcs_stack_len(state, a);
        if (cards_num == 0)
        {
            num_freestacks++;
        }
        
        if (cards_num <= 1)
        {
            continue;
        }

        c = cards_num-2;
        this_card = fcs_stack_card(state, a, c+1);
        prev_card = fcs_stack_card(state, a, c);
        while ((c >= 0) && fcs_is_parent_card(this_card,prev_card))
        {
            c--;
            this_card = prev_card;
            if (c>=0)
            {
                prev_card = fcs_stack_card(state, a, c);
            }
        }
        cards_under_sequences += pow(c+1, FCS_A_STAR_CARDS_UNDER_SEQUENCES_EXPONENT);
        if (c >= 0)
        {
            seqs_over_renegade_cards += 
                ((instance->unlimited_sequence_move) ? 
                    1 :
                    pow(cards_num-c-1, FCS_A_STAR_SEQS_OVER_RENEGADE_CARDS_EXPONENT)
                    );
        }
    }

    ret += ((soft_thread->a_star_initial_cards_under_sequences - cards_under_sequences) 
            / soft_thread->a_star_initial_cards_under_sequences) * soft_thread->a_star_weights[FCS_A_STAR_WEIGHT_CARDS_UNDER_SEQUENCES];

    ret += (seqs_over_renegade_cards / 
               pow(instance->decks_num*52, FCS_A_STAR_SEQS_OVER_RENEGADE_CARDS_EXPONENT) )
           * soft_thread->a_star_weights[FCS_A_STAR_WEIGHT_SEQS_OVER_RENEGADE_CARDS];

    num_cards_in_founds = 0;
    for(a=0;a<instance->decks_num*4;a++)
    {
        num_cards_in_founds += fcs_foundation_value(state, a);
    }

    ret += ((double)num_cards_in_founds/(instance->decks_num*52)) * soft_thread->a_star_weights[FCS_A_STAR_WEIGHT_CARDS_OUT];

    num_freecells = 0;
    for(a=0;a<instance->freecells_num;a++)
    {
        if (fcs_freecell_card_num(state,a) == 0)
        {
            num_freecells++;
        }
    }

    if (instance->empty_stacks_fill == FCS_ES_FILLED_BY_ANY_CARD)
    {
        if (instance->unlimited_sequence_move)
        {
            temp = (((double)num_freecells+num_freestacks)/(instance->freecells_num+instance->stacks_num));
        }
        else
        {
            temp = (((double)((num_freecells+1)<<num_freestacks)) / ((instance->freecells_num+1)<<(instance->stacks_num)));
        }
    }
    else
    {
        if (instance->unlimited_sequence_move)
        {
            temp = (((double)num_freecells)/instance->freecells_num);
        }
        else
        {
            temp = 0;
        }
    }

    ret += (temp * soft_thread->a_star_weights[FCS_A_STAR_WEIGHT_MAX_SEQUENCE_MOVE]);
    
    if (ptr_state_with_locations->depth <= 20000)
    {
        ret += ((20000 - ptr_state_with_locations->depth)/20000.0) * soft_thread->a_star_weights[FCS_A_STAR_WEIGHT_DEPTH];
    }

    return (int)(ret*INT_MAX);
}





void freecell_solver_a_star_enqueue_state(
    freecell_solver_soft_thread_t * soft_thread,
    fcs_state_with_locations_t * ptr_state_with_locations
    )
{
    PQueuePush(
        soft_thread->a_star_pqueue,
        ptr_state_with_locations,
        freecell_solver_a_star_rate_state(soft_thread, ptr_state_with_locations)
        );
}






/*
    freecell_solver_a_star_or_bfs_do_solve_or_resume() is the main event
    loop of the A* And BFS scans. It is quite simple as all it does is
    extract elements out of the queue or priority queue and run all the test
    of them. 
    
    It goes on in this fashion until the final state was reached or 
    there are no more states in the queue.
*/
int freecell_solver_a_star_or_bfs_do_solve_or_resume(
    freecell_solver_soft_thread_t * soft_thread,
    fcs_state_with_locations_t * ptr_state_with_locations_orig,
    int resume
    )
{
    freecell_solver_instance_t * instance;
    freecell_solver_hard_thread_t * hard_thread;
    fcs_state_with_locations_t * ptr_state_with_locations;
    int num_freestacks, num_freecells;
    fcs_states_linked_list_item_t * save_item;
    int a;
    int check;

    instance = soft_thread->instance;
    hard_thread = soft_thread->hard_thread;

    if (!resume)
    {
        /* Initialize the first element to indicate it is the first */
        ptr_state_with_locations_orig->parent = NULL;
        ptr_state_with_locations_orig->moves_to_parent = NULL;
        ptr_state_with_locations_orig->depth = 0;
    }

    ptr_state_with_locations = ptr_state_with_locations_orig;
    
    /* Continue as long as there are states in the queue or 
       priority queue. */
    while ( ptr_state_with_locations != NULL)
    {
        /* Count the free-cells */
        num_freecells = 0;
        for(a=0;a<instance->freecells_num;a++)
        {
            if (fcs_freecell_card_num(state, a) == 0)
            {
                num_freecells++;
            }
        }

        /* Count the number of unoccupied stacks */

        num_freestacks = 0;    
        for(a=0;a<instance->stacks_num;a++)
        {
            if (fcs_stack_len(state, a) == 0)
            {
                num_freestacks++;
            }
        }

        if (instance->debug_iter_output)
        {
            instance->debug_iter_output_func(
                    (void*)instance->debug_iter_output_context,
                    instance->num_times,
                    ptr_state_with_locations->depth,
                    (void*)instance,
                    ptr_state_with_locations
                    );
        }    


        if ((num_freestacks == instance->stacks_num) && (num_freecells == instance->freecells_num))
        {
            /*
                Trace the solution.
            */
            int num_solution_states;
            fcs_state_with_locations_t * s1;

            s1 = ptr_state_with_locations;

            /* The depth of the last state reached is the number of them */
            num_solution_states = instance->num_solution_states = s1->depth+1;
            /* Allocate space for the solution stacks */
            instance->solution_states = malloc(sizeof(fcs_state_with_locations_t *)*num_solution_states);
            /* Retrace the step from the current state to its parents */
            while (s1->parent != NULL)
            {
                /* Mark the state as part of the non-optimized solution */
                s1->visited |= FCS_VISITED_IN_SOLUTION_PATH;
                /* Duplicate the state to a freshly malloced memory */
                instance->solution_states[s1->depth] = (fcs_state_with_locations_t*)malloc(sizeof(fcs_state_with_locations_t));
                fcs_duplicate_state(*(instance->solution_states[s1->depth]), *s1);
        
                /* Move to the parent state */
                s1 = s1->parent;
            }
            /* There's one more state that there are move stacks */
            instance->solution_states[0] = (fcs_state_with_locations_t*)malloc(sizeof(fcs_state_with_locations_t));
            fcs_duplicate_state(*(instance->solution_states[0]), *s1);
            
            instance->final_state = ptr_state_with_locations;

            return FCS_STATE_WAS_SOLVED;
        }

        /* Increase the number of iterations by one */
        instance->num_times++;
        hard_thread->num_times++;

        /* Do all the tests at one go, because that the way it should be
           done for BFS and A* 
        */
        for(a=0 ;
            a < soft_thread->tests_order_num;
            a++)
        {
            check = freecell_solver_sfs_tests[soft_thread->tests_order[a]] (
                    soft_thread,
                    ptr_state_with_locations,
                    ptr_state_with_locations->depth,
                    num_freestacks,
                    num_freecells,
                    1
                    );
            if ((check == FCS_STATE_BEGIN_SUSPEND_PROCESS) ||
                (check == FCS_STATE_EXCEEDS_MAX_NUM_TIMES) ||
                (check == FCS_STATE_SUSPEND_PROCESS))
            {
                /* Save the current position in the scan */
                soft_thread->first_state_to_check = ptr_state_with_locations;
                return FCS_STATE_SUSPEND_PROCESS;
            }
        }

        /*
            Extract the next item in the queue/priority queue.
        */
        if ((soft_thread->method == FCS_METHOD_BFS) || (soft_thread->method == FCS_METHOD_OPTIMIZE))
        {
            if (soft_thread->bfs_queue->next != soft_thread->bfs_queue_last_item)
            {
                save_item = soft_thread->bfs_queue->next;
                ptr_state_with_locations = save_item->s;
                soft_thread->bfs_queue->next = soft_thread->bfs_queue->next->next;
                free(save_item);
            }
            else
            {
                ptr_state_with_locations = NULL;
            }
        }
        else
        {
            /* It is an A* scan */
            ptr_state_with_locations = PQueuePop(soft_thread->a_star_pqueue);
        }
    }

    return FCS_STATE_IS_NOT_SOLVEABLE;
}


int freecell_solver_a_star_or_bfs_solve_for_state(
    freecell_solver_soft_thread_t * soft_thread,
    fcs_state_with_locations_t * ptr_state_with_locations_orig
    )
{
    return freecell_solver_a_star_or_bfs_do_solve_or_resume(
            soft_thread,
            ptr_state_with_locations_orig,
            0
            );
}

int freecell_solver_a_star_or_bfs_resume_solution(
    freecell_solver_soft_thread_t * soft_thread
    )
{
    return freecell_solver_a_star_or_bfs_do_solve_or_resume(
            soft_thread,
            soft_thread->first_state_to_check,
            1
            );
}


#undef state
