/*
 * fcs.h - header file of the test functions for Freecell Solver.
 *
 * The test functions code is found in freecell.c
 *
 * Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000
 *
 * This file is in the public domain (it's uncopyrighted).
 */

#ifndef __TESTS_H
#define __TESTS_H

#include <stdlib.h>
#include <limits.h>

#include "fcs_isa.h"
#include "fcs.h"

typedef int (*freecell_solver_solve_for_state_test_t)(
        freecell_solver_instance_t *,
        fcs_state_with_locations_t *,
        int,
        int,
        int,
        int
        );

extern freecell_solver_solve_for_state_test_t freecell_solver_sfs_tests[FCS_TESTS_NUM];

/*
 * This macro determines if child can be placed above parent.
 *
 * instance has to be defined.
 * 
 * */
#define fcs_is_parent_card(child, parent) \
    ((fcs_card_card_num(child)+1 == fcs_card_card_num(parent)) && \
    ((instance->sequences_are_built_by == FCS_SEQ_BUILT_BY_RANK) ?   \
        1 :                                                          \
        ((instance->sequences_are_built_by == FCS_SEQ_BUILT_BY_SUIT) ?   \
            (fcs_card_suit(child) == fcs_card_suit(parent)) :     \
            ((fcs_card_suit(child) & 0x1) != (fcs_card_suit(parent)&0x1))   \
        ))                \
    )
    
/*
 * The number of cards that can be moved is 
 * (freecells_number + 1) * 2 ^ (free_stacks_number)
 *
 * See the Freecell FAQ and the source code of PySol
 * 
 * */
#define calc_max_sequence_move(fc_num, fs_num)        \
    ((instance->empty_stacks_fill == FCS_ES_FILLED_BY_ANY_CARD) ? \
        (                                                 \
            (instance->unlimited_sequence_move) ?         \
                INT_MAX :                                 \
                (((fc_num)+1)<<(fs_num))                  \
        ) :                                               \
        ((fc_num)+1)                                      \
    )

    
/*
 * check_and_add_state is defined in dfs.c.
 *
 * DFS stands for Depth First Search which is the type of scan Freecell 
 * Solver uses to solve a given board.
 * */
extern int freecell_solver_check_and_add_state(
    freecell_solver_instance_t * instance, 
    fcs_state_with_locations_t * new_state, 
    fcs_state_with_locations_t * * existing_state,
    int depth);


/*
 * This macro is used by sfs_check_state_begin() which is in turn
 * used in all the tests functions.
 *
 * What it does is allocate some space for the state that is derived from 
 * the current one. The derived state will be manipulated to create the 
 * board after the test was done. 
 * */
#define sfs_check_state_init() \
    ptr_new_state_with_locations = fcs_state_ia_alloc(instance);

/*
 * This macro is used by _all_ the tests to handle some check_and_add_state()
 * return codes. Notice the "else if" at its beginning.
 * */
#define sfs_check_state_finish() \
else if ((check == FCS_STATE_IS_NOT_SOLVEABLE) && ((instance->method == FCS_METHOD_BFS) || (instance->method == FCS_METHOD_A_STAR)||(instance->method == FCS_METHOD_OPTIMIZE))) \
{  \
    /* In A* or BFS, check_and_add_state() returns STATE_IS_NOT_SOLVEABLE \
     * if the state was just found to be unencountered so far, and was    \
     * placed in the queue or priority queue of the scan.                 \
     *                                                                    \
     * If it was indeed placed in the queue, then the move stack leading  \
     * to it was also recorded inside the fcs_state_with_locations_t      \
     * which encapsulates it. Thus, we need a fresh one here.             \
     */           \
    moves = fcs_move_stack_create();  \
} \
else if ((check == FCS_STATE_ALREADY_EXISTS) || (check == FCS_STATE_OPTIMIZED)) \
{             \
    /* The state already exists so we can release its pointer */    \
    fcs_state_ia_release(instance);          \
    if (check == FCS_STATE_OPTIMIZED)  \
    {               \
        moves = fcs_move_stack_create();  \
    }          \
}           \
else if ((check == FCS_STATE_EXCEEDS_MAX_NUM_TIMES) || \
         (check == FCS_STATE_SUSPEND_PROCESS) || \
         (check == FCS_STATE_BEGIN_SUSPEND_PROCESS) || \
         (check == FCS_STATE_EXCEEDS_MAX_DEPTH)) \
{          \
    if ((check == FCS_STATE_SUSPEND_PROCESS)) \
    {              \
        /* Record the moves so far in a move stack in the stack of  \
         * move stacks that belong to the scan.            \
         * */            \
        fcs_move_set_type(temp_move,FCS_MOVE_TYPE_CANONIZE);      \
        fcs_move_stack_push(moves, temp_move);           \
        instance->proto_solution_moves[depth] = moves;    \
    }          \
    else if ( (check == FCS_STATE_BEGIN_SUSPEND_PROCESS) &&  ((instance->method == FCS_METHOD_BFS)||(instance->method == FCS_METHOD_A_STAR)||(instance->method == FCS_METHOD_OPTIMIZE)) )    \
    {             \
        /* Do nothing because those methods expect us to have a move stack present in every state */  \
    }              \
    else           \
    {             \
        fcs_move_stack_destroy(moves);    \
    }         \
    return check;   \
}    


/*
 * A macro that manages the Soft-DFS stuff. It is placed inside
 * sfs_check_state_end() or in move_top_stack_cards_to_founds or
 * move_freecell_cards_to_founds.
 * */
#define sfs_check_state_handle_soft_dfs() \
if (instance->method == FCS_METHOD_SOFT_DFS)         \
{                                                    \
    /* Record the state  */                         \
    instance->soft_dfs_states_to_check[depth][       \
        instance->soft_dfs_num_states_to_check[depth]     \
        ] = ptr_new_state_with_locations;            \
    /* Record its move stack */                        \
    instance->soft_dfs_states_to_check_move_stacks[depth][  \
        instance->soft_dfs_num_states_to_check[depth]    \
        ] = moves;                                        \
    /* Increment the number of recorded states */            \
    instance->soft_dfs_num_states_to_check[depth]++;         \
    /* Create a fresh move stack because the current one was   \
     * recorded and must not be changed at this point */       \
    moves = fcs_move_stack_create();                        \
    /* We are going to exceed the maximum number of recorderd states  \
     * so we should resize it */    \
    if (instance->soft_dfs_num_states_to_check[depth] ==     \
        instance->soft_dfs_max_num_states_to_check[depth])   \
    {                                  \
        instance->soft_dfs_max_num_states_to_check[depth] += FCS_SOFT_DFS_STATES_TO_CHECK_GROW_BY;    \
        instance->soft_dfs_states_to_check[depth] = realloc(     \
            instance->soft_dfs_states_to_check[depth],           \
            sizeof(instance->soft_dfs_states_to_check[depth][0]) *    \
                instance->soft_dfs_max_num_states_to_check[depth]      \
            );          \
        instance->soft_dfs_states_to_check_move_stacks[depth] = realloc(     \
            instance->soft_dfs_states_to_check_move_stacks[depth],           \
            sizeof(instance->soft_dfs_states_to_check_move_stacks[depth][0]) *    \
                instance->soft_dfs_max_num_states_to_check[depth]      \
            );          \
    }        \
    \
}


/*
 * sfs_check_state_begin() is now used by all the tests.
 *
 * */
#define sfs_check_state_begin() \
sfs_check_state_init() \
/* Initialize the derived state from the source state */    \
fcs_duplicate_state(new_state_with_locations, state_with_locations); \
ptr_new_state_with_locations->moves_to_parent = NULL;         \
if ( (instance->method == FCS_METHOD_BFS) || (instance->method == FCS_METHOD_A_STAR) || (instance->method == FCS_METHOD_OPTIMIZE))     \
{       \
    /*  Some A* and BFS parameters that need to be initialized in the derived \
     *  state.               \
     * */        \
    ptr_new_state_with_locations->parent = ptr_state_with_locations;    \
    ptr_new_state_with_locations->moves_to_parent = moves; \
    ptr_new_state_with_locations->depth = depth+1; \
} \
ptr_new_state_with_locations->visited = 0; 



/*
 * This macro is not used by move_top_stack_cards_to_founds and
 * move_freecell_cards_to_founds because of their deducing of 
 * dead-end operations.
 * */
#define sfs_check_state_end()                        \
/* The last move in a move stack should be FCS_MOVE_TYPE_CANONIZE \
 * because it indicates that the order of the stacks and freecells \
 * need to be recalculated \ 
 * */ \
fcs_move_set_type(temp_move,FCS_MOVE_TYPE_CANONIZE); \
fcs_move_stack_push(moves, temp_move);               \
    \
{                                                    \
    fcs_state_with_locations_t * existing_state;     \
    check = freecell_solver_check_and_add_state(     \
        instance,                                    \
        ptr_new_state_with_locations,                \
        &existing_state,                             \
        depth);                                      \
    /* In Soft-DFS I'd like to save memory by pointing each state  \
     * to its cached state */   \
    if ((instance->method == FCS_METHOD_SOFT_DFS) && \
        (check == FCS_STATE_ALREADY_EXISTS))         \
    {                                                    \
        ptr_new_state_with_locations = existing_state;    \
    }                                                    \
}                                                    \
sfs_check_state_handle_soft_dfs()                    \
                                                     \
                                                     \
/* This is for Hard-DFS: we put all the intermediate \
 * move stacks in proto_solution_moves */            \
                                                     \
if (check == FCS_STATE_WAS_SOLVED)                   \
{                                                    \
    instance->proto_solution_moves[depth] = moves;   \
    return FCS_STATE_WAS_SOLVED;                     \
}                                                    \
sfs_check_state_finish();


/*
 *  Those are some macros to make it easier for the programmer.
 * */
#define state_with_locations (*ptr_state_with_locations)
#define state (ptr_state_with_locations->s)
#define new_state_with_locations (*ptr_new_state_with_locations)
#define new_state (ptr_new_state_with_locations->s)


/*
    This macro checks if the top card in the stack is a flipped card
    , and if so flips it so its face is up.
  */
#define fcs_flip_top_card(stack) \
                    {            \
                        int cards_num;         \
                        cards_num = fcs_stack_len(new_state,stack);    \
                                                                \
                        if (cards_num > 0)              \
                        {                \
                            if (fcs_card_get_flipped(fcs_stack_card(new_state,stack,cards_num-1)) == 1)        \
                            {               \
                                fcs_flip_stack_card(new_state,stack,cards_num-1);            \
                                fcs_move_set_type(temp_move, FCS_MOVE_TYPE_FLIP_CARD);        \
                                fcs_move_set_src_stack(temp_move, stack);           \
                                    \
                                fcs_move_stack_push(moves, temp_move);              \
                            }          \
                        }          \
                    }          \


extern int freecell_solver_sfs_simple_simon_move_sequence_to_founds(
        freecell_solver_instance_t * instance,
        fcs_state_with_locations_t * ptr_state_with_locations,
        int depth,
        int num_freestacks,
        int num_freecells,
        int ignore_osins
        );
extern int freecell_solver_sfs_simple_simon_move_sequence_to_true_parent(
        freecell_solver_instance_t * instance,
        fcs_state_with_locations_t * ptr_state_with_locations,
        int depth,
        int num_freestacks,
        int num_freecells,
        int ignore_osins
        );

extern int freecell_solver_sfs_simple_simon_move_whole_stack_sequence_to_false_parent(
        freecell_solver_instance_t * instance,
        fcs_state_with_locations_t * ptr_state_with_locations,
        int depth,
        int num_freestacks,
        int num_freecells,
        int ignore_osins
        );

extern int freecell_solver_sfs_simple_simon_move_sequence_to_true_parent_with_some_cards_above(
        freecell_solver_instance_t * instance,
        fcs_state_with_locations_t * ptr_state_with_locations,
        int depth,
        int num_freestacks,
        int num_freecells,
        int ignore_osins
        );

extern int freecell_solver_sfs_simple_simon_move_sequence_with_some_cards_above_to_true_parent(
        freecell_solver_instance_t * instance,
        fcs_state_with_locations_t * ptr_state_with_locations,
        int depth,
        int num_freestacks,
        int num_freecells,
        int ignore_osins
        );

extern int freecell_solver_sfs_simple_simon_move_sequence_with_junk_seq_above_to_true_parent_with_some_cards_above(
        freecell_solver_instance_t * instance,
        fcs_state_with_locations_t * ptr_state_with_locations,
        int depth,
        int num_freestacks,
        int num_freecells,
        int ignore_osins
        );

extern int freecell_solver_sfs_simple_simon_move_whole_stack_sequence_to_false_parent_with_some_cards_above(
        freecell_solver_instance_t * instance,
        fcs_state_with_locations_t * ptr_state_with_locations,
        int depth,
        int num_freestacks,
        int num_freecells,
        int ignore_osins
        );

extern int freecell_solver_sfs_simple_simon_move_sequence_to_parent_on_the_same_stack(
        freecell_solver_instance_t * instance,
        fcs_state_with_locations_t * ptr_state_with_locations,
        int depth,
        int num_freestacks,
        int num_freecells,
        int ignore_osins
        );

#endif /* __TESTS_H */
