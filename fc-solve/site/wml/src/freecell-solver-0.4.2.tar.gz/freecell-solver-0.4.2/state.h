/*
 * state.h - header file for state functions and macros for Freecell Solver
 *
 * Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000
 *
 * This file is in the public domain (it's uncopyrighted).
 */
#include "config.h"

#ifndef __STATE_H
#define __STATE_H

#ifdef _cplusplus
extern "C" {
#endif

#ifdef DEBUG_STATES

struct struct_card_t
{
    short card_num;
    short deck;
};

typedef struct struct_card_t card_t;

extern card_t empty_card;

struct struct_stack_t
{
    int num_cards;
    card_t cards[19];
};

typedef struct struct_stack_t fc_stack_t;

struct struct_state_t
{
    fc_stack_t stacks[8];
    card_t freecells[4];
    int decks[4];
};

typedef struct struct_state_t state_t;

#define stack_len(state, s) \
    ( (state).stacks[(s)].num_cards )    

#define stack_card_num(state, s, c) \
    ( (state).stacks[(s)].cards[(c)].card_num )

#define stack_card_deck(state, s, c) \
    ( (state).stacks[(s)].cards[(c)].deck )

#define stack_card(state, s, c) \
    ( (state).stacks[(s)].cards[(c)] )

#define card_card_num(card) \
    ( (card).card_num )

#define card_deck(card) \
    ( (card).deck )

#define freecell_card(state, f) \
    ( (state).freecells[(f)] )
    
#define freecell_card_num(state, f) \
    ( (state).freecells[(f)].card_num )
    
#define freecell_card_deck(state, f) \
    ( (state).freecells[(f)].deck )

#define deck_value(state, d) \
    ( (state).decks[(d)] )

#define increment_deck(state, d) \
    ( (state).decks[(d)]++ )

#define set_deck(state, d, value) \
    ( (state).decks[(d)] = (value) )
    
#define pop_stack_card(state, s, into) \
    into = (state).stacks[(s)].cards[(state).stacks[(s)].num_cards-1]; \
    (state).stacks[(s)].cards[(state).stacks[(s)].num_cards-1] = empty_card; \
    (state).stacks[(s)].num_cards--;
    
#define push_stack_card_into_stack(state, ds, ss, sc) \
    (state).stacks[(ds)].cards[(state).stacks[(ds)].num_cards] = (state).stacks[(ss)].cards[(sc)]; \
    (state).stacks[(ds)].num_cards++;
    
#define push_card_into_stack(state, ds, from) \
    (state).stacks[(ds)].cards[(state).stacks[(ds)].num_cards] = (from); \
    (state).stacks[(ds)].num_cards++;

#define duplicate_state(dest, src) \
    (dest) = (src);

#define put_card_in_freecell(state, f, card) \
    (state).freecells[(f)] = (card);

#define empty_freecell(state, f) \
    (state).freecells[(f)] = empty_card;

#define card_set_deck(card, d) \
    (card).deck = (d) ;

#define card_set_num(card, num) \
    (card).card_num = (num);
    
#elif defined(COMPACT_STATES)

typedef char card_t;
/*
 * Card:
 * Bits 0-3 - Card Number
 * Bits 4-5 - Deck
 * 
 */
extern card_t empty_card;

struct struct_state_t
{
    char data[168];
};
/*
 * Stack: 0 - Number of cards 1-19 - Cards
 * Stacks: stack_num*20 where stack_num >= 0 and stack_num <= 7
 * Bytes 160-163 - Freecells
 * Bytes 164-167 - Decks
 */

typedef struct struct_state_t state_t;

#define card_card_num(card) \
    ( (card) & 0x0F )

#define card_deck(card) \
    ( (card) >> 4 )

#define stack_len(state, s) \
    ( (state).data[s*20] )

#define stack_card(state, s, c) \
    ( (state).data[(s)*20+(c)+1] )

#define stack_card_num(state, s, c) \
    ( card_card_num(stack_card((state),(s),(c))) )

#define stack_card_deck(state, s, c) \
    ( card_deck(stack_card((state),(s),(c))) )

#define freecell_card(state, f) \
    ( (state).data[160+(f)] )

#define freecell_card_num(state, f) \
    ( card_card_num(freecell_card((state),(f))) )

#define freecell_card_deck(state, f) \
    ( card_deck(freecell_card((state),(f))) )

#define deck_value(state, d) \
    ( (state).data[164+(d)])

#define increment_deck(state, d) \
    ( (state).data[164+(d)]++ )

#define set_deck(state, d, value) \
    ( (state).data[164+(d)] = (value) )

#define pop_stack_card(state, s, into) \
    into = stack_card((state), (s), (stack_len((state), (s))-1)); \
    (state).data[((s)*20)+1+(stack_len((state), (s))-1)] = empty_card; \
    (state).data[(s)*20]--;
    
#define push_card_into_stack(state, ds, from) \
    (state).data[(ds)*20+1+stack_len((state), (ds))] = (from); \
    (state).data[(ds)*20]++;

#define push_stack_card_into_stack(state, ds, ss, sc) \
    push_card_into_stack((state), (ds), stack_card((state), (ss), (sc)))

#define duplicate_state(dest, src) \
    (dest) = (src);

#define put_card_in_freecell(state, f, card) \
    (state).data[160+(f)] = (card);

#define empty_freecell(state, f) \
    put_card_in_freecell((state), (f), empty_card)

#define card_set_num(card, num) \
    (card) = (((card)&0xF0)|(num));

#define card_set_deck(card, deck) \
    (card) = (((card)&0x0F)|((deck)<<4));
    
#endif

extern void canonize_state(state_t * state);
#ifdef DIRECT_STATE_STORAGE
extern int state_compare(const void * s1, const void * s2);
extern int state_compare_with_context(const void * s1, const void * s2, void * context);
#elif defined(INDIRECT_STATE_STORAGE)
extern int state_compare_indirect(const void * s1, const void * s2);
extern int state_compare_indirect_with_context(const void * s1, const void * s2, void * context);
#endif
extern void state_init(state_t * state);
extern state_t initial_user_state_to_c(char * string);
extern char * state_as_string(state_t * state);
extern int check_state_validity(state_t * state, card_t * misplaced_card);

#ifdef _cplusplus
}
#endif

#endif /* __STATE_H */
