#ifndef __FCS_ISA_H
#define __FCS_ISA_H

#include "state.h"

extern void state_ia_init(void);
extern state_t * state_ia_alloc(void);
extern void state_ia_release(void);
extern void state_ia_finish(void);



#endif
