/*
 * state.c - state functions module for Freecell Solver
 *
 * Written by Shlomi Fish (shlomif@vipe.technion.ac.il), 2000
 *
 * This file is in the public domain (it's uncopyrighted).
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "config.h"
#include "state.h"
#include "card.h"

#ifdef DEBUG_STATES

card_t empty_card = {0,0};

#elif defined(COMPACT_STATES)

card_t empty_card = 0;

#endif

int card_compare(const void * card1, const void * card2)
{
    const card_t * c1 = (const card_t *)card1;
    const card_t * c2 = (const card_t *)card2;

    if (card_card_num(*c1) > card_card_num(*c2))
    {
        return 1;
    }
    else if (card_card_num(*c1) < card_card_num(*c2))
    {
        return -1;
    }
    else
    {
        if (card_deck(*c1) > card_deck(*c2))
        {
            return 1;
        }
        else if (card_deck(*c1) < card_deck(*c2))
        {
            return -1;
        }
        else
        {
            return 0;
        }            
    }
}

#ifdef DEBUG_STATES
int stack_compare(const void * s1, const void * s2)
{
    card_t card1 = ((const fc_stack_t *)s1)->cards[0];
    card_t card2 = ((const fc_stack_t *)s2)->cards[0]; 

    return card_compare(&card1, &card2);
}
#elif defined(COMPACT_STATES)
int stack_compare(const void * s1, const void * s2)
{
    card_t card1 = ((card_t*)s1)[1];
    card_t card2 = ((card_t*)s2)[1];

    return card_compare(&card1, &card2);
}
#endif

#ifdef DEBUG_STATES
void canonize_state(state_t * state)
{
    qsort(state->stacks, 8, sizeof(fc_stack_t), stack_compare);

    qsort(state->freecells, 4, sizeof(card_t), card_compare);
}
#elif defined(COMPACT_STATES)
void canonize_state(state_t * state)
{
    qsort(state->data, 8, sizeof(card_t)*20, stack_compare);

    qsort(&(state->data[160]), 4, sizeof(card_t), card_compare);
}
#endif

void state_init(state_t * state)
{
    memset((void*)state, 0, sizeof(state_t));
}

#ifdef DIRECT_STATE_STORAGE
int state_compare(const void * s1, const void * s2)
{
    return memcmp(s1,s2,sizeof(state_t));
}

int state_compare_with_context(const void * s1, const void * s2, void * context)
{
    return memcmp(s1,s2,sizeof(state_t));
}
#elif defined(INDIRECT_STATE_STORAGE)
int state_compare_indirect(const void * s1, const void * s2)
{
    return memcmp(*(state_t * *)s1, *(state_t * *)s2, sizeof(state_t));
}

int state_compare_indirect_with_context(const void * s1, const void * s2, void * context)
{
    return memcmp(*(state_t * *)s1, *(state_t * *)s2, sizeof(state_t));
}
#endif

static char * freecells_prefixes[] = { "FC:", "Freecells:", "Freecell:", ""};
static char * foundations_prefixes[] = { "Decks:", "Deck:", "Founds:", "Foundations:", "Foundation:", "Found:", ""};

#ifdef WIN32
#define strncasecmp(a,b,c) (strnicmp((a),(b),(c)))
#endif

state_t initial_user_state_to_c(char * string)
{
    state_t ret;

    int s,c;
    char * str;
    card_t card;
    int first_line;
    
    int prefix_found;
    char * * prefixes;
    int i;

    state_init(&ret);
    str = string;

    first_line = 1;
   
    for(s=0;s<8;s++)
    {
        /* Move to the next stack */
        if (!first_line)
        {
            while((*str) != '\n')
            {
                str++;
            }
            str++;
        }
        first_line = 0;

	prefixes = freecells_prefixes;
        prefix_found = 0;
        for(i=0;prefixes[i][0] != '\0'; i++)
        {
            if (!strncasecmp(str, prefixes[i], strlen(prefixes[i])))
            {
                prefix_found = 1;
                str += strlen(prefixes[i]);
                break;
            }
        }
        
        if (prefix_found)
        {
            for(c=0;c<4;c++)
            {
                empty_freecell(ret, c);
            }
            for(c=0;c<4;c++)
            {
                if (c!=0)
                {
                    while(((*str) != ' ') && ((*str) != '\t') && ((*str) != '\n') && ((*str) != '\r'))
                    {
                        str++;
                    }
                    if ((*str == '\n') || (*str == '\r'))
                    {
                        break;
                    }
                    str++;
                }

                while ((*str == ' ') || (*str == '\t'))
                {
                    str++;
                }
                
                card = card_user2perl(str);

                put_card_in_freecell(ret, c, card);
            }

            while ((*str != '\n') && (*str != '\0'))
            {
                str++;
            }
            s--;
            continue;
        }
        
        prefixes = foundations_prefixes;
        prefix_found = 0;
        for(i=0;prefixes[i][0] != '\0'; i++)
        {
            if (!strncasecmp(str, prefixes[i], strlen(prefixes[i])))
            {
                prefix_found = 1;
                str += strlen(prefixes[i]);
                break;
            }
        }
    
        if (prefix_found)
        {
            int d;
            
            for(d=0;d<4;d++)
            {
                set_deck(ret, d, 0);
            }
            while (1)
            {
                while((*str == ' ') || (*str == '\t'))
                    str++;
                if ((*str == '\n') || (*str == '\r'))
                    break;
                d = u2p_deck(str);
                str++;
                while (*str == '-')
                    str++;
                c = u2p_card_number(str);
                while ((*str != ' ') && (*str != '\t') && (*str != '\n') && (*str != '\r'))
                    str++;

                set_deck(ret, d, c);
            }
            s--;
            continue;
        }
        
        for(c=0;c<19;c++)
        {
            /* Move to the next card */
            if (c!=0)
            {
                while(
                    ((*str) != ' ') && 
                    ((*str) != '\t') && 
                    ((*str) != '\n') && 
                    ((*str) != '\r')
                )
                {
                    str++;
                }
                if ((*str == '\n') || (*str == '\r'))
                {
                    break;
                }
            }

            while ((*str == ' ') || (*str == '\t'))
            {
                str++;
            }
            if ((*str == '\n') || (*str == '\r'))
            {
                break;
            }
            card = card_user2perl(str);

            push_card_into_stack(ret, s, card);
        }        
    }

    return ret;
}

int check_state_validity(state_t * state, card_t * misplaced_card)
{
    int cards[4][14];
    int c, s, d, f;

    /* Initialize all cards to 0 */
    for(d=0;d<4;d++)
    {
        for(c=1;c<=13;c++)
        {
            cards[d][c] = 0;
        }
    }

    /* Mark the cards in the decks */
    for(d=0;d<4;d++)
    {
        for(c=1;c<=deck_value(*state, d);c++)
        {
            cards[d][c]++;
        }
    }
    
    /* Mark the cards in the freecells */
    for(f=0;f<4;f++)
    {
        if (freecell_card_num(*state, f) != 0)
        {
            cards
                [freecell_card_deck(*state, f)]
                [freecell_card_num(*state, f)] ++;
        }
    }
    
    /* Mark the cards in the stacks */
    for(s=0;s<8;s++)
    {
        for(c=0;c<stack_len(*state,s);c++)
        {
            cards
                [stack_card_deck(*state, s, c)]
                [stack_card_num(*state, s, c)] ++;
        }
    }
    
    /* Now check if there are extra or missing cards */
    
    for(d=0;d<4;d++)
    {
        for(c=1;c<=13;c++)
        {
            if (cards[d][c] != 1)
            {
                card_set_deck(*misplaced_card, d);
                card_set_num(*misplaced_card, c);
                return (cards[d][c] == 0) ? 1 : 2;
            }
        }
    }
    
    return 0;
}

char * state_as_string(state_t * state)
{
    char freecells[4][10], decks[4][10], stack_card[10];
    int a, card_num_is_null;
    int max_num_cards, s, card_num;

    char string[2000];
    for(a=0;a<4;a++)
    {
        p2u_card_number( (short)(deck_value(*state, a)), decks[a], &card_num_is_null);
        if (decks[a][0] == ' ')
            decks[a][0] = '0';
    }

    sprintf(string, "%3s %3s %3s %3s        H-%1s S-%1s D-%1s C-%1s\n",
            card_perl2user(freecell_card(*state, 0), freecells[0]),
            card_perl2user(freecell_card(*state, 1), freecells[1]),
            card_perl2user(freecell_card(*state, 2), freecells[2]),
            card_perl2user(freecell_card(*state, 3), freecells[3]),
            decks[0],
            decks[1],
            decks[2],
            decks[3]);

    sprintf(string+strlen(string), "--- --- --- ---\n");
    sprintf(string+strlen(string), "\n --  --  --  --  --  --  --  --\n");

    max_num_cards = 0;
    for(s=0;s<8;s++)
    {
        if (stack_len(*state, s) > max_num_cards)
        {
            max_num_cards = stack_len(*state, s);
        }
    }

    for(card_num=0;card_num<max_num_cards;card_num++)
    {
        for(s = 0; s<8; s++)
        {
            if (card_num >= stack_len(*state, s))
            {
                strcat(string, "    ");
            }
            else
            {
                sprintf(string+strlen(string), "%3s ", card_perl2user( stack_card(*state, s, card_num), stack_card));

            }
        }
        strcat(string, "\n");
    }
    return strdup(string);
}
        

