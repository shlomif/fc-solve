/* fcs_isa.c - Freecell Solver Indirect State Allocation Routines
   
   Written by Shlomi Fish, 2000
   This file is distributed under the public domain.
*/

#include "config.h"
#ifdef INDIRECT_STATE_STORAGE


#include "state.h"
#include <malloc.h>



static state_t * * state_packs;
static int max_num_state_packs=0;
static int num_state_packs=0;
static int num_states_in_last_pack=0;

static int state_pack_len=0;

void state_ia_init(void)
{
    max_num_state_packs = IA_STATE_PACKS_GROW_BY;
    state_packs = (state_t * *)malloc(sizeof(state_t *) * max_num_state_packs);
    num_state_packs = 1;
    state_pack_len = 0x010000 / sizeof(state_t);
    state_packs[0] = malloc(state_pack_len*sizeof(state_t));

    num_states_in_last_pack = 0;
}

state_t * state_ia_alloc(void)
{
    if (num_states_in_last_pack == state_pack_len)
    {
        if (num_state_packs == max_num_state_packs)
        {
            max_num_state_packs += IA_STATE_PACKS_GROW_BY;
            state_packs = (state_t * *)realloc(state_packs, sizeof(state_t *) * max_num_state_packs);
        }
        state_packs[num_state_packs] = malloc(state_pack_len*sizeof(state_t));
        num_state_packs++;
        num_states_in_last_pack = 0;
    }
    return &state_packs[num_state_packs-1][num_states_in_last_pack++];
}

void state_ia_release(void)
{
    num_states_in_last_pack--;
}

void state_ia_finish(void)
{
    int a;
    for(a=0;a<num_state_packs;a++)
    {
        free(state_packs[a]);
    }
    free(state_packs);
}
#endif
