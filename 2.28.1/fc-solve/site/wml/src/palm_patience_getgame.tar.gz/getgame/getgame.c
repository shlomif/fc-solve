#include <PalmOS.h>
#include <stdarg.h>
#include "rsrc.h"

#if 0
void msg(const char *str, ...)
{
	int n, len;
	char buf[100];
	va_list ap;
	static int row = 15;
	static int pos = 0;

	va_start(ap, str);
	StrVPrintF(buf, str, ap);
	n = StrLen(buf);
	len = FntCharsWidth(buf, n);
	if (pos + len >= 160) {
		pos = 0;
		row += 10;
	}
	WinDrawChars(buf, n, pos, row);
	pos += len;
	va_end(ap);
}
#endif

Boolean MainFormHandleEvent(EventPtr event)
{
	Boolean handled = false;
	void go();

	switch (event->eType) {

	case ctlSelectEvent:
		if (event->data.ctlEnter.controlID == GoButton) {
			go();
		}
		handled = true;
		break;

	case frmOpenEvent:
		FrmDrawForm(FrmGetActiveForm());
		go();                   /* no need to push the button */
		handled = true;
		break;

	case nilEvent:
		handled = true;
		break;
	}

	return handled;
}

Boolean ApplicationHandleEvent(EventPtr event)
{
	FormPtr form;
	UInt16 formId;

	if (event->eType != frmLoadEvent) {
		return false;
	}

	formId = event->data.frmLoad.formID;
	form = FrmInitForm(formId);
	FrmSetActiveForm(form);
	if (formId == MainForm) {
		FrmSetEventHandler(form, MainFormHandleEvent);
	}
	return true;
}

UInt32 PilotMain(UInt16 cmd, void *cmdPBP, UInt16 launchFlags)
{
	EventType event;
	Err error;

	if (cmd != sysAppLaunchCmdNormalLaunch) {
		return 0;
	}

	FrmGotoForm(MainForm);

	do {
		EvtGetEvent(&event, -1);

		if (SysHandleEvent(&event)) {
			continue;
		}
		if (MenuHandleEvent(NULL, &event, &error)) {
			continue;
		}
		if (ApplicationHandleEvent(&event)) {
			continue;
		}
		FrmDispatchEvent(&event);
	} while (event.eType != appStopEvent);

	return 0;
}

/* We need all this stuff to extract the preference information.. */

typedef int PatI;
typedef long PatL;
typedef unsigned long PatUL;
typedef short PatS;
typedef unsigned long ULong;

#define MAX_GAMES   32

char Rankchr[] = " A23456789TJQK";
char Suitchr[] = "CDHS";

#define JACK    11
#define QUEEN   12
#define KING    13
#define ACE     14

#define CLUB        0x00
#define DIAMOND     0x10
#define HEART       0x20
#define SPADE       0x30
#define NextSuit(s) ((s) + 0x10)

#define Suit(c)     ((c) & 0x70)
#define Rank(c)     ((c) & 0x0f)
#define MakeCard(t, s, r) ((t) | (s) | (r))

#define CardPtr(i) ((i) == NullIndex ? (CardType *)0 : &(Game.deck[i]))
#define CardStackPtr(i) ((i) == NullIndex ? (CardStackType *)0 : (&Game.stacks[i]))

typedef unsigned char Card;
typedef unsigned char CardIndex;
typedef unsigned char CardStackIndex;
typedef unsigned char CardHistoryKind;
typedef unsigned char CardBool;

#define NullIndex 0xff

typedef struct {
	CardIndex next, prev;
	Card card;
	unsigned int face:1;
	unsigned int show:2;
} CardType;

typedef struct {
	PatS x, y;
} PatCoord;

typedef struct {
	PatCoord pos;
	CardIndex first, last;
	Card empty;
	unsigned char face_up;
	unsigned char back_up;
	unsigned char pack_up;
	unsigned int display:3;
	unsigned int dirty:1;
	unsigned int horizontal:1;
	unsigned int select_card:1;
	signed char face_off;
	signed char back_off;
	signed char pack_off;
} CardStackType;

typedef struct {
	PatL serial;
	CardHistoryKind kind;
	union {
		struct {
			CardStackIndex stack;
			CardIndex card;
			unsigned int face:1;
		} turn;
		struct {
			CardStackIndex source;
			CardStackIndex dest;
			CardIndex before;
			CardIndex first;
			CardIndex last;
		} move;
		struct {
			CardStackIndex stack;
			PatL seed;
		} shuffle;
	} u;
} CardHistoryType;

typedef struct {
	CardStackIndex stack;
	PatS pos;
} CardHintType;

#define MAX_CARDS       104
#define MAX_STACKS      53
#define MAX_HISTORY     1024
#define MAX_HINT        5
#define HISTORY_CHUNK   32
#define HISTORY_CHUNKS  (MAX_HISTORY / HISTORY_CHUNK)

typedef struct {
	CardHistoryType history[HISTORY_CHUNK];
	PatI historyTop;
} HistoryChunkType;

typedef struct {
	PatUL won;
	PatUL lost;
} GameStatType;

typedef struct {
	CardType deck[MAX_CARDS];
	CardStackType stacks[MAX_STACKS];
	CardHintType hints[MAX_HINT];
	PatS nhint;
	CardIndex ncards;
	CardStackIndex nstacks;
	PatL historySerial;
	PatS historyTop;
	CardBool playing;
	CardBool queryMode;
	CardBool queryDirty;
	CardBool alwaysAuto;
	CardBool alwaysDirty;
	CardBool leftHanded;
	PatS gameKind;
	PatS gameSeed;
	PatS randomSeed;
	CardStackIndex srcStack;
	CardIndex srcCard;
	HistoryChunkType historyChunk;
	ULong historyID[HISTORY_CHUNKS];
	GameStatType stats[MAX_GAMES];
} GameType;

GameType Game;

DmOpenRef Db;

#define DbCreator 'TomH'
#define DbType 'moo '
#define PatienceFileCreator 'Pati'
#define PatienceVersionNum 6

PatL Random(PatL max)
{
	PatL v;

	v = Game.randomSeed;
	if (!v) {
		v = 1;
	}
	Game.randomSeed = SysRandom(v);
	v = Game.randomSeed;
	if (max) {
		if (v < 0) {
			v = -v;
		}
		v %= max;
	}
	return v;
}

void SRandom(PatL seed)
{
	Game.randomSeed = seed;
}

void OpenDb(void)
{
	Err err;

	Db = DmOpenDatabaseByTypeCreator(DbType, DbCreator, dmModeReadWrite);
	if (!Db) {
		err = DmCreateDatabase(0, "PatGame", DbCreator, DbType, false);
		if (err) {
			return;
		}
		Db = DmOpenDatabaseByTypeCreator(DbType, DbCreator,
						 dmModeReadWrite);
	}
}

void CloseDb(void)
{
	DmCloseDatabase(Db);
}

void WriteDb(UInt8 *buf, UInt32 len)
{
	UInt16 at;
	MemHandle h;
	MemPtr p;

	if (DmNumRecords(Db) > 0) {
		DmRemoveRecord(Db, 0);
	}

	at = 0;
	h = DmNewRecord(Db, &at, len);
	if (h == NULL) {
		return;
	}

	p = MemHandleLock(h);
	DmWrite(p, 0, buf, len);
	MemHandleUnlock(h);
	DmReleaseRecord(Db, at, true);
}

void CardMakeDeck(Card first, Card last, PatI ndecks)
{
	PatI n;
	Card r, s, c;
	CardType *cp = 0;
	CardIndex card;
	CardStackType *sp;

	card = 0;
	for (n = 0; n < ndecks; n++) {
		for (s = Suit(first); s <= Suit(last); s = NextSuit(s)) {
			for (r = Rank(first); r <= Rank(last); r++) {
				c = MakeCard(0, s, r);
				cp = CardPtr(card);
				cp->card = c;
				cp->next = card + 1;
				card++;
			}
		}
	}
	sp = CardStackPtr(0);
	cp->next = NullIndex;
	sp->first = 0;
	sp->last = card - 1;
}

void CardShuffle(CardStackIndex stack, CardBool remember)
{
	char *s, buf[3 * MAX_CARDS + 1];
	CardIndex deck[MAX_CARDS];
	PatI n;
	PatI i, j;
	CardStackType *sp;
	Card card;
	CardType *cp;

	SRandom(Game.gameSeed);
	sp = CardStackPtr(stack);
	for (n = 0, card = sp->first; card != NullIndex; n++, card = cp->next) {
		cp = CardPtr(card);
		deck[n] = card;
	}

	for (i = 0; i < n; i++) {
		j = Random(n - i) + i;
		card = deck[i];
		deck[i] = deck[j];
		deck[j] = card;
	}

	/* Dump the cards. */

	s = buf;
	for (i = n - 1; i >= 0; i--) {
		cp = CardPtr(deck[i]);
		StrPrintF(s, "%c%c\n", Rankchr[Rank(cp->card)],
			  Suitchr[Suit(cp->card) >> 4]);
		s += 3;
	}
	i = s - buf + 1;
	OpenDb();
	WriteDb(buf, i);
	CloseDb();
}

void go()
{
	EventType e;

	PrefGetAppPreferencesV10(PatienceFileCreator, PatienceVersionNum,
				 &Game, sizeof(GameType));
	CardMakeDeck(MakeCard(0, CLUB, 1), MakeCard(0, SPADE, KING), 1);
	CardShuffle(0, 0);

	/* Exit immediately. */

	MemSet(&e, sizeof(EventType), 0);
	e.eType = appStopEvent;
	EvtAddEventToQueue(&e);
}
