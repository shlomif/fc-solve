#define MainForm   1000
#define GoButton   1001
