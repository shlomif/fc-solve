#include <libguile.h>
#include <guile/gh.h>
#include "fcs_user.h"


static long freecell_solver_guile_tag;

struct freecell_solver_guile
{
    void * solver;    
};

typedef struct freecell_solver_guile fcs_guile_t;

static SCM
freecell_solver_guile_make(void)
{
    fcs_guile_t * fcs_guile;

    fcs_guile = (fcs_guile_t *)scm_must_malloc(sizeof (fcs_guile_t), "freecell_solver_guile");
    fcs_guile->solver = freecell_solver_user_alloc();

    SCM_RETURN_NEWSMOB(freecell_solver_guile_tag, fcs_guile);
}
   
static SCM 
freecell_solver_guile_mark(SCM  fcs_guile_smob)
{
    return SCM_BOOL_F;
}

static scm_sizet
freecell_solver_guile_free(SCM fcs_guile_smob)
{
    fcs_guile_t * fcs_guile;
    
    fcs_guile = (fcs_guile_t *) SCM_CDR(fcs_guile_smob);

    freecell_solver_user_free(fcs_guile->solver);

    scm_must_free(fcs_guile);

    return sizeof(*fcs_guile);
}

static int 
freecell_solver_guile_print(SCM fcs_guile_smob, SCM port, scm_print_state * pstate)
{
    fcs_guile_t * fcs_guile;

    fcs_guile = (fcs_guile_t *) SCM_CDR(fcs_guile_smob);

    scm_puts ("#<freecell_solver>", port);

    /* non-zero means success */
    return 1;
}

static SCM
freecell_solver_guile_solve(SCM fcs_guile_smob, SCM state_string)
{
    fcs_guile_t * fcs_guile;
    int ret;

    fcs_guile = (fcs_guile_t *) SCM_CDR(fcs_guile_smob);

    ret = freecell_solver_user_solve_board(fcs_guile->solver, SCM_CHARS(state_string));

    return gh_int2scm(ret);
}

static SCM
freecell_solver_guile_get_moves_left(SCM fcs_guile_smob)
{
    fcs_guile_t * fcs_guile;

    fcs_guile = (fcs_guile_t *) SCM_CDR(fcs_guile_smob);

    return gh_int2scm(freecell_solver_user_get_moves_left(fcs_guile->solver));
}

static SCM
freecell_solver_guile_get_next_move(SCM fcs_guile_smob)
{
    fcs_guile_t * fcs_guile;
    fcs_move_t move;
    int ret;

    fcs_guile = (fcs_guile_t *) SCM_CDR(fcs_guile_smob);

    ret = freecell_solver_user_get_next_move(fcs_guile->solver, &move);

    if (ret != 0)
    {
        return gh_bool2scm(0);
    }

    return gh_cons(gh_int2scm(move.c[FCS_MOVE_TYPE]), 
           gh_cons(gh_int2scm(move.c[FCS_MOVE_SRC]),
           gh_cons(gh_int2scm(move.c[FCS_MOVE_DEST]),
           gh_cons(gh_int2scm(move.c[FCS_MOVE_NUM_CARDS_IN_SEQ]), SCM_EOL))));
}

static SCM
freecell_solver_guile_limit_iterations(SCM fcs_guile_smob, SCM max_iters)
{
    fcs_guile_t * fcs_guile;
    
    fcs_guile = (fcs_guile_t *) SCM_CDR(fcs_guile_smob);
    
    freecell_solver_user_limit_iterations(fcs_guile->solver, gh_scm2int(max_iters));

    return gh_bool2scm(1);
}

static SCM
freecell_solver_guile_resume(SCM fcs_guile_smob, SCM state_string)
{
    fcs_guile_t * fcs_guile;
    int ret;

    fcs_guile = (fcs_guile_t *) SCM_CDR(fcs_guile_smob);

    ret = freecell_solver_user_resume_solution(fcs_guile->solver);

    return gh_int2scm(ret);
}


void init_freecell_solver_guile_type (void)
{
    freecell_solver_guile_tag = scm_make_smob_type("freecell_solver", sizeof(struct freecell_solver_guile));

    scm_set_smob_mark(freecell_solver_guile_tag, freecell_solver_guile_mark);
    scm_set_smob_free(freecell_solver_guile_tag, freecell_solver_guile_free);
    scm_set_smob_print(freecell_solver_guile_tag, freecell_solver_guile_print);
    
    scm_make_gsubr ("freecell-solver-make-instance", 0, 0, 0, freecell_solver_guile_make);
    scm_make_gsubr ("freecell-solver-solve", 2, 0, 0, freecell_solver_guile_solve);
    scm_make_gsubr ("freecell-solver-get-moves-left", 1, 0, 0, freecell_solver_guile_get_moves_left);
    scm_make_gsubr ("freecell-solver-get-next-move", 1, 0, 0, freecell_solver_guile_get_next_move);
    scm_make_gsubr ("freecell-solver-limit-iterations", 2, 0, 0, freecell_solver_guile_limit_iterations);
    scm_make_gsubr ("freecell-solver-resume", 1, 0, 0, freecell_solver_guile_resume);


    gh_define("FCS_STATE_WAS_SOLVED", gh_int2scm(FCS_STATE_WAS_SOLVED));
    gh_define("FCS_STATE_IS_NOT_SOLVEABLE", gh_int2scm(FCS_STATE_IS_NOT_SOLVEABLE));
    gh_define("FCS_STATE_SUSPEND_PROCESS", gh_int2scm(FCS_STATE_SUSPEND_PROCESS));
    gh_define("FCS_MOVE_TYPE_STACK_TO_STACK", gh_int2scm(FCS_MOVE_TYPE_STACK_TO_STACK));
    gh_define("FCS_MOVE_TYPE_STACK_TO_FREECELL", gh_int2scm(FCS_MOVE_TYPE_STACK_TO_FREECELL));
    gh_define("FCS_MOVE_TYPE_FREECELL_TO_STACK", gh_int2scm(FCS_MOVE_TYPE_FREECELL_TO_STACK));
    gh_define("FCS_MOVE_TYPE_FREECELL_TO_FREECELL", gh_int2scm(FCS_MOVE_TYPE_FREECELL_TO_FREECELL));
    gh_define("FCS_MOVE_TYPE_STACK_TO_FOUNDATION", gh_int2scm(FCS_MOVE_TYPE_STACK_TO_FOUNDATION));
    gh_define("FCS_MOVE_TYPE_FREECELL_TO_FOUNDATION", gh_int2scm(FCS_MOVE_TYPE_FREECELL_TO_FOUNDATION));
}
