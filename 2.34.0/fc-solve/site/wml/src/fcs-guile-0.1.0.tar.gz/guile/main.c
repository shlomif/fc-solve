#include "fcs-guile.h"
#include <guile/gh.h>

void main_prog(int argc, char * argv[])
{
    init_freecell_solver_guile_type();
    gh_eval_file(argv[1]);
}

int main(int argc, char * argv[])
{
    gh_enter(argc, argv, main_prog);
    return 0;
}
