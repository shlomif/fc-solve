#ifndef __FCS_GUILE_H
#define __FCS_GUILE_H

#ifdef __cplusplus
extern "C" {
#endif

extern void init_freecell_solver_guile_type(void);
    
#ifdef __cplusplus
}
#endif

#endif /* __FCS_GUILE_H */
