from distutils.core import setup, Extension

module1 = Extension('FreecellSolver',
                    define_macros = [('MAJOR_VERSION', '1'),
                                     ('MINOR_VERSION', '0')],
                    include_dirs = ['/usr/include/freecell-solver'],
                    libraries = ['freecell-solver'],
                    library_dirs = ['/usr/local/lib'],
                    sources = ['FreecellSolver.c'])

setup (name = 'FreecellSolver',
       version = '0.2.0',
       description = 'This is a demo package',
       author = 'Shlomi Fish',
       author_email = 'shlomif@vipe.technion.ac.il',
       url = 'http://www.python.org/doc/current/ext/building.html',
       long_description = '''
This is really just a demo package.
''',
       ext_modules = [module1])

