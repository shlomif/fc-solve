#include <Python.h>
#include <fcs_cl.h>

typedef struct 
{
    PyObject_HEAD
    void * user_instance;
}FCS;

static void
instance_dealloc(FCS * self)
{
    freecell_solver_user_free(self->user_instance);
	PyObject_Del(self);
}

static PyObject *
translate_ret_code(int code)
{
    char * string;
    switch (code)
    {
#define c(e,s) case FCS_STATE_##e : string = s; break;
        c(WAS_SOLVED, "solved");
        c(IS_NOT_SOLVEABLE, "not_solvable");
        c(ALREADY_EXISTS, "already_exists");
        c(INVALID_STATE, "invalid_state");
        c(SUSPEND_PROCESS, "suspended");
        default:
            string = "ERROR!!!!!!!!!!!!!!!";
            break;
#undef c
    }
    return Py_BuildValue("s", string);
}

static PyObject *
instance_solve(FCS *self, PyObject *args)
{
    char * board;
    int ret;

    if (!PyArg_ParseTuple(args, "s", &board))
    {
        return NULL;
    }

    ret = freecell_solver_user_solve_board(self->user_instance, board);

    return translate_ret_code(ret);
}

static PyObject *
instance_get_next_move(FCS *self, PyObject *args)
{
    fcs_move_t move;
    int code;
    
    code = freecell_solver_user_get_next_move(self->user_instance, &move);

    if (code)
    {
        Py_INCREF(Py_None);
        return Py_None;
    }
    else
    {
        PyObject * ret;
        char * type;
        ret = PyDict_New();
        switch(fcs_move_get_type(move))
        {
#define c(e,s) case FCS_MOVE_TYPE_##e : type = s; break;
            c(STACK_TO_STACK, "s2s");
            c(STACK_TO_FREECELL, "s2f");
            c(FREECELL_TO_STACK, "f2s");
            c(FREECELL_TO_FREECELL, "f2f");
            c(STACK_TO_FOUNDATION, "s2found");
            c(FREECELL_TO_FOUNDATION, "f2found");
            c(SEQ_TO_FOUNDATION, "seq2found");
            default : type = "ERROR!!!!!!!!"; break;
#undef c
        }
        PyDict_SetItemString(ret, "type", Py_BuildValue("s", type));
        PyDict_SetItemString(ret, "src", Py_BuildValue("i", fcs_move_get_src_stack(move)));
        PyDict_SetItemString(ret, "dest", Py_BuildValue("i", fcs_move_get_dest_stack(move)));
        PyDict_SetItemString(ret, "num_cards", Py_BuildValue("i", fcs_move_get_num_cards_in_seq(move)));
        
        return ret;
    }
}

static PyObject *
instance_config(FCS *self, PyObject *args)
{
    char * error_string;
    int last_arg;
    char * * argv;
    int argc;
    int ret;
    int i;
    PyObject * arg_list;
    PyObject * item, * * items_str;
    const char * known_parameters[1] = {NULL};
    
    if (!PyArg_ParseTuple(args, "O", &arg_list))
    {
        return NULL;
    }


    argc = PyList_Size(arg_list);
    argv = malloc(sizeof(argv[0])*argc);
    items_str = malloc(sizeof(items_str[0]) * argc);

    for(i=0;i<argc;i++)
    {
        item = PyList_GetItem(arg_list, i);
        items_str[i] = PyObject_Str(item);
        argv[i] = PyString_AsString(items_str[i]);
    }
    
    ret =
        freecell_solver_user_cmd_line_parse_args(
            self->user_instance,
            argc,
            argv,
            0,
            known_parameters,
            NULL,
            NULL,
            &error_string,
            &last_arg
            );

    for(i=0;i<argc;i++)
    {
        Py_DECREF(items_str[i]);
    }
    free(argv);
    free(items_str);

    return Py_BuildValue("i", ret);
}

static PyObject *
instance_limit_iterations(FCS *self, PyObject *args)
{
    int limit;
    int ret;

    if (!PyArg_ParseTuple(args, "i", &limit))
    {
        return NULL;
    }

    freecell_solver_user_limit_iterations(self->user_instance, limit);

    Py_INCREF(Py_None);
    return Py_None;
}

static PyObject *
instance_resume(FCS *self, PyObject *args)
{
    char * board;
    int ret;

    ret = freecell_solver_user_resume_solution(self->user_instance);

    return translate_ret_code(ret);
}



static PyMethodDef InstanceMethods[] = {
    {"solve", instance_solve, METH_VARARGS,
        "Solve a board"},
    {"get_next_move", instance_get_next_move, METH_VARARGS,
        "Get next move"},
    {"config", instance_config, METH_VARARGS,
        "Configure using the Freecell Solver command line"},
    {"limit_iterations", instance_limit_iterations, METH_VARARGS,
        "Limit the number of iterations the solver will run to."},
    {"resume", instance_resume, METH_VARARGS,
        "Resume a solving process."},
    {NULL, NULL, 0, NULL },
};

static PyObject *
instance_getattr(FCS *self, char *name)
{
	return Py_FindMethod(InstanceMethods, (PyObject *)self, name);
}

static char instance_doc[] = 
"Hello\n"
"You\n";

static PyTypeObject FCStype = {
	PyObject_HEAD_INIT(NULL)
	0,			  /*ob_size*/
	"FreecellSolver.fcs",		  /*tp_name*/
	sizeof(FCS),	  /*tp_size*/
	0,			  /*tp_itemsize*/
	/* methods */
	(destructor)instance_dealloc,  /*tp_dealloc*/
	0,			  /*tp_print*/
	(getattrfunc)instance_getattr, /*tp_getattr*/
	0,			  /*tp_setattr*/
	0,			  /*tp_compare*/
	0,			  /*tp_repr*/
        0,			  /*tp_as_number*/
	0,                        /*tp_as_sequence*/
	0,			  /*tp_as_mapping*/
	0, 			  /*tp_hash*/
	0,			  /*tp_call*/
	0,			  /*tp_str*/
	0,			  /*tp_getattro*/
	0,			  /*tp_setattro*/
	0,	                  /*tp_as_buffer*/
	0,			  /*tp_xxx4*/
	instance_doc,		  /*tp_doc*/
};

static PyObject *
module_alloc(PyObject *self, PyObject *args)
{
    FCS * ret;
    ret = PyObject_New(FCS, &FCStype);
    ret->user_instance = freecell_solver_user_alloc();
    return ret;
}

static PyObject *
spam_system(PyObject *self, PyObject *args)
{
    char *command;
    int sts;

    if (!PyArg_ParseTuple(args, "s", &command))
        return NULL;
    sts = system(command);
    return Py_BuildValue("i", sts);
}

static PyMethodDef SpamMethods[] = {
    {"system",  spam_system, METH_VARARGS,
     "Execute a shell command."},
    {"alloc", module_alloc, METH_VARARGS,
     "Allocate a new instance"},
    {NULL, NULL, 0, NULL}        /* Sentinel */
};

void
initFreecellSolver(void)
{
    (void) Py_InitModule("FreecellSolver", SpamMethods);
}

